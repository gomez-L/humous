
# Hv3

  # ORDINAL MODELING OF AGE AND DIFF IN MOUSE

source("humous_v3/lib/lib_misc.R")
library(Seurat) ; library(dplyr); library(readr) ; library(ggplot2) ; library(plyr) ; library(dplyr) ; library(scales) ; library(purrr) ; library(DescTools)

# LOAD INTEGRATION RESULTS ----
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
IntM <- readRDS("humous_v3/out/IntM/IntM.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


# ANNOTATE CELL TYPES DEFINED UPON INTEGRATION RESULTS
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
DiffTypes_Ms_Int <- read_csv("humous_v3/out/IntM/DiffTypes_Ms_Int.csv")
IntM$diff_ek <- DiffTypes_Ms_Int$DiffTypes_final[match(colnames(IntM),DiffTypes_Ms_Int$cells)]
DimPlot(IntM,group.by = "diff_ek")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


# CELL SELECTION FOR ORDI TRAINING, BALANCED BY AGE GROUPS (X5) AND DIFF GROUPS (X3) ----
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
# across species, the minimum n cells per age & diff combined is 50. Thus, we can select 50 cells per group for ordis (50*5 for age and 50*3 for diff)
table(IntM$age_ek,IntM$diff_ek,useNA = "always")

# define integer label on age and diff levels (ages 16 and 17 same integer group)
IntM$y_age <- as.integer(as.character(plyr::revalue(as.character(IntM$age_ek),c("12"="1","13"="2","14"="3","15"="4","16-17"="5"))))
IntM$y_diff <- as.integer(as.character(plyr::revalue(as.character(IntM$diff_ek),c("RG"="1","IPC"="2","N"="3")))) ; table(IntM$y_age,IntM$y_diff)

# cell selection for training ordinals (balanced by diff and age, not by dataset because this is regressed out in the integration)
# Paste y_age and y_diff for selecting a balanced n of cells per group
IntM$grouping_ordi <- paste0(IntM$y_age,"_",IntM$y_diff) ; table(IntM$grouping_ordi)  
IntM_train <- cell.selector(seuratobject=IntM,cellnames=colnames(IntM),grouping=IntM$grouping_ordi,n=50*5) ; table(IntM_train$grouping_ordi) ; table(IntM_train$y_age,IntM_train$y_diff) 
#saveRDS(IntM_train,"humous_v3/out/ordiM/IntM_train.rds")

# annotate in IntM which cells were used for training ordis (those in IntM_train)
IntM$ordi_split <- ifelse(colnames(IntM) %in% colnames(IntM_train),"ordi_train","ordi_test")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


# Load cells for landscapes - those for which we want to calculate ordinals
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
Ms_4Lands <- read_csv("humous_v3/out/IntM/SelectCells_Ms_Int_forLandscapes.csv")
IntM_L <- subset(IntM,cells=Ms_4Lands$x)
table(IntM_L$age_ek,IntM_L$diff_ek)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


# ORDINALS - Reconstruct age and differentiation
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# AGE 
#######################
fullAGE <- training_ordi_full(datamatrix=t(as.matrix(IntM_train@assays$integrated@scale.data)),
                              target=IntM_train$y_age,
                              cost=costM(X=t(as.matrix(IntM_train@assays$integrated@scale.data)),y=IntM_train$y_age),
                              lambda_full=0.05,epsilon_full=1e-7,maxiter=1000) 
#saveRDS(fullAGE,"humous_v3/out/ordiM/model_fullAGE_M.rds") # save full model

# predict all data and evaluate performance
redAGE <-  custom_red_and_pred(fullmodel=fullAGE,xtrain=t(as.matrix(IntM_train@assays$integrated@scale.data)),target=IntM_train$y_age,
                               xtest=t(as.matrix(IntM_L@assays$integrated@scale.data)),ngenesselect=25,lambda_red=0.05,epsilon_red=1e-7,maxiter=1000,nfolds=20)
#saveRDS(redAGE$redmodel,"humous_v3/out/ordiM/model_redAGE_M.rds") # save reduced model

# store prediction on df rescaled
predAGE <- data.frame( cellnames=c(names(redAGE$pred)), pred=c(scales::rescale(redAGE$pred,to=c(0,1))))
IntM_L$ordi_age <- predAGE$pred[match(colnames(IntM_L),predAGE$cellnames)]

#metricsAGE <- as.data.frame(IntM@meta.data %>% dplyr::group_by(grouping_ordi) %>% summarise_at(vars(ordi_age), list(min=min,max=max,median=median,sd=sd)))
#metricsAGE$range <- metricsAGE$max-metricsAGE$min ; mean(metricsAGE$range)

# visualize prediction
ggplot(IntM_L@meta.data) + geom_density(aes(ordi_age,color=as.character(y_age))) + facet_wrap(~y_diff,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiAGE_density_bydiff.pdf",useDingbats=FALSE)
ggplot(IntM_L@meta.data) + geom_point(aes(ordi_age,y="y",color=as.character(y_age))) + facet_wrap(~grouping_ordi,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiAGE_scatter_byagediff.pdf",useDingbats=FALSE)
ggplot(IntM_L@meta.data) + geom_density(aes(ordi_age,color=as.character(y_age))) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiAGE_density_byage.pdf",useDingbats=FALSE)
ggplot(IntM_L@meta.data,aes(x=ordi_age,y=y_age,color=as.character(y_age)))+ geom_jitter()  + geom_boxplot() + facet_wrap(~y_diff,ncol=1)  + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiAGE_jitterboxplot_byage.pdf",useDingbats=FALSE)
#######################


# DIFF 
#######################
fullDIFF <- training_ordi_full(datamatrix=t(as.matrix(IntM_train@assays$integrated@scale.data)),
                               target=IntM_train$y_diff,
                               cost=costM(X=t(as.matrix(IntM_train@assays$integrated@scale.data)),y=IntM_train$y_diff),
                               lambda_full=0.5,epsilon_full=1e-7,maxiter=1000) 
#saveRDS(fullDIFF,"humous_v3/out/ordiM/model_fullDIFF_M.rds") # save full model

# predict all data and evaluate performance
redDIFF <-  custom_red_and_pred(fullmodel=fullDIFF,xtrain=t(as.matrix(IntM_train@assays$integrated@scale.data)),target=IntM_train$y_diff,
                                xtest=t(as.matrix(IntM_L@assays$integrated@scale.data)),ngenesselect=25,lambda_red=0.5,epsilon_red=1e-7,maxiter=1000,nfolds=2)
#saveRDS(redDIFF$redmodel,"humous_v3/out/ordiM/model_redDIFF_M.rds") # save reduced model

# store prediction on df rescaled
predDIFF <- data.frame( cellnames=c(names(redDIFF$pred)), pred=c(scales::rescale(redDIFF$pred,to=c(0,1))))
IntM_L$ordi_diff <- predDIFF$pred[match(colnames(IntM_L),predDIFF$cellnames)]

#metricsDIFF <- as.data.frame(IntM@meta.data %>% dplyr::group_by(grouping_ordi) %>% summarise_at(vars(ordi_diff), list(min=min,max=max,median=median,sd=sd))) # some metrics

# visualize prediction
ggplot(IntM_L@meta.data) + geom_density(aes(ordi_diff,color=as.character(y_diff))) + facet_wrap(~y_age,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiDIFF_density_byage.pdf",useDingbats=FALSE)
ggplot(IntM_L@meta.data) + geom_point(aes(ordi_diff,y="y",color=as.character(y_diff))) + facet_wrap(~grouping_ordi,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiDIFF_scatter_byagediff.pdf",useDingbats=FALSE)
ggplot(IntM_L@meta.data) + geom_density(aes(ordi_diff,color=as.character(y_diff))) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiDIFF_density_bydiff.pdf",useDingbats=FALSE)
ggplot(IntM_L@meta.data,aes(x=ordi_diff,y=y_diff,color=as.character(y_diff)))+ geom_jitter()  + geom_boxplot()  + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiDIFF_jitterboxplot_bydiff.pdf",useDingbats=FALSE)
#######################
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


# NORMALIZE ORDIS
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

ggplot(IntM_L@meta.data) + geom_point(aes(ordi_age,ordi_diff,color=diff_ek))

IntM_L$ordi_diff_norm <- NA ; IntM_L$ordi_age_norm <- NA 
IntM_L$ordi_diff_norm <- ordi_normalize(ordiscore=IntM_L$ordi_diff,
                                        ordigroups=IntM_L$y_diff,
                                        ordigroups_other=IntM_L$y_age,
                                        limits1=c(0,0.26),limits2=c(0.21,0.5),limits3=c(0.4,1),
                                        applyWinsor=TRUE)

IntM_L$ordi_age_norm <- ordi_normalize(ordiscore=IntM_L$ordi_age,
                                       ordigroups=IntM_L$y_age,
                                       ordigroups_other=IntM_L$y_diff,
                                       applyWinsor=TRUE)


ggplot(IntM_L@meta.data) + geom_point(aes(ordi_age_norm,ordi_diff_norm,color=diff_ek))

#saveRDS(IntM_L,"humous_v3/out/ordiM/IntM_ordi.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


















# CALCULATE GRID FOR LANDSCAPES
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
table(IntM_L$y_age,IntM_L$y_diff)


IntM_L2 <- IntM_L
DefaultAssay(IntM_L2) <- "RNA"

# subset IntM_L2 to keep just genes expressed in all datasets
  # find which genes are expressed in all datasets
expr_genes <- local({
  expr_genes <- list()
  for(i in levels(as.factor(IntM_L2$dataset))){
    expr_genes[[i]] <- rownames(IntM_L2)[which(rowSums(IntM_L2@assays$RNA@counts[,IntM_L2$dataset==i]) > 0)] ; print(length(expr_genes[[i]]))
  }
  expr_genes <- Reduce(intersect,expr_genes) ; print(length(expr_genes)) ; expr_genes
})
IntM_L2 <- subset(IntM_L2,features = expr_genes)

# scale data slot for nfeatures on all genes
IntM_L2 <- IntM_L2 %>% NormalizeData() %>% ScaleData(vars.to.regress="nFeature_RNA",features=rownames(IntM_L2))

# correct scale data so it has all positive values  
rang_expr <- range(IntM_L2@assays$RNA@scale.data)
IntM_L2@assays$RNA@scale.data <- IntM_L2@assays$RNA@scale.data + abs(min(IntM_L2@assays$RNA@scale.data))

#save IntM_L2
#saveRDS(IntM_L2,"humous_v3/out/landscapes/IntM_4_L.rds")

# check if gene expression makes sense in scale.data scatter
IntM_L2$Sox2 <- IntM_L2@assays$RNA@scale.data["Sox2",] ; IntM_L2$Eomes <- IntM_L2@assays$RNA@scale.data["Eomes",] ; IntM_L2$Neurod6 <- IntM_L2@assays$RNA@scale.data["Neurod6",]
IntM_L2$Junb <- IntM_L2@assays$RNA@scale.data["Junb",] ; IntM_L2$Apbb2 <- IntM_L2@assays$RNA@scale.data["Apbb2",] 
ggplot(IntM_L2@meta.data) + geom_point(aes(ordi_age_norm,ordi_diff_norm,color=Apbb2)) + scale_color_gradient2(low="white",mid="grey",high="red",midpoint = 6)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

source("lib/lib_landscape.R")

# CALCULATE GRIDS - LOW AND MED RESOLUTION
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
gridlist <- list(grid_medR=knn_array_medres(IntM_L2$ordi_age_norm,IntM_L2$ordi_diff_norm,k=200L),
                 grid_lowR=knn_array_lowres(IntM_L2$ordi_age_norm,IntM_L2$ordi_diff_norm,k=200L))
#saveRDS(gridlist,"humous_v2/out/landscapes/gridlist.rds")
gridlist <- readRDS("humous_v2/out/landscapes/gridlist_M.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


L_LR_M <- local({
  m <- IntM_L2@assays$RNA@scale.data[c("Sox2","Eomes","Neurod6","Junb","Apbb2"),]
  landscapes_LR_M <- knn_rowMeans(m,gridlist$grid_lowR) ; rownames(landscapes_LR_M) <- rownames(m) ; landscapes_LR_M
})

as.array(L_LR_M["Eomes",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster() + scale_y_continuous(breaks = c(-0.95,-0.7,-0.4,-0.15),labels = c("aRG","oRG/bRG/IPC","iN","mN"))  + scale_x_continuous(breaks = c(0,1),labels = c("10pcw","24pcw"))


L_MR_M <- local({
  m <- IntM_L2@assays$RNA@scale.data[c("Sox2","Eomes","Neurod6","Junb","Apbb2"),]
  landscapes_MR_M <- knn_rowMeans(m,gridlist$grid_medR) ; rownames(landscapes_MR_M) <- rownames(m) ; landscapes_MR_M
})

as.array(L_MR_M["Apbb2",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster() + scale_y_continuous(breaks = c(-0.95,-0.5,-0.15),labels = c("aRG","IPC","mN"))  + scale_x_continuous(breaks = c(0,1),labels = c("12","17"))

#



















# AGE ORDINAL - one model per diff group ----
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# FOR EACH DIFF GROUP, CALCULATE AGE ORDI
################################
fullAGE_list <- list() 
redAGE_list <- list()
for (i in levels(as.factor(IntM$y_diff))){
  fullAGE_list[[i]] <- training_ordi_full(datamatrix=t(as.matrix(IntM_train@assays$integrated@scale.data[,colnames(IntM_train)[IntM_train$y_diff==i]])),target=IntM_train$y_age[IntM_train$y_diff==i],
                                          cost=costM(X=t(as.matrix(IntM_train@assays$integrated@scale.data[,colnames(IntM_train)[IntM_train$y_diff==i]])),y=IntM_train$y_age[IntM_train$y_diff==i]),
                                          lambda_full=0.1,epsilon_full=1e-7,maxiter=1000) 
  
  redAGE_list[[i]] <-  custom_red_and_pred(fullmodel=fullAGE_list[[i]],xtrain=t(as.matrix(IntM_train@assays$integrated@scale.data[,colnames(IntM_train)[IntM_train$y_diff==i]])),target=IntM_train$y_age[IntM_train$y_diff==i],
                                           xtest=t(as.matrix(IntM@assays$integrated@scale.data[,colnames(IntM)[IntM$y_diff==i]])),ngenesselect=25,lambda_red=0.05,epsilon_red=1e-7,maxiter=1000,nfolds=5)
}

# ASSEMBLE AGE ORDIS & CORRECT BY MODEL SD (per diff group) 
predAGE <- (apply(t(redAGE_list %>% map(~.x$pred) %>% bind_rows()),1, function(x) paste(na.omit(x),collapse="") ))
IntM$ordi_age <- as.numeric(predAGE)[match(colnames(IntM),names(predAGE))]

metricsAGE <- as.data.frame(IntM@meta.data %>% dplyr::group_by(grouping_ordi) %>% summarise_at(vars(ordi_age), list(min=min,max=max,median=median,sd=sd)))
metricsAGE$range <- metricsAGE$max-metricsAGE$min ; mean(metricsAGE$range)
################################


# NORMALIZE PREDICTIONS (first correct median shift, then scale by st deviation, then apply sigmoid to each ordigroup and them apply tanh activation to each diff group)
################################
IntM$ordi_age_norm <- NA
vec_list <- split(IntM$ordi_age,as.character(IntM$y_diff))
for (i in levels(as.factor(IntM$y_age))){
  vec_norm_list <- lapply(vec_list,function(x){
    print(median(x)) # median of current split
    print(median(sapply(vec_norm_list, median))) # median across all splits
    x + ( median(sapply(vec_norm_list, median)) - median(x))      
  })
  vec_norm_assembled <- do.call(c,vec_norm_list)
  IntM$ordi_age_norm[IntM$y_age==i] <- vec_norm_assembled[match( colnames(IntM)[IntM$y_age==i] , substring(names(vec_norm_assembled),3) )]
}
for (i in levels(as.factor(IntM$y_age))){ IntM$ordi_diff_norm[IntM$y_age==i] <- rescale(IntM$ordi_diff_norm[IntM$y_age==i] , to=c(0,1)) }

for (i in levels(as.factor(IntM$grouping_ordi))){  
  IntM$ordi_age_norm[IntM$grouping_ordi==i] <- (IntM$ordi_age_norm[IntM$grouping_ordi==i] - median(IntM$ordi_age_norm[IntM$grouping_ordi==i])) * (0.1/sd(IntM$ordi_age_norm[IntM$grouping_ordi==i])) + median(IntM$ordi_age_norm[IntM$grouping_ordi==i]) }

for (i in levels(as.factor(IntM$grouping_ordi))){  
  # apply sigmoid function - takes the form 1/(1+exp(-k*(x-c))), where k is the steepness of the curve and c is the midpoint of the range
  IntM$ordi_age_norm[IntM$grouping_ordi==i] <- quantile(IntM$ordi_age_norm[IntM$grouping_ordi==i],0.2) + quantile(IntM$ordi_age_norm[IntM$grouping_ordi==i],0.8) *
    (1/(1+exp(-10*(IntM$ordi_age_norm[IntM$grouping_ordi==i]-quantile(IntM$ordi_age_norm[IntM$grouping_ordi==i],0.25))))) 
}
for (i in levels(as.factor(IntM$y_diff))){ IntM$ordi_age_norm[IntM$y_diff==i] <- rescale(IntM$ordi_age_norm[IntM$y_diff==i] , to=c(0,1)) }
IntM$ordi_age_tanh <- NA 
for (i in levels(as.factor(IntM$y_diff))){
  IntM$ordi_age_tanh[IntM$y_diff==i] <- rescale(tanh(IntM$ordi_age_norm[IntM$y_diff==i]-median(IntM$ordi_age_norm[IntM$y_diff==i])*0.9),to =c(0,1) )
}
################################


# check performance
################################
metricsAGEnorm <- as.data.frame(IntM@meta.data %>% dplyr::group_by(grouping_ordi) %>% summarise_at(vars(ordi_age_tanh), list(min=min,max=max,median=median,sd=sd))) 
metricsAGEnorm$range <- metricsAGEnorm$max-metricsAGEnorm$min ; mean(metricsAGEnorm$range)

ggplot(IntM@meta.data,aes(x=ordi_age_norm,y=y_age,color=as.character(y_age)))+ geom_jitter()  + geom_boxplot() + facet_wrap(~y_diff,ncol=1)  + theme_bw()
ggplot(IntM@meta.data,aes(x=ordi_age_tanh,y=y_age,color=as.character(y_age)))+ geom_jitter()  + geom_boxplot() + facet_wrap(~y_diff,ncol=1)  + theme_bw()
ggplot(IntM@meta.data) + geom_jitter(aes(x=ordi_age_norm,y="y",color=as.character(IntM$y_age)))
ggplot(IntM@meta.data) + geom_jitter(aes(x=ordi_age_tanh,y="y",color=as.character(IntM$y_age)))

ggplot(IntM@meta.data) + geom_density(aes(ordi_age,color=as.character(y_age))) + facet_wrap(~y_diff,ncol=1) + theme_bw() 
ggplot(IntM@meta.data) + geom_density(aes(ordi_age_tanh,color=as.character(y_age))) + facet_wrap(~y_diff,ncol=1) + theme_bw() 
ggplot(IntM@meta.data) + geom_point(aes(ordi_age_tanh,y="y",color=as.character(y_age))) + facet_wrap(~grouping_ordi,ncol=1) + theme_bw() 
ggplot(IntM@meta.data) + geom_density(aes(ordi_age_norm,color=as.character(y_age))) + theme_bw() 
ggplot(IntM@meta.data,aes(x=ordi_age_norm,y=y_age,color=as.character(y_age)))+ geom_jitter()  + geom_boxplot()  + theme_bw() + facet_wrap(~grouping_ordi,ncol=1)
################################

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #



# DIFF ORDINAL - one model per age group ----
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
fullDIFF_list <- list()
redDIFF_list <- list()
for (i in levels(as.factor(IntM_train$y_age))){
  print(table(IntM_train$y_age[IntM_train$y_age==i],IntM_train$y_diff[IntM_train$y_age==i]))
  fullDIFF_list[[i]] <- training_ordi_full(datamatrix=t(as.matrix(IntM_train@assays$integrated@scale.data[,colnames(IntM_train)[IntM_train$y_age==i]])),target=IntM_train$y_diff[IntM_train$y_age==i],
                                           cost=costM(X=t(as.matrix(IntM_train@assays$integrated@scale.data[,colnames(IntM_train)[IntM_train$y_age==i]])),y=IntM_train$y_diff[IntM_train$y_age==i]),
                                           lambda_full=1,epsilon_full=1e-7,maxiter=1000) 
  
  redDIFF_list[[i]] <-  custom_red_and_pred(fullmodel=fullDIFF_list[[i]],xtrain=t(as.matrix(IntM_train@assays$integrated@scale.data[,colnames(IntM_train)[IntM_train$y_age==i]])),target=IntM_train$y_diff[IntM_train$y_age==i],
                                            xtest=t(as.matrix(IntM@assays$integrated@scale.data[,colnames(IntM)[IntM$y_age==i]])),ngenesselect=25,lambda_red=1,epsilon_red=1e-7,maxiter=2000,nfolds=5)
}

# ASSEMBLE DIFF ORDIS & CORRECT BY MODEL SD (per diff group) 
predDIFF <- (apply(t(redDIFF_list %>% map(~.x$pred) %>% bind_rows()),1, function(x) paste(na.omit(x),collapse="") ))
IntM$ordi_diff <- as.numeric(predDIFF)[match(colnames(IntM),names(predDIFF))]

metricsDIFF <- as.data.frame(IntM@meta.data %>% dplyr::group_by(grouping_ordi) %>% summarise_at(vars(ordi_diff), list(min=min,max=max,median=median,sd=sd)))
metricsDIFF$range <- metricsDIFF$max-metricsDIFF$min ; mean(metricsDIFF$range)


# NORMALIZE PREDICTIONS
IntM$ordi_diff_norm <- NA
vec_list <- split(IntM$ordi_diff,as.character(IntM$y_age))
for (i in levels(as.factor(IntM$y_diff))){
  vec_norm_list <- lapply(vec_list,function(x){
    print(median(x)) # median of current split
    print(median(sapply(vec_norm_list, median))) # median across all splits
    x + ( median(sapply(vec_norm_list, median)) - median(x))      
  })
  vec_norm_assembled <- do.call(c,vec_norm_list)
  IntM$ordi_diff_norm[IntM$y_diff==i] <- vec_norm_assembled[match( colnames(IntM)[IntM$y_diff==i] , substring(names(vec_norm_assembled),3) )]
}
for (i in levels(as.factor(IntM$y_age))){ IntM$ordi_diff_norm[IntM$y_age==i] <- rescale(IntM$ordi_diff_norm[IntM$y_age==i] , to=c(0,1)) }


for (i in levels(as.factor(IntM$grouping_ordi))){  
  IntM$ordi_diff_norm[IntM$grouping_ordi==i] <- (IntM$ordi_diff_norm[IntM$grouping_ordi==i] - median(IntM$ordi_diff_norm[IntM$grouping_ordi==i])) * (0.1/sd(IntM$ordi_diff_norm[IntM$grouping_ordi==i])) + median(IntM$ordi_diff_norm[IntM$grouping_ordi==i]) }

for (i in levels(as.factor(IntM$grouping_ordi))){  
  # apply sigmoid function - takes the form 1/(1+exp(-k*(x-c))), where k is the steepness of the curve and c is the midpoint of the range
  IntM$ordi_diff_norm[IntM$grouping_ordi==i] <- quantile(IntM$ordi_diff_norm[IntM$grouping_ordi==i],0.2) + quantile(IntM$ordi_diff_norm[IntM$grouping_ordi==i],0.8) *
    (1/(1+exp(-10*(IntM$ordi_diff_norm[IntM$grouping_ordi==i]-quantile(IntM$ordi_diff_norm[IntM$grouping_ordi==i],0.25))))) 
}
for (i in levels(as.factor(IntM$y_age))){ IntM$ordi_diff_norm[IntM$y_age==i] <- rescale(IntM$ordi_diff_norm[IntM$y_age==i] , to=c(0,1)) }
IntM$ordi_diff_tanh <- NA 
for (i in levels(as.factor(IntM$y_age))){
  IntM$ordi_diff_tanh[IntM$y_age==i] <- rescale(tanh(IntM$ordi_diff_norm[IntM$y_age==i]-median(IntM$ordi_diff_norm[IntM$y_age==i])*0.9),to =c(0,1) )
}

ggplot(IntM@meta.data,aes(x=ordi_diff,color=as.character(y_diff))) + geom_boxplot() + facet_wrap(~y_age,ncol=1)  + theme_bw()
ggplot(IntM@meta.data,aes(x=ordi_diff_norm,color=as.character(y_diff))) + geom_boxplot() + facet_wrap(~y_age,ncol=1)  + theme_bw()


ggplot(IntM@meta.data,aes(x=ordi_diff_norm,y=y_age,color=as.character(y_diff)))+ geom_jitter()  + geom_boxplot() + facet_wrap(~y_age,ncol=1)  + theme_bw()
ggplot(IntM@meta.data,aes(x=ordi_age_tanh,y=y_age,color=as.character(y_age)))+ geom_jitter()  + geom_boxplot() + facet_wrap(~y_diff,ncol=1)  + theme_bw()
ggplot(IntM@meta.data) + geom_jitter(aes(x=ordi_diff_norm,y="y",color=as.character(IntM$diff_ek)))


ggplot(IntM@meta.data) + geom_point(aes(ordi_age,y=ordi_diff,col=age_ek))
ggplot(IntM@meta.data) + geom_point(aes(ordi_age_norm,y=ordi_diff_norm,col=age_ek))
ggplot(IntM@meta.data) + geom_point(aes(ordi_age_tanh,y=ordi_diff_tanh,col=age_ek))

ggplot(IntM@meta.data) + geom_point(aes(ordi_age_norm,y=ordi_diff_norm,col=diff_ek))
ggplot(IntM@meta.data) + geom_point(aes(ordi_age_tanh,y=ordi_diff_tanh,col=age_ek))
ggplot(IntM@meta.data) + geom_point(aes(ordi_age_tanh,y=ordi_diff_tanh^2,col=diff_ek))


# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #






# NORMALIZE PREDICTIONS
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


source("lib/lib1.R")



IntM$ordi_age_norm <- NA
IntM$ordi_age_norm <- quantile(IntM$ordi_age,0.2) + quantile(IntM$ordi_age,0.8) * (1/(1+exp(-10*(IntM$ordi_age-quantile(IntM$ordi_age,0.5))))) 
for (i in levels(as.factor(IntM$y_diff))){ IntM$ordi_age_norm[IntM$y_diff==i] <- rescale(IntM$ordi_age_norm[IntM$y_diff==i] , to=c(0,1)) }
age_intersections <- list(
  Start=min(IntM$ordi_age_norm),
  Int_1_2=find_intersect(cellnames=colnames(IntM),axis=IntM$ordi_age_norm,groups=IntM$y_age,group1=c("1"),group2=c("2")),
  Int_2_3=find_intersect(cellnames=colnames(IntM),axis=IntM$ordi_age_norm,groups=IntM$y_age,group1=c("2"),group2=c("3")),
  Int_3_4=find_intersect(cellnames=colnames(IntM),axis=IntM$ordi_age_norm,groups=IntM$y_age,group1=c("3"),group2=c("4")),
  End=max(IntM$ordi_age_norm)
)
age_segments <- data.frame(row.names=levels(as.factor(IntM$y_age)),groups=levels(as.factor(IntM$y_age)), min=c(0,0.1,0.3,0.5,0.7),max=c(0.2,0.4,0.6,0.8,1))
for (i in levels(as.factor(IntM$y_age))){IntM$ordi_age_norm[IntM$y_age==i] <- scales::rescale(IntM$ordi_age_norm[IntM$y_age==i],to=c(age_segments[i,2],age_segments[i,3]))} 




IntM$ordi_diff_norm <- NA ; IntM$ordi_age_norm <- NA 
# iteratively, detect distribution type and perform tanh transformation accordingly
IntM$ordi_diff_norm <- ordi_activate(IntM$ordi_diff,10)
IntM$ordi_age_norm <- ordi_activate(IntM$ordi_age,10)

IntM$ordi_age_norm <- tanh((IntM$ordi_age - median(IntM$ordi_age))*5)
IntM$ordi_diff_norm <- tanh((IntM$ordi_diff - median(IntM$ordi_diff))*1)

IntM$ordi_age_norm <- tanh((IntM$ordi_age_norm - median(IntM$ordi_age_norm))*1)
IntM$ordi_diff_norm <- tanh((IntM$ordi_diff_norm - median(IntM$ordi_diff_norm))*1)



library(DescTools)

IntM$ordi_age_norm <- Winsorize(IntM$ordi_age,probs=c(0.1,0.9),type=2)
IntM$ordi_diff_norm <- Winsorize(IntM$ordi_diff,probs=c(0.01,0.99),type=2)
ggplot(IntM@meta.data) + geom_point(aes((ordi_age_norm),y=(ordi_diff_norm),col=diff_ek))
ggplot(IntM@meta.data) + geom_point(aes(ordi_age_norm,y=ordi_diff_norm,col=age_ek)) + facet_wrap(~grouping_ordi,ncol=3)







#IntM$ordi_diff_norm <- quantile(IntM$ordi_diff_norm,0.2) + quantile(IntM$ordi_diff_norm,0.8) * (1/(1+exp(-1*(IntM$ordi_diff_norm-quantile(IntM$ordi_diff_norm,0.5))))) 
IntM$ordi_diff_norm <- tanh(IntM$ordi_diff_norm- median(IntM$ordi_diff_norm)*0.9)
for (i in levels(as.factor(IntM$y_age))){ IntM$ordi_diff_norm[IntM$y_age==i] <- rescale(IntM$ordi_diff_norm[IntM$y_age==i] , to=c(0,1)) }
diff_intersections <- list(
  Start=min(IntM$ordi_diff_norm),
  Int_1_2=find_intersect(cellnames=colnames(IntM),axis=IntM$ordi_diff_norm,groups=IntM$y_age,group1=c("1"),group2=c("2")),
  Int_2_3=find_intersect(cellnames=colnames(IntM),axis=IntM$ordi_diff_norm,groups=IntM$y_age,group1=c("2"),group2=c("3")),
  End=max(IntM$ordi_diff_norm)
)
diff_segments <- data.frame(row.names=levels(as.factor(IntM$y_diff)),groups=levels(as.factor(IntM$y_diff)), min=c(0,0.1,0.3),max=c(0.4,0.6,1))
for (i in levels(as.factor(IntM$y_diff))){IntM$ordi_diff_norm[IntM$y_diff==i] <- scales::rescale(IntM$ordi_diff_norm[IntM$y_diff==i],to=c(diff_segments[i,2],diff_segments[i,3]))} 
ggplot(IntM@meta.data) + geom_point(aes(ordi_age,y=ordi_diff,col=age_ek))

#
diagonal_length <- sqrt( ( max(IntM$ordi_age) - min(IntM$ordi_age) ) * ( max(IntM$ordi_age) - min(IntM$ordi_age) ) + ( max(IntM$ordi_diff) - min(IntM$ordi_diff) ) * ( max(IntM$ordi_diff) - min(IntM$ordi_diff) )  )
IntM$ordi_age <- ( IntM$ordi_age - min(IntM$ordi_age) ) / diagonal_length
IntM$ordi_diff <- ( IntM$ordi_diff - min(IntM$ordi_diff) ) / diagonal_length

ggplot(IntM@meta.data) + geom_point(aes((ordi_age_norm),y=(ordi_diff_norm),col=age_ek))

IntM$ordi_age_norm <- tanh((IntM$ordi_age - mean(IntM$ordi_age))*5)
IntM$ordi_diff_norm <- tanh((IntM$ordi_diff - mean(IntM$ordi_diff))*0.05)

ggplot(IntM@meta.data) + geom_point(aes((ordi_age),y=(ordi_diff),col=age_ek))






IntM$ordi_diff_norm <- NA
IntM$ordi_diff_norm <- quantile(IntM$ordi_diff,0.2) + quantile(IntM$ordi_diff,0.8) * (1/(1+exp(-10*(IntM$ordi_diff-quantile(IntM$ordi_diff,0.25))))) 


ggplot(IntM@meta.data) + geom_point(aes(ordi_age_norm,y=ordi_diff,col=age_ek))
ggplot(IntM@meta.data) + geom_point(aes(ordi_age,y=ordi_diff,col=age_ek))


ggplot(IntM@meta.data) + geom_point(aes(ordi_age_norm,y=ordi_diff,col=age_ek)) + facet_wrap(~grouping_ordi,ncol=3)
ggplot(IntM@meta.data) + geom_point(aes(ordi_age,y=ordi_diff,col=age_ek)) + facet_wrap(~grouping_ordi,ncol=3)



for (i in levels(as.factor(IntM$grouping_ordi))){  
  # apply sigmoid function - takes the form 1/(1+exp(-k*(x-c))), where k is the steepness of the curve and c is the midpoint of the range
  IntM$ordi_age_norm[IntM$grouping_ordi==i] <- quantile(IntM$ordi_age_norm[IntM$grouping_ordi==i],0.2) + quantile(IntM$ordi_age_norm[IntM$grouping_ordi==i],0.8) *
    (1/(1+exp(-10*(IntM$ordi_age_norm[IntM$grouping_ordi==i]-quantile(IntM$ordi_age_norm[IntM$grouping_ordi==i],0.25))))) 
}
for (i in levels(as.factor(IntM$y_diff))){ IntM$ordi_age_norm[IntM$y_diff==i] <- rescale(IntM$ordi_age_norm[IntM$y_diff==i] , to=c(0,1)) }
IntM$ordi_age_tanh <- NA 
for (i in levels(as.factor(IntM$y_diff))){
  IntM$ordi_age_tanh[IntM$y_diff==i] <- rescale(tanh(IntM$ordi_age_norm[IntM$y_diff==i]-median(IntM$ordi_age_norm[IntM$y_diff==i])*0.9),to =c(0,1) )
}



for (i in levels(as.factor(IntM$grouping_ordi))){  
  # apply sigmoid function - takes the form 1/(1+exp(-k*(x-c))), where k is the steepness of the curve and c is the midpoint of the range
  IntM$ordi_diff_norm[IntM$grouping_ordi==i] <- quantile(IntM$ordi_diff_norm[IntM$grouping_ordi==i],0.2) + quantile(IntM$ordi_diff_norm[IntM$grouping_ordi==i],0.8) *
    (1/(1+exp(-10*(IntM$ordi_diff_norm[IntM$grouping_ordi==i]-quantile(IntM$ordi_diff_norm[IntM$grouping_ordi==i],0.25))))) 
}
for (i in levels(as.factor(IntM$y_age))){ IntM$ordi_diff_norm[IntM$y_age==i] <- rescale(IntM$ordi_diff_norm[IntM$y_age==i] , to=c(0,1)) }


IntM$ordi_diff_tanh <- NA 
for (i in levels(as.factor(IntM$y_age))){
  IntM$ordi_diff_tanh[IntM$y_age==i] <- rescale(tanh(IntM$ordi_diff_norm[IntM$y_age==i]-median(IntM$ordi_diff_norm[IntM$y_age==i])*0.9),to =c(0,1) )
}
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #















# AGE 
#######################
fullAGE <- training_ordi_full(datamatrix=t(as.matrix(IntM_train@assays$integrated@scale.data)),
                              target=IntM_train$y_age,
                              cost=costM(X=t(as.matrix(IntM_train@assays$integrated@scale.data)),y=IntM_train$y_age),
                              lambda_full=0.05,epsilon_full=1e-7,maxiter=1000) 
# save full model
#saveRDS(fullAGE,"humous_v3/out/IntM/model_fullAGE_orghuman.rds")

# predict all data and evaluate performance
redAGE <-  custom_red_and_pred(fullmodel=fullAGE,xtrain=t(as.matrix(IntM_train@assays$integrated@scale.data)),target=IntM_train$y_age,
                               xtest=t(as.matrix(IntM@assays$integrated@scale.data)),ngenesselect=25,lambda_red=0.05,epsilon_red=1e-7,maxiter=1000,nfolds=20)
# save reduced model
#saveRDS(redAGE$redmodel,"humous_v3/out/IntM/model_redAGE_orghuman.rds")

# store prediction on df rescaled
predAGE <- data.frame( cellnames=c(names(redAGE$pred)), pred=c(scales::rescale(redAGE$pred,to=c(0,1))))

IntM$ordi_age <- predAGE$pred[match(colnames(IntM),predAGE$cellnames)]

metricsAGE <- as.data.frame(IntM@meta.data %>% dplyr::group_by(grouping_ordi) %>% summarise_at(vars(ordi_age), list(min=min,max=max,median=median,sd=sd)))
metricsAGE$range <- metricsAGE$max-metricsAGE$min ; mean(metricsAGE$range)

# visualize prediction
ggplot(IntM@meta.data) + geom_density(aes(ordi_age,color=as.character(y_age))) + facet_wrap(~y_diff,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiAGE_density_bydiff.pdf",useDingbats=FALSE)
ggplot(IntM@meta.data) + geom_point(aes(ordi_age,y="y",color=as.character(y_age))) + facet_wrap(~grouping_ordi,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiAGE_scatter_byagediff.pdf",useDingbats=FALSE)
ggplot(IntM@meta.data) + geom_density(aes(ordi_age,color=as.character(y_age))) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiAGE_density_byage.pdf",useDingbats=FALSE)
ggplot(IntM@meta.data,aes(x=ordi_age,y=y_age,color=as.character(y_age)))+ geom_jitter()  + geom_boxplot() + facet_wrap(~y_diff,ncol=1)  + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiAGE_jitterboxplot_byage.pdf",useDingbats=FALSE)
#######################



# DIFF 
#######################
fullDIFF <- training_ordi_full(datamatrix=t(as.matrix(IntM_train@assays$integrated@scale.data)),
                               target=IntM_train$y_diff,
                               cost=costM(X=t(as.matrix(IntM_train@assays$integrated@scale.data)),y=IntM_train$y_diff),
                               lambda_full=0.5,epsilon_full=1e-7,maxiter=1000) 
# save full model
#saveRDS(fullDIFF,"humous_v3/out/IntM/model_fullDIFF_orghuman.rds")

# predict all data and evaluate performance
redDIFF <-  custom_red_and_pred(fullmodel=fullDIFF,xtrain=t(as.matrix(IntM_train@assays$integrated@scale.data)),target=IntM_train$y_diff,
                                xtest=t(as.matrix(IntM@assays$integrated@scale.data)),ngenesselect=25,lambda_red=0.5,epsilon_red=1e-7,maxiter=1000,nfolds=2)
# save reduced model
#saveRDS(redDIFF$redmodel,"humous_v3/out/IntM/model_redDIFF_orghuman.rds")

# store prediction on df rescaled
predDIFF <- data.frame( cellnames=c(names(redDIFF$pred)), pred=c(scales::rescale(redDIFF$pred,to=c(0,1))))

IntM$ordi_diff <- predDIFF$pred[match(colnames(IntM),predDIFF$cellnames)]

metricsDIFF <- as.data.frame(IntM@meta.data %>% dplyr::group_by(grouping_ordi) %>% summarise_at(vars(ordi_diff), list(min=min,max=max,median=median,sd=sd)))

# visualize prediction
ggplot(IntM@meta.data) + geom_density(aes(ordi_diff,color=as.character(y_diff))) + facet_wrap(~y_age,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiDIFF_density_byage.pdf",useDingbats=FALSE)
ggplot(IntM@meta.data) + geom_point(aes(ordi_diff,y="y",color=as.character(y_diff))) + facet_wrap(~grouping_ordi,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiDIFF_scatter_byagediff.pdf",useDingbats=FALSE)
ggplot(IntM@meta.data) + geom_density(aes(ordi_diff,color=as.character(y_diff))) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiDIFF_density_bydiff.pdf",useDingbats=FALSE)
ggplot(IntM@meta.data,aes(x=ordi_diff,y=y_diff,color=as.character(y_diff)))+ geom_jitter()  + geom_boxplot()  + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiDIFF_jitterboxplot_bydiff.pdf",useDingbats=FALSE)
#######################

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


ggplot(IntM@meta.data) + geom_point(aes(ordi_age,ordi_diff,color=diff_ek))

IntM$ordi_diff_norm <- NA ; IntM$ordi_age_norm <- NA 
# iteratively, detect distribution type and perform tanh transformation accordingly
IntM$ordi_diff_norm <- ordi_activate(IntM$ordi_diff)
IntM$ordi_age_norm <- ordi_activate(IntM$ordi_age,2)

ggplot(IntM@meta.data) + geom_point(aes(ordi_age_norm,ordi_diff_norm,color=diff_ek))



w <- attr(redDIFF$redmodel,"gradient")
a <- as.data.frame(t(w))
IntM$Nfix <- IntM@assays$RNA@data["Nfix",]
ggplot(IntM@meta.data) + geom_point(aes(ordi_age_norm,ordi_diff_norm,color=Nfix))
IntM$Sox2 <- IntM@assays$RNA@data["Sox2",]
ggplot(IntM@meta.data) + geom_point(aes(ordi_age,ordi_diff,color=Sox2)) + facet_wrap(~y_diff)
ggplot(IntM@meta.data) + geom_point(aes(ordi_age_norm,ordi_diff_norm,color=Sox2)) + facet_wrap(~y_age)


library(faux)
IntM$ordi_age_norm <- as.numeric(faux::norm2unif(IntM$ordi_age))
ggplot(IntM@meta.data) + geom_point(aes(ordi_age,ordi_diff,color=age_ek))
IntM$ordi_diff_norm <- as.numeric(faux::norm2unif(IntM$ordi_diff))


