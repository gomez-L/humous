
# INTEGRATION OF MOUSE DATASETS

source("lib/lib_misc.R")
library(Seurat) ; library(dplyr); library(readr) ; library(ggplot2) ; library(plyr) ; library(dplyr) ; library(scales)

      
# load raw mouse datasets and join them in a list ----
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
full.list <- list(Ad21=readRDS("data/M/Ad21.rds"),
                  My17=readRDS("data/M/My17.rds"),
                  LMl21=readRDS("data/M/LMl21.rds"),
                  Jt19=readRDS("data/M/Jt19.rds"))
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


# filter cells on each dataset to keep ages and types of interest, annotate also by dataset (for integration)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# load annotations prepared by esther, filter and attach age and diff vectors

# Ad21
annot_Ad21 <- read_csv("data/M/DiffTypes_Ad21.csv") ; table(annot_Ad21$age,annot_Ad21$DiffTypes,useNA="always") ; dim(annot_Ad21)
full.list$Ad21 <- subset(full.list$Ad21,cells=annot_Ad21$cells[annot_Ad21$DiffTypes != "CR"]) # subset
full.list$Ad21$age_ek <- annot_Ad21$age[match(colnames(full.list$Ad21),annot_Ad21$cells)]
full.list$Ad21$diff_ek <- annot_Ad21$DiffTypes[match(colnames(full.list$Ad21),annot_Ad21$cells)]
table(full.list$Ad21$age_ek,full.list$Ad21$diff_ek,useNA = "always")
full.list$Ad21$dataset <- "Ad21"

# My17
annot_My17 <- read_csv("data//M/DiffTypes_My17.csv") ; table(annot_My17$age,annot_My17$DiffTypes,useNA="always") ; dim(annot_My17)
full.list$My17 <- subset(full.list$My17,cells=annot_My17$cells[ ! annot_My17$DiffTypes %in% c("CR","SP","IPCearly") & annot_My17$age!="11" ] ) # subset
full.list$My17$age_ek <- annot_My17$age[match(colnames(full.list$My17),annot_My17$cells)]
full.list$My17$diff_ek <- annot_My17$DiffTypes[match(colnames(full.list$My17),annot_My17$cells)]
table(full.list$My17$age_ek,full.list$My17$diff_ek,useNA = "always") 
full.list$My17$dataset <- "My17"

# LMl21
annot_LMl21 <- read_csv("data//M/DiffTypes_LMl21.csv")  ; table(annot_LMl21$age,annot_LMl21$DiffTypes,useNA="always") ; dim(annot_LMl21)
full.list$LMl21 <- subset(full.list$LMl21,cells=annot_LMl21$cells[ ! annot_LMl21$DiffTypes %in% c("CR")]) # subset
full.list$LMl21$age_ek <- annot_LMl21$age[match(colnames(full.list$LMl21),annot_LMl21$cells)]
full.list$LMl21$diff_ek <- annot_LMl21$DiffTypes[match(colnames(full.list$LMl21),annot_LMl21$cells)]
table(full.list$LMl21$age_ek,full.list$LMl21$diff_ek,useNA = "always") # all good
full.list$LMl21$dataset <- "LMl21"

# Jt19
annot_Jt19 <- read_csv("data/M/DiffTypes_Jt19.csv")  ; table(annot_Jt19$age,annot_Jt19$DiffTypes,useNA="always") ; dim(annot_Jt19)
# all good, no need to subset
full.list$Jt19$age_ek <- annot_Jt19$age[match(colnames(full.list$Jt19),annot_Jt19$cells)] 
table(full.list$Jt19$age_ek,useNA = "always") # there are some NA cells, remove them
full.list$Jt19$age_ek <- ifelse(is.na(full.list$Jt19$age_ek),"toremove",as.character(full.list$Jt19$age_ek))
full.list$Jt19 <- subset(full.list$Jt19,age_ek!="toremove")
full.list$Jt19$diff_ek <- annot_Jt19$DiffTypes[match(colnames(full.list$Jt19),annot_Jt19$cells)]
table(full.list$Jt19$age_ek,full.list$Jt19$diff_ek,useNA = "always") 
full.list$Jt19$dataset <- "Jt19"

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #



# CELL SELECTION FOR INTEGRATION ----
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
# as integration will balance by dataset/protocol, and cell types will be redefined based on integration, select based on age

merged <- merge(full.list$Ad21,list(full.list$My17,full.list$LMl21,full.list$Jt19))
table(merged$age_ek ,useNA = "always") # all good

# SELECT CELLS UP TO 6000 per age group no matter celltype neither dataset

# re-define age groups
merged$age_ek <- plyr::revalue(merged$age_ek,c("12"="12","13"="13","14"="14","15"="15","16"="16-17","17"="16-17"))

# select 6000 per age
merged_f <- cell.selector(merged,colnames(merged),merged$age_ek,6000)
table(merged_f$age_ek ,useNA = "always") # all good

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


# Run pairwise Seurat integration ----
# finding anchors between all datasets
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

full.list <- SplitObject(merged_f,split.by =  "dataset")

# run integration

IntM <- dataset_integration(list_seuratobjs=full.list,nfeats=10000,FindIntDims=1:15,FindInt_kScore=20,IntKweight=20)

# run umap
DefaultAssay(IntM) <- "integrated" 
IntM <- IntM %>% ScaleData(vars.to.regress="nFeature_RNA") %>% RunPCA %>% RunUMAP(dims = 1:25,return.model = TRUE,min.dist = 0.8,n.neighbors = 100,local.connectivity = 6)
DimPlot(IntM,group.by = "dataset",pt.size = 0.5 ) 
DimPlot(IntM,group.by = "age_ek",pt.size = 0.5, split.by = "dataset") 
DimPlot(IntM,group.by = "diff_ek",pt.size = 0.5 , split.by = "dataset") 


# save integration
#saveRDS(IntM,"out/dataset_integration/IntM.rds")

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #



















# PREPROCESSING ----
# filter objects in full.list to keep cells in esther selections and annotate by dataset and cell type and age groups defined by esther
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# store full.list into a new name, will be used for filtering
full.list_f <- full.list

# load lists of selected cells prepared by esther (all mouse cells selected and selected cells by dataset)
Sel_all_Ms <- read_csv("humous_v3/data/preprocessed_ek/SelectCells_all_Ms.csv") ; head(Sel_all_Ms)
Sel_Ad21 <- read_csv("humous_v3/data/preprocessed_ek/Ms/SelectCells_Ad21.csv") ; head(Sel_Ad21) ; dim(Sel_Ad21)
Sel_My17 <- read_csv("humous_v3/data/preprocessed_ek/Ms/SelectCells_My17.csv") ; head(Sel_My17) ; dim(Sel_My17)
Sel_LMl21 <- read_csv("humous_v3/data/preprocessed_ek/Ms/SelectCells_LMl21.csv") ; head(Sel_LMl21) ; dim(Sel_LMl21)
Sel_Jt19 <- read_csv("humous_v3/data/preprocessed_ek/Ms/SelectCells_Jt19.csv") ; head(Sel_Jt19) ; dim(Sel_Jt19)


# subset cells per dataset according to esther annotations
    # carefull to: A) check colnames have identical format
# Ad21
head(colnames(full.list_f$Ad21)) ; head(Sel_Ad21$x) ; table(Sel_Ad21$x %in% colnames(full.list_f$Ad21) ) # correct size (3078)
full.list_f$Ad21 <- subset(full.list_f$Ad21,cells=Sel_Ad21$x[Sel_Ad21$x %in% colnames(full.list_f$Ad21)]) ; full.list_f$Ad21$dataset <- "Ad21"
# My17
head(colnames(full.list_f$My17)) ; head(Sel_My17$x) ; table(Sel_My17$x %in% colnames(full.list_f$My17) ) # correct size (1442)
full.list_f$My17 <- subset(full.list_f$My17,cells=Sel_My17$x[Sel_My17$x %in% colnames(full.list_f$My17)]) ; full.list_f$My17$dataset <- "My17"
# LMl21
head(colnames(full.list_f$LMl21)) ; head(Sel_LMl21$x) ; table(Sel_LMl21$x %in% colnames(full.list_f$LMl21) ) # correct size (3185)
full.list_f$LMl21 <- subset(full.list_f$LMl21,cells=Sel_LMl21$x[Sel_LMl21$x %in% colnames(full.list_f$LMl21)]) ; full.list_f$LMl21$dataset <- "LMl21"
# Jt19
head(colnames(full.list_f$Jt19)) ; head(Sel_Jt19$x) ; table(Sel_Jt19$x %in% colnames(full.list_f$Jt19) ) # correct size (1438)
full.list_f$Jt19 <- subset(full.list_f$Jt19,cells=Sel_Jt19$x[Sel_Jt19$x %in% colnames(full.list_f$Jt19)]) ; full.list_f$Jt19$dataset <- "Jt19"

# load metadata on difftype and age prepared by esther (all cells, not only the ones selected)
annot_Ad21 <- read_csv("humous_v3/data/preprocessed_ek/Ms/DiffTypes_Ad21.csv") ; head(annot_Ad21) ; dim(annot_Ad21) ; table(annot_Ad21$age,annot_Ad21$DiffTypes,useNA="always") # more cells than selected
annot_My17 <- read_csv("humous_v3/data/preprocessed_ek/Ms/DiffTypes_My17.csv")  ; head(annot_My17) ; dim(annot_My17) ; table(annot_My17$age,annot_My17$DiffTypes,useNA="always") # more cells than selected
annot_LMl21 <- read_csv("humous_v3/data/preprocessed_ek/Ms/DiffTypes_LMl21.csv")  ; head(annot_LMl21) ; dim(annot_LMl21) ; table(annot_LMl21$age,annot_LMl21$DiffTypes,useNA="always") # more cells than selected
annot_Jt19 <- read_csv("humous_v3/data/preprocessed_ek/Ms/DiffTypes_Jt19.csv")  ; head(annot_Jt19) ; dim(annot_Jt19) ; table(annot_Jt19$age,annot_Jt19$DiffTypes,useNA="always") # more cells than selected


# annotate datasets by celltype and age vectors (matchs by name of cell)
    # make sure cells match
# Ad21
table(annot_Ad21$cells %in% colnames(full.list_f$Ad21) ) # correct size (3078)  
full.list_f$Ad21$age_ek <- annot_Ad21$age[match(colnames(full.list_f$Ad21),annot_Ad21$cells)]
full.list_f$Ad21$diff_ek <- annot_Ad21$DiffTypes[match(colnames(full.list_f$Ad21),annot_Ad21$cells)]
table(full.list_f$Ad21$age_ek,full.list_f$Ad21$diff_ek,useNA = "always") # all good
# My17
table(annot_My17$cells %in% colnames(full.list_f$My17) ) # correct size (1442)  
full.list_f$My17$age_ek <- annot_My17$age[match(colnames(full.list_f$My17),annot_My17$cells)]
full.list_f$My17$diff_ek <- annot_My17$DiffTypes[match(colnames(full.list_f$My17),annot_My17$cells)]
table(full.list_f$My17$age_ek,full.list_f$My17$diff_ek,useNA = "always") # all good
# LMl21
table(annot_LMl21$cells %in% colnames(full.list_f$LMl21) ) # correct size (3185)  
full.list_f$LMl21$age_ek <- annot_LMl21$age[match(colnames(full.list_f$LMl21),annot_LMl21$cells)]
full.list_f$LMl21$diff_ek <- annot_LMl21$DiffTypes[match(colnames(full.list_f$LMl21),annot_LMl21$cells)]
table(full.list_f$LMl21$age_ek,full.list_f$LMl21$diff_ek,useNA = "always") # all good
# Jt19
table(annot_Jt19$cells %in% colnames(full.list_f$Jt19) ) # correct size (1438)  
full.list_f$Jt19$age_ek <- annot_Jt19$age[match(colnames(full.list_f$Jt19),annot_Jt19$cells)]
full.list_f$Jt19$diff_ek <- annot_Jt19$DiffTypes[match(colnames(full.list_f$Jt19),annot_Jt19$cells)]
table(full.list_f$Jt19$age_ek,full.list_f$Jt19$diff_ek,useNA = "always") # all good


Sel_LMl21 <- read_csv("humous_v3/data/preprocessed_ek/Ms/SelectCells_LMl21.csv")
full.list_f$LMl21 <- subset(full.list_f$LMl21,cells=Sel_LMl21$x) ; full.list_f$LMl21$dataset <- "LMl21"
Sel_Jt19 <- read_csv("humous_v3/data/preprocessed_ek/Ms/SelectCells_Jt19.csv")
full.list_f$Jt19 <- subset(full.list_f$Jt19,cells=Sel_Jt19$x) ; full.list_f$Jt19$dataset <- "Jt19"

annot_Ad21 <- read_csv("humous_v3/data/preprocessed_ek/Ms/DiffTypes_Ad21.csv") 
full.list_f$Ad21$celltype_ek <- annot_Ad21$DiffTypes[match(colnames(full.list_f$Ad21),annot_Ad21$cells)] ; full.list_f$Ad21$age_ek <- annot_Ad21$age[match(colnames(full.list_f$Ad21),annot_Ad21$cells)]
table(full.list_f$Ad21$age_ek,full.list_f$Ad21$celltype_ek,useNA = "always")

annot_My17 <- read_csv("humous_v3/data/preprocessed_ek/Ms/DiffTypes_My17.csv") 
annot_My17$cells <- paste0(annot_My17$cells,"_E",gsub("\\..*","",annot_My17$age))
full.list_f$My17$celltype_ek <- annot_My17$DiffTypes[match(colnames(full.list_f$My17),annot_My17$cells)] ; full.list_f$My17$age_ek <- annot_My17$age[match(colnames(full.list_f$My17),annot_My17$cells)]
table(full.list_f$My17$age_ek,full.list_f$My17$celltype_ek,useNA = "always")

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #



# Run pairwise Seurat integration ----
    # finding anchors between all datasets
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# run integration

IntM <- pairwise_integration(list_seuratobjs=full.list_f,nfeats=10000,FindIntDims=1:15,FindInt_kScore=20,IntKweight=20)

# run umap
DefaultAssay(IntM) <- "integrated" 
IntM <- IntM %>% ScaleData(vars.to.regress="nFeature_RNA") %>% RunPCA %>% RunUMAP(dims = 1:25,return.model = TRUE,min.dist = 0.8,n.neighbors = 100,local.connectivity = 6)
DimPlot(IntM,group.by = "dataset",pt.size = 0.5 ) ; #ggsave("humous_v3/pdf/IntM/DimPlot_IntM_byDataset.pdf",useDingbats=FALSE)
DimPlot(IntM,group.by = "age_ek",pt.size = 0.5) ; #ggsave("humous_v3/pdf/IntM/DimPlot_IntM_byAge.pdf",useDingbats=FALSE)
DimPlot(IntM,group.by = "diff_ek",pt.size = 0.5) ; #ggsave("humous_v3/pdf/IntM/DimPlot_IntM_byDiff.pdf",useDingbats=FALSE)

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #





# Age & Diff Ordinal Regressions on integrated assay ----
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# Define grouping for ordinals and create integer labels
IntM$grouping_ordi <- paste0(IntM$age_ek,"_",IntM$diff_ek) ; table(IntM$grouping_ordi) 
# define integer label on age and diff levels (ages 16 and 17 same integer group)
IntM$y_age <- as.integer(as.character(plyr::revalue(as.character(IntM$age_ek),c("12"="1","13"="2","14"="3","15"="4","16"="5","17"="5"))))
IntM$y_diff <- as.integer(as.character(plyr::revalue(as.character(IntM$diff_ek),c("RG"="1","IPC"="2","N"="3")))) ; table(IntM$y_age,IntM$y_diff)
  
# cell selection for training ordinals (balanced by diff and age, not by dataset because this is regressed out in the integration)
# Paste y_age and y_diff for selecting a balanced n of cells per group
IntM$grouping_ordi <- paste0(IntM$y_age,"_",IntM$y_diff) ; table(IntM$grouping_ordi) # min n cells on the combination of these 2 variables is 183, take 150 per group for training
IntM_train <- cell.selector(seuratobject=IntM,cellnames=colnames(IntM),grouping=IntM$grouping_ordi,n=150) ; table(IntM_train$grouping_ordi) ; table(IntM_train$y_age,IntM_train$y_diff) 

# annotate in IntM_train which cells were used for training ordis
IntM$ordi_split <- ifelse(colnames(IntM) %in% colnames(IntM_train),"ordi_train","ordi_test")



# AGE 
#######################
fullAGE <- training_ordi_full(datamatrix=t(as.matrix(IntM_train@assays$integrated@scale.data)),
                              target=IntM_train$y_age,
                              cost=costM(X=t(as.matrix(IntM_train@assays$integrated@scale.data)),y=IntM_train$y_age),
                              lambda_full=0.05,epsilon_full=1e-7,maxiter=1000) 
# save full model
#saveRDS(fullAGE,"humous_v3/out/IntM/model_fullAGE_mouse.rds")

# predict all data and evaluate performance
redAGE <-  custom_red_and_pred(fullmodel=fullAGE,xtrain=t(as.matrix(IntM_train@assays$integrated@scale.data)),target=IntM_train$y_age,
                               xtest=t(as.matrix(IntM@assays$integrated@scale.data)),ngenesselect=25,lambda_red=0.01,epsilon_red=1e-7,maxiter=1000,nfolds=20)
# save reduced model
#saveRDS(redAGE$redmodel,"humous_v3/out/model_redAGE_mouse.rds")

# store prediction on df rescaled
predAGE <- data.frame( cellnames=c(names(redAGE$pred)), pred=c(scales::rescale(redAGE$pred,to=c(0,1))))

IntM$ordi_age <- predAGE$pred[match(colnames(IntM),predAGE$cellnames)]

metricsAGE <- as.data.frame(IntM@meta.data %>% dplyr::group_by(grouping_ordi) %>% summarise_at(vars(ordi_age), list(min=min,max=max,median=median,sd=sd)))

# visualize prediction
ggplot(IntM@meta.data) + geom_density(aes(ordi_age,color=as.character(y_age))) + facet_wrap(~y_diff,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiAGE_density_bydiff.pdf",useDingbats=FALSE)
ggplot(IntM@meta.data) + geom_point(aes(ordi_age,y="y",color=as.character(y_age))) + facet_wrap(~grouping_ordi,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiAGE_scatter_byagediff.pdf",useDingbats=FALSE)
ggplot(IntM@meta.data) + geom_density(aes(ordi_age,color=as.character(y_age))) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiAGE_density_byage.pdf",useDingbats=FALSE)
ggplot(IntM@meta.data,aes(x=ordi_age,y=y_age,color=as.character(y_age)))+ geom_jitter()  + geom_boxplot()  + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiAGE_jitterboxplot_byage.pdf",useDingbats=FALSE)
#######################



# DIFF 
#######################
fullDIFF <- training_ordi_full(datamatrix=t(as.matrix(IntM_train@assays$integrated@scale.data)),
                              target=IntM_train$y_diff,
                              cost=costM(X=t(as.matrix(IntM_train@assays$integrated@scale.data)),y=IntM_train$y_diff),
                              lambda_full=0.05,epsilon_full=1e-7,maxiter=1000) 
# save full model
#saveRDS(fullDIFF,"humous_v3/out/IntM/model_fullDIFF_mouse.rds")

# predict all data and evaluate performance
redDIFF <-  custom_red_and_pred(fullmodel=fullDIFF,xtrain=t(as.matrix(IntM_train@assays$integrated@scale.data)),target=IntM_train$y_diff,
                               xtest=t(as.matrix(IntM@assays$integrated@scale.data)),ngenesselect=25,lambda_red=0.01,epsilon_red=1e-7,maxiter=1000,nfolds=20)
# save reduced model
#saveRDS(redDIFF$redmodel,"humous_v3/out/model_redDIFF_mouse.rds")

# store prediction on df rescaled
predDIFF <- data.frame( cellnames=c(names(redDIFF$pred)), pred=c(scales::rescale(redDIFF$pred,to=c(0,1))))

IntM$ordi_diff <- predDIFF$pred[match(colnames(IntM),predDIFF$cellnames)]

metricsDIFF <- as.data.frame(IntM@meta.data %>% dplyr::group_by(grouping_ordi) %>% summarise_at(vars(ordi_diff), list(min=min,max=max,median=median,sd=sd)))

# visualize prediction
ggplot(IntM@meta.data) + geom_density(aes(ordi_diff,color=as.character(y_diff))) + facet_wrap(~y_age,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiDIFF_density_byage.pdf",useDingbats=FALSE)
ggplot(IntM@meta.data) + geom_point(aes(ordi_diff,y="y",color=as.character(y_diff))) + facet_wrap(~grouping_ordi,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiDIFF_scatter_byagediff.pdf",useDingbats=FALSE)
ggplot(IntM@meta.data) + geom_density(aes(ordi_diff,color=as.character(y_diff))) + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiDIFF_density_bydiff.pdf",useDingbats=FALSE)
ggplot(IntM@meta.data,aes(x=ordi_diff,y=y_diff,color=as.character(y_diff)))+ geom_jitter()  + geom_boxplot()  + theme_bw() ; #ggsave("humous_v3/pdf/IntM/ordiDIFF_jitterboxplot_bydiff.pdf",useDingbats=FALSE)
#######################

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# save IntM
#saveRDS(IntM,"humous_v3/out/IntM/IntM.rds")
####################################





# define number of points and radius of circle
n_points <- 500
radius <- 10

# generate random coordinates within a circle
theta <- runif(n_points, 0, 2*pi)
r <- runif(n_points, 0, radius)
circle_x <- r*cos(theta)
circle_y <- r*sin(theta)
circle_coords <- cbind(circle_x, circle_y)

ggplot(as.data.frame(circle_coords)) + geom_point(aes(circle_x,circle_y))


# rearrange circle coordinates into a rectangle
n_cols <- round(sqrt(n_points))
n_rows <- ceiling(n_points/n_cols)
rect_coords <- matrix(nrow = n_points, ncol = 2)
for (i in 1:n_cols) {
  for (j in 1:n_rows) {
    idx <- (j - 1)*n_cols + i
    if (idx <= n_points) {
      rect_coords[idx, ] <- c(i, j)
    }
  }
}
rect_coords <- (rect_coords - 0.5*n_cols)*2*radius/n_cols

ggplot(as.data.frame(rect_coords)) + geom_point(aes(V1,V2))



