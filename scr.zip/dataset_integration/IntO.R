
# HV3

# INTEGRATION OF ORGHUMAN DATASETS

source("humous_v3/lib/lib_misc.R")
library(Seurat) ; library(dplyr); library(readr) ; library(ggplot2) ; library(plyr) ; library(dplyr) ; library(scales) ; library(purrr)

# PIPELINE
# load raw datasets and filter cells in the range of interest for age (1m to maxE12 to E17) and celltype (RG IPC N)
# remove EPS cells
# select up to 6000 cells per age group randomly across datasets
# integrate them all - pairwise by dataset and protocol, scaling nfeats (these two sources of variation will be removed)
# re-define celltype groups based on integration - clusters & markers
# select balanced 

# load raw org datasets and join them in a list ----
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
full.list <- list(Av19=readRDS("~/humous/humous_v3/data/preprocessed_ek/Org/Av19.rds"),
                  Kp19=readRDS("~/humous/humous_v3/data/preprocessed_ek/Org/Kp19.rds"),
                  Pt20=readRDS("~/humous/humous_v3/data/preprocessed_ek/Org/Pt20.rds"),
                  Ck19=readRDS("~/humous/data/raw/Ck19/Ck19.rds"))
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


# load HumanInt with selected cells for landscapes ----
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
IntH <- readRDS("~/humous/humous_v3/out/ordiH/IntH_ordi_new.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


# filter cells on each dataset to keep ages and types of interest, annotate also by dataset and protocol (for integration)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# load annotations prepared by esther, filter and attach age and diff vectors

DiffTypes_org <- read_csv("humous_v3/data/preprocessed_ek/Org/DiffTypes_org.csv")
dim(DiffTypes_org) ; table(DiffTypes_org$age,DiffTypes_org$DiffTypes,DiffTypes_org$dataset,useNA="always") ; table(DiffTypes_org$proto,DiffTypes_org$dataset)
# as we don't have certainty for all and since umap is homogeneous, we disregard information about linw if ESC or iPS
# cells of interest: diff = RG, IPC, N ; age = 1-2 m, 2-3 m, 3 m, 3.5-5 m, 6-7 m

# Av19
# keep cell types and ages of interest 
  # in DiffTypes_org all cells are of ages we want but not the cell types. Keep RG, IPC and N, Remove those that are NA (no cell type could be assigned) or IN, CR
full.list$Av19$age_ek <- DiffTypes_org$age[match(colnames(full.list$Av19),DiffTypes_org$cells)]
full.list$Av19$diff_ek <- DiffTypes_org$DiffTypes[match(colnames(full.list$Av19),DiffTypes_org$cells)]
full.list$Av19$protocol <- DiffTypes_org$proto[match(colnames(full.list$Av19),DiffTypes_org$cells)]
full.list$Av19$dataset <- "Av19"
full.list$Av19$dataset_proto <- paste0("Av19_",full.list$Av19$protocol)
full.list$Av19 <- subset(full.list$Av19,diff_ek %in% c("RG","IPC","N") & age_ek %in% c("1-2 m","2-3 m","3 m","3.5-5 m","6-7 m"))
table(full.list$Av19$age_ek,full.list$Av19$diff_ek,useNA = "always") ; table(full.list$Av19$dataset)

# Kp19
full.list$Kp19$age_ek <- DiffTypes_org$age[match(colnames(full.list$Kp19),DiffTypes_org$cells)]
full.list$Kp19$diff_ek <- DiffTypes_org$DiffTypes[match(colnames(full.list$Kp19),DiffTypes_org$cells)]
full.list$Kp19$protocol <- DiffTypes_org$proto[match(colnames(full.list$Kp19),DiffTypes_org$cells)]
full.list$Kp19$dataset <- "Kp19"
full.list$Kp19$dataset_proto <- paste0("Kp19_",full.list$Kp19$protocol)
full.list$Kp19 <- subset(full.list$Kp19,diff_ek %in% c("RG","IPC","N") & age_ek %in% c("1-2 m","2-3 m","3 m","3.5-5 m","6-7 m"))
table(full.list$Kp19$age_ek,full.list$Kp19$diff_ek,useNA = "always") ; table(full.list$Kp19$dataset)

# Ck19
full.list$Ck19$age_ek <- DiffTypes_org$age[match(colnames(full.list$Ck19),DiffTypes_org$cells)]
full.list$Ck19$diff_ek <- DiffTypes_org$DiffTypes[match(colnames(full.list$Ck19),DiffTypes_org$cells)]
full.list$Ck19$protocol <- DiffTypes_org$proto[match(colnames(full.list$Ck19),DiffTypes_org$cells)]
full.list$Ck19$dataset <- "Ck19"
full.list$Ck19$dataset_proto <- paste0("Ck19_",full.list$Ck19$protocol)
full.list$Ck19 <- subset(full.list$Ck19,diff_ek %in% c("RG","IPC","N") & age_ek %in% c("1-2 m","2-3 m","3 m","3.5-5 m","6-7 m"))
table(full.list$Ck19$age_ek,full.list$Ck19$diff_ek,useNA = "always") ; table(full.list$Ck19$dataset)

# Pt20
full.list$Pt20$age_ek <- DiffTypes_org$age[match(colnames(full.list$Pt20),DiffTypes_org$cells)]
full.list$Pt20$diff_ek <- DiffTypes_org$DiffTypes[match(colnames(full.list$Pt20),DiffTypes_org$cells)]
full.list$Pt20$protocol <- DiffTypes_org$proto[match(colnames(full.list$Pt20),DiffTypes_org$cells)]
full.list$Pt20$dataset <- "Pt20"
full.list$Pt20$dataset_proto <- paste0("Pt20_",full.list$Pt20$protocol)
full.list$Pt20 <- subset(full.list$Pt20,diff_ek %in% c("RG","IPC","N") & age_ek %in% c("1-2 m","2-3 m","3 m","3.5-5 m","6-7 m"))
table(full.list$Pt20$age_ek,full.list$Pt20$diff_ek,useNA = "always") ; table(full.list$Pt20$dataset)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #



# CELL SELECTION FOR INTEGRATION ----
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
# as integration will balance by dataset/protocol, and cell types will be redefined based on integration, select based on age

# AGE SELECTION notes:
# aim at getting 30000 cells. Normally, the MAX n cells to keep per age is 6000 when possible if a lot of cells in an age group, balance by dataset.
# for age 3.5-5 m we just have 599 cells. To compensate, I'll take 2701 extra cells from neighboring ages (3 m and 6-7 m)
# for age 1-2 m we just have 5706, to compensate, I'll take 294 extra from 2-3 m.


mergedO <- merge(full.list$Av19,list(full.list$Kp19,full.list$Pt20,full.list$Ck19))
table(mergedO$age_ek,mergedO$dataset,useNA = "always")
table(mergedO$age_ek,mergedO$dataset_proto,useNA = "always")
table(mergedO$age_ek,mergedO$diff_ek,useNA = "always")


# SELECTION

# first subset, ages that we take all cells
mergedO_f1 <- subset(mergedO,  age_ek %in% c("1-2 m","3.5-5 m")  )

# second subset, ages from which we take 8701 cells balanced by dataset
# 3 m
mergedO_f2 <- subset(mergedO,  age_ek %in% c("3 m","6-7 m")  )
mergedO_f2$age_dataset <- paste(mergedO_f2$age_ek,mergedO_f2$dataset) ; print(table(mergedO_f2$age_dataset))
# for Kp19 only 117, those take them all
mergedO_f2_f1 <- subset(mergedO_f2,age_dataset=="6-7 m Kp19")
# for other 4 datasets, take ((8701*2)-117)/4=4322 on each
print(table(mergedO_f2$age_dataset))
mergedO_f2_f2 <- cell.selector(subset(mergedO_f2,age_dataset!="6-7 m Kp19"),
                               colnames(subset(mergedO_f2,age_dataset!="6-7 m Kp19")),
                               subset(mergedO_f2,age_dataset!="6-7 m Kp19")$age_dataset,4322)
mergedO_f2 <- merge(mergedO_f2_f1,mergedO_f2_f2) ; table(mergedO_f2$age_dataset)

# third subset, age 2-3 m, from which we need to take 6294 cells balanced by dataset
mergedO_f3 <- subset(mergedO,  age_ek %in% c("2-3 m"))
mergedO_f3$age_dataset <- paste(mergedO_f3$age_ek,mergedO_f3$dataset) ; print(table(mergedO_f3$age_dataset))
# for Kp19 only 700 cells and from Ck19 only 1955, take them all cause 6294/3=2098
mergedO_f3_f1 <- subset(mergedO_f3,age_dataset %in% c("2-3 m Kp19","2-3 m Ck19"))
# for Pt20, to compensate, take 6294-2655=3639 cells
mergedO_f3_f2 <- cell.selector(subset(mergedO_f3,age_dataset=="2-3 m Pt20"),
                               colnames(subset(mergedO_f3,age_dataset=="2-3 m Pt20")),
                               subset(mergedO_f3,age_dataset=="2-3 m Pt20")$age_dataset,3639)
mergedO_f3 <- merge(mergedO_f3_f1,mergedO_f3_f2) ; table(mergedO_f3$age_dataset)


# NOW ASSEMBLE ALL SUBSETS
mergedO_f <- merge(mergedO_f1,list(mergedO_f2,mergedO_f3))
# check cell numbers are ok
table(mergedO_f$age_ek,useNA = "always")

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #



# INTEGRATION - HUMAN INT OBJECT AS REFERENCE!!
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# define new seurat object with integrated data assay as counts and data
IntH2 <- CreateSeuratObject(counts=IntH@assays$integrated@data,meta.data = IntH@meta.data)
IntH2@assays$RNA@data <- IntH2@assays$RNA@counts
IntH2$dataset_proto <- "IntH2"
DefaultAssay(IntH2) <- "RNA" ; IntH2[['integrated']] <- NULL

# merge human and orgs and group org datasets that are not from metanalysis
merged <- merge(IntH2,mergedO_f)
merged$dataset_proto2 <- ifelse(grepl("Kp19",merged$dataset_proto),"Kp19",ifelse(grepl("Av19",merged$dataset_proto),"Av19",as.character(merged$dataset_proto)))
table(merged$dataset_proto2,merged$age_ek,useNA = "always")

# create list with independent object split by integration variable
full.list <- SplitObject(merged,split.by =  "dataset_proto2") 


# normalize org datasets but not human (else the integration will be undone)
for (i in 2:length(full.list)) {
  full.list[[i]] <- NormalizeData(full.list[[i]], verbose = FALSE)
}

# find variable features in all (although in human we'll consider only the 2000 used previously - integrated genes)
for (i in 1:length(full.list)) {
  full.list[[i]] <- FindVariableFeatures(full.list[[i]], selection.method = "mvp",nfeatures=10000, verbose = FALSE)
}

# find which genes of human integration are also present in all org datasets
features <- Reduce(intersect,list(rownames(IntH2),rownames(full.list$Av19),rownames(full.list$Ck19),rownames(full.list$Kp19),rownames(full.list$Pt20_Xiang)))


# run integration of integration
IntHO <- double_dataset_integration(list_seuratobjs=full.list,nfeats=10000,FindIntDims=1:15,FindInt_kScore=20,IntKweight=20,reference_dataset="IntH2",features=features)


# scale nFeature_RNA and calculate UMAP 
DefaultAssay(IntHO) <- "integrated" 
IntHO <- IntHO %>% ScaleData(vars.to.regress="nFeature_RNA") %>% RunPCA %>% RunUMAP(dims = 1:25,return.model = TRUE,min.dist = 0.5,n.neighbors = 50,local.connectivity = 6)
DimPlot(IntHO,group.by = "dataset_proto2",pt.size = 0.5,split.by = "dataset" )
DimPlot(IntHO,group.by = "age_ek",pt.size = 0.5,split.by = "dataset_proto2")
DimPlot(IntHO,group.by = "diff_ek",pt.size = 0.5,split.by = "dataset_proto2") 

# save result
#saveRDS(IntHO,"humous_v3/out/IntO/IntHO.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


















# OTHER TRIALS


# CELL SELECTION FOR INTEGRATION ----
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
# as integration will balance by dataset/protocol, and cell types will be redefined based on integration, select based on age

# AGE SELECTION notes:
    # aim at getting 30000 cells. Normally, the MAX n cells to keep per age is 6000 when possible if a lot of cells in an age group, balance by dataset.
        # for age 3.5-5 m we just have 599 cells. To compensate, I'll take 2701 extra cells from neighboring ages (3 m and 6-7 m)
        # for age 1-2 m we just have 5706, to compensate, I'll take 294 extra from 2-3 m.


mergedO <- merge(full.list$Av19,list(full.list$Kp19,full.list$Pt20,full.list$Ck19))
table(mergedO$age_ek,mergedO$dataset,useNA = "always")
table(mergedO$age_ek,mergedO$dataset_proto,useNA = "always")
table(mergedO$age_ek,mergedO$diff_ek,useNA = "always")


# SELECTION

# first subset, ages that we take all cells
mergedO_f1 <- subset(mergedO,  age_ek %in% c("1-2 m","3.5-5 m")  )

# second subset, ages from which we take 8701 cells balanced by dataset
# 3 m
mergedO_f2 <- subset(mergedO,  age_ek %in% c("3 m","6-7 m")  )
mergedO_f2$age_dataset <- paste(mergedO_f2$age_ek,mergedO_f2$dataset) ; print(table(mergedO_f2$age_dataset))
# for Kp19 only 117, those take them all
mergedO_f2_f1 <- subset(mergedO_f2,age_dataset=="6-7 m Kp19")
# for other 4 datasets, take ((8701*2)-117)/4=4322 on each
print(table(mergedO_f2$age_dataset))
mergedO_f2_f2 <- cell.selector(subset(mergedO_f2,age_dataset!="6-7 m Kp19"),
                              colnames(subset(mergedO_f2,age_dataset!="6-7 m Kp19")),
                              subset(mergedO_f2,age_dataset!="6-7 m Kp19")$age_dataset,4322)
mergedO_f2 <- merge(mergedO_f2_f1,mergedO_f2_f2) ; table(mergedO_f2$age_dataset)

# third subset, age 2-3 m, from which we need to take 6294 cells balanced by dataset
mergedO_f3 <- subset(mergedO,  age_ek %in% c("2-3 m"))
mergedO_f3$age_dataset <- paste(mergedO_f3$age_ek,mergedO_f3$dataset) ; print(table(mergedO_f3$age_dataset))
# for Kp19 only 700 cells and from Ck19 only 1955, take them all cause 6294/3=2098
mergedO_f3_f1 <- subset(mergedO_f3,age_dataset %in% c("2-3 m Kp19","2-3 m Ck19"))
# for Pt20, to compensate, take 6294-2655=3639 cells
mergedO_f3_f2 <- cell.selector(subset(mergedO_f3,age_dataset=="2-3 m Pt20"),
                               colnames(subset(mergedO_f3,age_dataset=="2-3 m Pt20")),
                               subset(mergedO_f3,age_dataset=="2-3 m Pt20")$age_dataset,3639)
mergedO_f3 <- merge(mergedO_f3_f1,mergedO_f3_f2) ; table(mergedO_f3$age_dataset)


# NOW ASSEMBLE ALL SUBSETS
mergedO_f <- merge(mergedO_f1,list(mergedO_f2,mergedO_f3))
# check cell numbers are ok
table(mergedO_f$age_ek,useNA = "always")

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #



# Run Seurat INTEGRATION ----
# Orgs are an exception, here no pairwise because else, we remove age differences
# Using Kp19 as reference to integrate other datasets (cause it contains cells across ages and the most used org protocol)
# scaling on nfeats
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

table(mergedO$dataset_proto,useNA = "always")

# pull kp19 protos so I use it as ref
mergedO$dataset_proto2 <- ifelse(grepl("Kp19",mergedO$dataset_proto),"Kp19",ifelse(grepl("Av19",mergedO$dataset_proto),"Av19",as.character(mergedO$dataset_proto)))
table(mergedO$dataset_proto2,mergedO$age_ek,useNA = "always")

full.list <- SplitObject(mergedO,split.by =  "dataset_proto2") 

IntO <- dataset_integration(list_seuratobjs=full.list,nfeats=10000,FindIntDims=1:15,FindInt_kScore=20,IntKweight=20,reference_dataset="Kp19")


# run umap
DefaultAssay(IntO) <- "integrated" 
IntO <- IntO %>% ScaleData(vars.to.regress="nFeature_RNA") %>% RunPCA %>% RunUMAP(dims = 1:25,return.model = TRUE,min.dist = 0.5,n.neighbors = 50,local.connectivity = 6)
DimPlot(IntO,group.by = "dataset_proto2",pt.size = 0.5,split.by = "dataset" )
DimPlot(IntO,group.by = "age_ek",pt.size = 0.5,split.by = "dataset")
DimPlot(IntO,group.by = "diff_ek",pt.size = 0.5,split.by = "dataset") 

table(IntO$age_ek,IntO$diff_ek)

# save integration
#saveRDS(IntO,"humous_v3/out/IntO/IntO.rds")

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #







# OTHER THINGS








# PREPROCESSING ----
# filter objects in full.list to keep cells in esther selections and annotate by dataset and cell type and age groups defined by esther
# attention, dataset annotation for organoids needs to consider also information on protocol, I can find it in DiffTypes tables
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# store full.list into a new name, will be used for filtering
full.list_f <- full.list

# load lists of selected cells prepared by esther (all mouse cells selected and selected cells by dataset)
Sel_all_Org <- read_csv("humous_v3/data/preprocessed_ek/SelectCells_all_Org.csv") ; head(Sel_all_Org) 

# subset cells per dataset according to esther annotations
# carefull to: A) check colnames have identical format
# Av19
head(colnames(full.list_f$Av19)) ; head(Sel_all_Org$x) ; table(Sel_all_Org$x %in% colnames(full.list_f$Av19) ) # correct size (2861)
full.list_f$Av19 <- subset(full.list_f$Av19,cells=Sel_all_Org$x[Sel_all_Org$x %in% colnames(full.list_f$Av19)]) 
DiffTypes_Av19 <- read_csv("humous_v3/data/preprocessed_ek/Org/DiffTypes_Av19.csv")
full.list_f$Av19$Protocol <- DiffTypes_Av19$proto[match(colnames(full.list_f$Av19),DiffTypes_Av19$cells)] ; table(full.list_f$Av19$Protocol,useNA="always")
full.list_f$Av19$dataset <- paste0("Av19","_",full.list_f$Av19$Protocol)  ; table(full.list_f$Av19$dataset,useNA="always")

# Kp19
head(colnames(full.list_f$Kp19)) ; head(Sel_all_Org$x) ; table(Sel_all_Org$x %in% colnames(full.list_f$Kp19) ) # correct size (1344)
full.list_f$Kp19 <- subset(full.list_f$Kp19,cells=Sel_all_Org$x[Sel_all_Org$x %in% colnames(full.list_f$Kp19)]) 
# here all cells are iPS
full.list_f$Kp19$dataset <-  paste0("Kp19","_","iPS") ;  table(full.list_f$Kp19$dataset,useNA="always")

# Pt20
head(colnames(full.list_f$Pt20)) ; head(Sel_all_Org$x) ; table(Sel_all_Org$x %in% colnames(full.list_f$Pt20) ) # correct size (5520)
full.list_f$Pt20 <- subset(full.list_f$Pt20,cells=Sel_all_Org$x[Sel_all_Org$x %in% colnames(full.list_f$Pt20)]) ; full.list_f$Pt20$dataset <- "Pt20"
# here there is a vector of protocol already, all should be iPS but we want to keep the dataset names for protocol because there are huge batch effects
table(full.list_f$Pt20$Protocol)
full.list_f$Pt20$dataset <-  paste0("Pt20","_",full.list_f$Pt20$Protocol) ; table(full.list_f$Pt20$dataset,useNA="always")

# load metadata on difftype and age prepared by esther (all cells, not only the ones selected)
annot_Av19 <- read_csv("humous_v3/data/preprocessed_ek/Org/DiffTypes_Av19.csv") ; head(annot_Av19) ; dim(annot_Av19) ; table(annot_Av19$age,annot_Av19$DiffTypes,useNA="always") # more cells than selected
annot_Kp19 <- read_csv("humous_v3/data/preprocessed_ek/Org/DiffTypes_Kp19.csv")  ; head(annot_Kp19) ; dim(annot_Kp19) ; table(annot_Kp19$age,annot_Kp19$DiffTypes,useNA="always") # more cells than selected
annot_Pt20 <- read_csv("humous_v3/data/preprocessed_ek/Org/DiffTypes_Pt20.csv")  ; head(annot_Pt20) ; dim(annot_Pt20) ; table(annot_Pt20$age,annot_Pt20$DiffTypes,useNA="always") # more cells than selected


# annotate datasets by celltype and age vectors (matchs by name of cell)
# make sure cells match
# Av19
table(annot_Av19$cells %in% colnames(full.list_f$Av19) ) # correct size (2861)  
full.list_f$Av19$age_ek <- annot_Av19$age[match(colnames(full.list_f$Av19),annot_Av19$cells)]
full.list_f$Av19$diff_ek <- annot_Av19$DiffTypes[match(colnames(full.list_f$Av19),annot_Av19$cells)]
table(full.list_f$Av19$age_ek,full.list_f$Av19$diff_ek,useNA = "always") # all good
# Kp19
table(annot_Kp19$cells %in% colnames(full.list_f$Kp19) ) # correct size (1344)  
full.list_f$Kp19$age_ek <- annot_Kp19$age[match(colnames(full.list_f$Kp19),annot_Kp19$cells)]
full.list_f$Kp19$diff_ek <- annot_Kp19$DiffTypes[match(colnames(full.list_f$Kp19),annot_Kp19$cells)]
table(full.list_f$Kp19$age_ek,full.list_f$Kp19$diff_ek,useNA = "always") # >8 m cells need to be removed
full.list_f$Kp19 <- subset(full.list_f$Kp19, age_ek!=">8 m")
# Pt20
table(annot_Pt20$cells %in% colnames(full.list_f$Pt20) ) # correct size (5520)  
full.list_f$Pt20$age_ek <- annot_Pt20$age[match(colnames(full.list_f$Pt20),annot_Pt20$cells)]
full.list_f$Pt20$diff_ek <- annot_Pt20$DiffTypes[match(colnames(full.list_f$Pt20),annot_Pt20$cells)]
table(full.list_f$Pt20$age_ek,full.list_f$Pt20$diff_ek,useNA = "always") # all good

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #



# Run pairwise Seurat integration ----
# finding anchors between all datasets/protocols and scaling on nfeats
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# I need to split full.list_f by the dataset variable
full.list_f2 <- local({
  Av19list <- SplitObject(full.list_f$Av19, split.by = "dataset")
  # Kp19 is just one dataset type
  Pt20list <- SplitObject(full.list_f$Pt20, split.by = "dataset")
  full.list_f2 <- list(c(Av19list,Kp19_iPS=full.list_f$Kp19,Pt20list))
  full.list_f2 <- unlist(full.list_f2) # unlist because ifnot is a list of lists
}) ; names(full.list_f2)


IntO <- pairwise_integration(list_seuratobjs=full.list_f2,nfeats=10000,FindIntDims=1:15,FindInt_kScore=20,IntKweight=20)

# run umap
DefaultAssay(IntO) <- "integrated" 
IntO <- IntO %>% ScaleData(vars.to.regress="nFeature_RNA") %>% RunPCA %>% RunUMAP(dims = 1:25,return.model = TRUE,min.dist = 0.5,n.neighbors = 50,local.connectivity = 6)
DimPlot(IntO,group.by = "dataset",pt.size = 0.5 ) ; ggsave("humous_v3/pdf/IntO/DimPlot_IntO_byDataset.pdf",useDingbats=FALSE)
DimPlot(IntO,group.by = "age_ek",pt.size = 0.5) ; ggsave("humous_v3/pdf/IntO/DimPlot_IntO_byAge.pdf",useDingbats=FALSE)
DimPlot(IntO,group.by = "diff_ek",pt.size = 0.5) ; ggsave("humous_v3/pdf/IntO/DimPlot_IntO_byDiff.pdf",useDingbats=FALSE)
DimPlot(IntO,group.by = "Protocol",pt.size = 0.5) ; ggsave("humous_v3/pdf/IntO/DimPlot_IntO_byProt.pdf",useDingbats=FALSE)

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #



# Age & Diff Ordinal Regressions on integrated assay ----
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# Define grouping for ordinals and create integer labels
IntO$grouping_ordi <- paste0(IntO$age_ek,"_",IntO$diff_ek) ; table(IntO$grouping_ordi) 
# define integer label on age and diff levels
IntO$y_age <- as.integer(as.character(plyr::revalue(as.character(IntO$age_ek),c("1-2 m"="1","2-3 m"="2","3-4 m"="3","4-5 m"="4","5-6 m"="4","6-7 m"="5"))))
IntO$y_diff <- as.integer(as.character(plyr::revalue(as.character(IntO$diff_ek),c("RG"="1","IPC"="2","N"="3")))) ; table(IntO$y_age,IntO$y_diff)

# cell selection for training ordinals (balanced by diff and age, not by dataset because this is regressed out in the integration)
# Paste y_age and y_diff for selecting a balanced n of cells per group
IntO$grouping_ordi <- paste0(IntO$y_age,"_",IntO$y_diff) ; table(IntO$grouping_ordi) # min n cells on the combination of these 2 variables is 111, take 100 per group for training
IntO_train <- cell.selector(seuratobject=IntO,cellnames=colnames(IntO),grouping=IntO$grouping_ordi,n=100) ; table(IntO_train$grouping_ordi) ; table(IntO_train$y_age,IntO_train$y_diff) 

# annotate in IntO which cells were used for training ordis (those in IntO_train)
IntO$ordi_split <- ifelse(colnames(IntO) %in% colnames(IntO_train),"ordi_train","ordi_test")


# AGE 
#######################
fullAGE <- training_ordi_full(datamatrix=t(as.matrix(IntO_train@assays$integrated@scale.data)),
                              target=IntO_train$y_age,
                              cost=costM(X=t(as.matrix(IntO_train@assays$integrated@scale.data)),y=IntO_train$y_age),
                              lambda_full=0.05,epsilon_full=1e-7,maxiter=1000) 
# save full model
#saveRDS(fullAGE,"humous_v3/out/IntO/model_fullAGE_orghuman.rds")

# predict all data and evaluate performance
redAGE <-  custom_red_and_pred(fullmodel=fullAGE,xtrain=t(as.matrix(IntO_train@assays$integrated@scale.data)),target=IntO_train$y_age,
                               xtest=t(as.matrix(IntO@assays$integrated@scale.data)),ngenesselect=25,lambda_red=0.05,epsilon_red=1e-7,maxiter=1000,nfolds=20)
# save reduced model
#saveRDS(redAGE$redmodel,"humous_v3/out/IntO/model_redAGE_orghuman.rds")

# store prediction on df rescaled
predAGE <- data.frame( cellnames=c(names(redAGE$pred)), pred=c(scales::rescale(redAGE$pred,to=c(0,1))))

IntO$ordi_age <- predAGE$pred[match(colnames(IntO),predAGE$cellnames)]

metricsAGE <- as.data.frame(IntO@meta.data %>% dplyr::group_by(grouping_ordi) %>% summarise_at(vars(ordi_age), list(min=min,max=max,median=median,sd=sd)))

# visualize prediction
ggplot(IntO@meta.data) + geom_density(aes(ordi_age,color=as.character(y_age))) + facet_wrap(~y_diff,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntO/ordiAGE_density_bydiff.pdf",useDingbats=FALSE)
ggplot(IntO@meta.data) + geom_point(aes(ordi_age,y="y",color=as.character(y_age))) + facet_wrap(~grouping_ordi,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntO/ordiAGE_scatter_byagediff.pdf",useDingbats=FALSE)
ggplot(IntO@meta.data) + geom_density(aes(ordi_age,color=as.character(y_age))) + theme_bw() ; #ggsave("humous_v3/pdf/IntO/ordiAGE_density_byage.pdf",useDingbats=FALSE)
ggplot(IntO@meta.data,aes(x=ordi_age,y=y_age,color=as.character(y_age)))+ geom_jitter()  + geom_boxplot() + facet_wrap(~y_diff,ncol=1)  + theme_bw() ; #ggsave("humous_v3/pdf/IntO/ordiAGE_jitterboxplot_byage.pdf",useDingbats=FALSE)
#######################



# DIFF 
#######################
fullDIFF <- training_ordi_full(datamatrix=t(as.matrix(IntO_train@assays$integrated@scale.data)),
                               target=IntO_train$y_diff,
                               cost=costM(X=t(as.matrix(IntO_train@assays$integrated@scale.data)),y=IntO_train$y_diff),
                               lambda_full=0.5,epsilon_full=1e-7,maxiter=1000) 
# save full model
#saveRDS(fullDIFF,"humous_v3/out/IntO/model_fullDIFF_orghuman.rds")

# predict all data and evaluate performance
redDIFF <-  custom_red_and_pred(fullmodel=fullDIFF,xtrain=t(as.matrix(IntO_train@assays$integrated@scale.data)),target=IntO_train$y_diff,
                                xtest=t(as.matrix(IntO@assays$integrated@scale.data)),ngenesselect=25,lambda_red=0.05,epsilon_red=1e-7,maxiter=1000,nfolds=20)
# save reduced model
#saveRDS(redDIFF$redmodel,"humous_v3/out/IntO/model_redDIFF_orghuman.rds")

# store prediction on df rescaled
predDIFF <- data.frame( cellnames=c(names(redDIFF$pred)), pred=c(scales::rescale(redDIFF$pred,to=c(0,1))))

IntO$ordi_diff <- predDIFF$pred[match(colnames(IntO),predDIFF$cellnames)]

metricsDIFF <- as.data.frame(IntO@meta.data %>% dplyr::group_by(grouping_ordi) %>% summarise_at(vars(ordi_diff), list(min=min,max=max,median=median,sd=sd)))

# visualize prediction
ggplot(IntO@meta.data) + geom_density(aes(ordi_diff,color=as.character(y_diff))) + facet_wrap(~y_age,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntO/ordiDIFF_density_byage.pdf",useDingbats=FALSE)
ggplot(IntO@meta.data) + geom_point(aes(ordi_diff,y="y",color=as.character(y_diff))) + facet_wrap(~grouping_ordi,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntO/ordiDIFF_scatter_byagediff.pdf",useDingbats=FALSE)
ggplot(IntO@meta.data) + geom_density(aes(ordi_diff,color=as.character(y_diff))) + theme_bw() ; #ggsave("humous_v3/pdf/IntO/ordiDIFF_density_bydiff.pdf",useDingbats=FALSE)
ggplot(IntO@meta.data,aes(x=ordi_diff,y=y_diff,color=as.character(y_diff)))+ geom_jitter()  + geom_boxplot()  + theme_bw() ; #ggsave("humous_v3/pdf/IntO/ordiDIFF_jitterboxplot_bydiff.pdf",useDingbats=FALSE)
#######################

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# save IntO
#saveRDS(IntO,"humous_v3/out/IntO/IntO.rds")
####################################







# AGE - one model per diff group
####################################

IntO_train <- subset(IntO,ordi_split=="ordi_train")

# FOR EACH DIFF GROUP, CALCULATE AGE ORDI
fullAGE_list <- list() 
redAGE_list <- list()
for (i in levels(as.factor(IntO$y_diff))){
  fullAGE_list[[i]] <- training_ordi_full(datamatrix=t(as.matrix(IntO_train@assays$integrated@scale.data[,colnames(IntO_train)[IntO_train$y_diff==i]])),target=IntO_train$y_age[IntO_train$y_diff==i],
                                          cost=costM(X=t(as.matrix(IntO_train@assays$integrated@scale.data[,colnames(IntO_train)[IntO_train$y_diff==i]])),y=IntO_train$y_age[IntO_train$y_diff==i]),
                                          lambda_full=1,epsilon_full=1e-7,maxiter=1000) 
  
  redAGE_list[[i]] <-  custom_red_and_pred(fullmodel=fullAGE_list[[i]],xtrain=t(as.matrix(IntO_train@assays$integrated@scale.data[,colnames(IntO_train)[IntO_train$y_diff==i]])),target=IntO_train$y_age[IntO_train$y_diff==i],
                                      xtest=t(as.matrix(IntO@assays$integrated@scale.data[,colnames(IntO)[IntO$y_diff==i]])),ngenesselect=25,lambda_red=0.05,epsilon_red=1e-7,maxiter=1000,nfolds=2)
}

# ASSEMBLE AGE ORDIS & CORRECT BY MODEL SD (per diff group) 
predAGE <- (apply(t(redAGE_list %>% map(~.x$pred) %>% bind_rows()),1, function(x) paste(na.omit(x),collapse="") ))
IntO$ordi_age_2 <- as.numeric(predAGE)[match(colnames(IntO),names(predAGE))]
IntO$ordi_age_3 <- rep(-5.1,length(colnames(IntO)))
for (i in levels(as.factor(IntO$y_diff))){
  IntO$ordi_age_3[IntO$y_diff==i] <- ( IntO$ordi_age_2[IntO$y_diff==i]  ) / sd(IntO$ordi_age_2[IntO$y_diff==i])
}

# visualize results
ggplot(IntO@meta.data) + geom_density(aes(ordi_age_2,color=as.character(y_age))) + facet_wrap(~y_diff,ncol=1) + theme_bw() 

ggplot(IntO@meta.data) + geom_point(aes(ordi_age,y="y",color=as.character(y_age))) + facet_wrap(~grouping_ordi,ncol=1) + theme_bw() ; #ggsave("humous_v3/pdf/IntO/ordiAGE_scatter_byagediff.pdf",useDingbats=FALSE)
ggplot(IntO@meta.data) + geom_density(aes(ordi_age,color=as.character(y_age))) + theme_bw() ; #ggsave("humous_v3/pdf/IntO/ordiAGE_density_byage.pdf",useDingbats=FALSE)
ggplot(IntO@meta.data,aes(x=ordi_age,y=y_age,color=as.character(y_age)))+ geom_jitter()  + geom_boxplot()  + theme_bw() ; #ggsave("humous_v3/pdf/IntO/ordiAGE_jitterboxplot_byage.pdf",useDingbats=FALSE)

####################################




# DIFF 
####################################

# FOR EACH DIFF GROUP, CALCULATE AGE ORDI
fullDIFF_list <- list()
redDIFF_list <- list()
for (i in levels(as.factor(IntO_train$y_age))){
  print(table(IntO_train$y_age[IntO_train$y_age==i],IntO_train$y_diff[IntO_train$y_age==i]))
  fullDIFF_list[[i]] <- training_ordi_full(datamatrix=t(as.matrix(IntO_train@assays$integrated@scale.data[,colnames(IntO_train)[IntO_train$y_age==i]])),target=IntO_train$y_diff[IntO_train$y_age==i],
                                          cost=costM(X=t(as.matrix(IntO_train@assays$integrated@scale.data[,colnames(IntO_train)[IntO_train$y_age==i]])),y=IntO_train$y_diff[IntO_train$y_age==i]),
                                          lambda_full=1,epsilon_full=1e-5,maxiter=1000) 
  
  redDIFF_list[[i]] <-  custom_red_and_pred(fullmodel=fullDIFF_list[[i]],xtrain=t(as.matrix(IntO_train@assays$integrated@scale.data[,colnames(IntO_train)[IntO_train$y_age==i]])),target=IntO_train$y_diff[IntO_train$y_age==i],
                                           xtest=t(as.matrix(IntO@assays$integrated@scale.data[,colnames(IntO)[IntO$y_age==i]])),ngenesselect=20,lambda_red=10,epsilon_red=1e-7,maxiter=2000,nfolds=2)
}


# ASSEMBLE DIFF ORDIS & CORRECT BY MODEL SD (per diff group) 
predDIFF <- (apply(t(redDIFF_list %>% map(~.x$pred) %>% bind_rows()),1, function(x) paste(na.omit(x),collapse="") ))
IntO$ordi_diff_2 <- as.numeric(predDIFF)[match(colnames(IntO),names(predDIFF))]

diffcuts <- cut(IntO$ordi_diff_2, length(levels(as.factor(IntO$y_diff))) )


IntO$ordi_diff_3 <- rep(-5.1,length(colnames(IntO)))
for (i in levels(as.factor(IntO$y_diff))){
  #binlength <- 1/length(levels(as.factor(IntO$y_diff)))
  #IntO$ordi_diff_3[IntO$y_diff==i] <- ( IntO$ordi_diff_2[IntO$y_diff==i] - mean(IntO$ordi_diff_2)  ) / sd(IntO$ordi_diff_2[IntO$y_diff==i])
  #IntO$ordi_diff_3[IntO$y_diff==i] <- IntO$ordi_diff_3[IntO$y_diff==i] - 1/length(levels(as.factor(IntO$y_diff)))
}

# visualize results
ggplot(IntO@meta.data) + geom_density(aes(ordi_diff_3,color=as.character(y_diff))) + facet_wrap(~y_age,ncol=1) + theme_bw() 
ggplot(IntO@meta.data) + geom_point(aes(ordi_diff_3,y="y",color=as.character(y_diff))) + facet_wrap(~grouping_ordi,ncol=1) + theme_bw() 
ggplot(IntO@meta.data) + geom_density(aes(ordi_diff,color=as.character(y_diff))) + theme_bw() 
ggplot(IntO@meta.data,aes(x=ordi_diff_3,y=y_diff,color=as.character(y_diff)))+ geom_jitter()  + geom_boxplot()  + facet_wrap(~y_age,ncol=1) + theme_bw() 

####################################



# TANH SCALING
####################################

IntO$ordi_diff_3[IntO$y_diff==1] <-  IntO$ordi_diff_2[IntO$y_diff==1]  - 0.99 
IntO$ordi_diff_3[IntO$y_diff==1] <-  rescale(IntO$ordi_diff_3[IntO$y_diff==1],to= c((0), (0.33 + 0.10) ) )
IntO$ordi_diff_3[IntO$y_diff==2] <- IntO$ordi_diff_2[IntO$y_diff==2] - 0.66
IntO$ordi_diff_3[IntO$y_diff==2] <-  rescale(IntO$ordi_diff_3[IntO$y_diff==2],to= c((0.33-0.1),(0.66 + 0.10)) )
IntO$ordi_diff_3[IntO$y_diff==3] <- IntO$ordi_diff_2[IntO$y_diff==3] - 0.33
IntO$ordi_diff_3[IntO$y_diff==3] <-  rescale(IntO$ordi_diff_3[IntO$y_diff==3],to= c((0.66-0.1),(0.99)) )


IntO$ordi_age_3[IntO$y_age==1] <-  IntO$ordi_age_2[IntO$y_age==1]  - 0.99 
IntO$ordi_age_3[IntO$y_age==1] <-  rescale(IntO$ordi_age_3[IntO$y_age==1],to= c((0), (0.2 + 0.10) ) )
IntO$ordi_age_3[IntO$y_age==2] <- IntO$ordi_age_2[IntO$y_age==2] - 0.8
IntO$ordi_age_3[IntO$y_age==2] <-  rescale(IntO$ordi_age_3[IntO$y_age==2],to= c((0.2-0.1),(0.4 + 0.10)) )
IntO$ordi_age_3[IntO$y_age==3] <- IntO$ordi_age_2[IntO$y_age==3] - 0.6
IntO$ordi_age_3[IntO$y_age==3] <-  rescale(IntO$ordi_age_3[IntO$y_age==3],to= c((0.4-0.1),(0.6 +0.1)) )
IntO$ordi_age_3[IntO$y_age==4] <- IntO$ordi_age_2[IntO$y_age==4] - 0.4
IntO$ordi_age_3[IntO$y_age==4] <-  rescale(IntO$ordi_age_3[IntO$y_age==4],to= c((0.6-0.1),(0.8 +0.1)) )
IntO$ordi_age_3[IntO$y_age==5] <- IntO$ordi_age_2[IntO$y_age==5] - 0.2
IntO$ordi_age_3[IntO$y_age==5] <-  rescale(IntO$ordi_age_3[IntO$y_age==5],to= c((0.8-0.1),(0.99)) )

IntO$ordi_age_3_tanh <-  rescale(tanh((IntO$ordi_age_3-median(IntO$ordi_age_3))*.1),to=c(0,1))
IntO$ordi_diff_3_tanh <-  rescale(tanh((IntO$ordi_diff_3-median(IntO$ordi_diff_3))*.1),to=c(0,1))

IntO$ordi_age_3_tanh <- NA ; IntO$ordi_diff_3_tanh <- NA 
for (i in levels(as.factor(IntO$grouping_ordi))){
  IntO$ordi_age_3_tanh[IntO$grouping_ordi==i] <- tanh(IntO$ordi_age_3[IntO$grouping_ordi==i]-median(IntO$ordi_age_3[IntO$grouping_ordi==i])*0.6)
  IntO$ordi_diff_3_tanh[IntO$grouping_ordi==i] <- tanh(IntO$ordi_diff_3[IntO$grouping_ordi==i]-median(IntO$ordi_diff_3[IntO$grouping_ordi==i])*0.6)
} 

IntO$ordi_age_3_tanh2 <- NA 
for (i in levels(as.factor(IntO$y_diff))){
  IntO$ordi_age_3_tanh2[IntO$y_diff==i] <- rescale(tanh(IntO$ordi_age_3_tanh[IntO$y_diff==i]-median(IntO$ordi_age_3_tanh[IntO$y_diff==i])*0.9),to =c(0,1) )
} 
IntO$ordi_diff_3_tanh2 <- NA 
for (i in levels(as.factor(IntO$y_age))){
  IntO$ordi_diff_3_tanh2[IntO$y_age==i] <- rescale(tanh(IntO$ordi_diff_3_tanh[IntO$y_age==i]-median(IntO$ordi_diff_3_tanh[IntO$y_age==i])*0.9),to =c(0,1) )
} 


ggplot(IntO@meta.data) + geom_point(aes(ordi_age_3_tanh2,ordi_diff_3_tanh2,color=as.character(diff_ek))) + theme_bw()
ggplot(IntO@meta.data) + geom_point(aes(ordi_age_3_tanh2,ordi_diff_3_tanh,color=as.character(age_ek))) + theme_bw()



ggplot(IntO@meta.data,aes(x=ordi_diff_3_tanh2,y=y_diff,color=as.character(y_diff)))+ geom_jitter()  + geom_boxplot()  + facet_wrap(~y_age,ncol=1) + theme_bw() 
ggplot(IntO@meta.data,aes(x=ordi_age_3_tanh2,y=y_diff,color=as.character(y_diff)))+ geom_jitter()  + geom_boxplot()  + facet_wrap(~y_diff,ncol=1) + theme_bw() 


IntO$SOX2 <- IntO@assays$RNA@data["SOX2",]
ggplot(IntO@meta.data) + geom_point(aes(ordi_age_3_tanh2,ordi_diff_3_tanh2,color=SOX2)) + theme_bw() + scale_color_gradient2(low="white",mid="orange",high="red")

####################################







# VISUALIZE AGE & ORDI PRED TOGETHER AND NORMALIZE POSITIONS USING BILINEAR INTERPOLATION
####################################

ggplot(IntO@meta.data) + geom_point(aes(ordi_age_3,ordi_diff_3,color=as.character(grouping_ordi))) + theme_bw()
ggplot(IntO@meta.data) + geom_point(aes(ordi_age_3,ordi_diff_3,color=as.character(diff_ek))) + theme_bw()
ggplot(IntO@meta.data) + geom_point(aes(ordi_age_3,ordi_diff_3,color=as.character(age_ek))) + theme_bw()


####################################


ggplot(IntO@meta.data) + geom_point(aes(ordi_age_2,ordi_diff_2,color=as.character(diff_ek))) + theme_bw()
ggplot(IntO@meta.data) + geom_point(aes(ordi_age_3,ordi_diff_3,color=as.character(diff_ek))) + theme_bw()


center_diff_1 <- median(IntO$ordi_diff_2[IntO$y_diff==1])


IntO$ordi_diff_3 <- rep(-5.1,length(colnames(IntO)))
for (i in levels(as.factor(IntO$y_diff))){
  IntO$ordi_diff_3[IntO$y_diff==i] <- ( IntO$ordi_diff_2[IntO$y_diff==i]  ) / sd(IntO$ordi_diff_2[IntO$y_diff==i])
}



IntO$ordi_diff_3 <- ifelse(IntO$y_diff==1,IntO$ordi_diff_2 -  median(IntO$ordi_diff_2[IntO$y_diff==1]),as.numeric(IntO$ordi_diff_2))


IntO$ordi_diff_3 <- ifelse(IntO$y_diff==1,IntO$ordi_diff_2 -  median(IntO$ordi_diff_2[IntO$y_diff==1]), 
                           ifelse(IntO$y_diff==2,IntO$ordi_diff_2 -  median(IntO$ordi_diff_2[IntO$y_diff==2]),
                                  ifelse(IntO$y_diff==3,IntO$ordi_diff_2 -  median(IntO$ordi_diff_2[IntO$y_diff==3]), -5 )))

ggplot(IntO@meta.data,aes(x=(IntO$ordi_diff_3 / sd(IntO$ordi_diff_3)),y=y_diff,color=as.character(y_diff)))+ geom_jitter()  + geom_boxplot()  + facet_wrap(~y_age,ncol=1) + theme_bw() 


