

# Hv3

# LANDSCAPES' CORRELATIONS

library(dplyr) ; library(parallel) ; library(png) ; library(readr) ; library(ggplot2) ; library(plotly)

source("humous_v3/lib/lib_lands.R")

# Load landscapes data
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
L_MR_M <- readRDS("~/humous/humous_v4/out/landsM/L_MR_M.rds")
L_MR_H <- readRDS("~/humous/humous_v4/out/landsH/L_MR_H.rds")
L_MR_O <- readRDS("~/humous/humous_v4/out/landsO/L_MR_O.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# NON-PAIRWWISE CORRELATION HANDLE MOUSE-HUMAN ORTHOLOGS 
  # up to now, we let mouse gene names as they are  
    # for corrs across species-conditions, we need to match mouse genes with human genes
      # keep only genes called the same way in mouse and human
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

# load orthologs table
ortholog <- as.data.frame(read.csv("humous_v3/data/MH_orthologs.csv"))

# check which genes have a exact same across species (besides capitalization)
ortholog$samename <- ifelse(tolower(ortholog$mmu)==tolower(ortholog$hsa),"yes","no")
table(ortholog$samename)

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



# CALCULATE NON-PAIRWISE CORRELATIONS - SAME GENE ACROSS SPECIES CORRELATIONS 
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

# create empty dataframe with the needed shape
df_corr_nopairwise <- data.frame(genename_h=c(ortholog$hsa[ortholog$samename=="yes"]),genename_m=c(ortholog$mmu[ortholog$samename=="yes"]),
                                 corr_HvsM=NA,corr_HvsO=NA,corr_MvsO=NA,stringsAsFactors=FALSE)

# calculate non-pairwise correlations and populate df_corr_nopairwise
for (i in 1:nrow(df_corr_nopairwise)){
  
  print(df_corr_nopairwise$genename_h[i])
  
  if( any(df_corr_nopairwise$genename_h[i] %in% rownames(L_MR_H)) & any(df_corr_nopairwise$genename_m[i] %in% rownames(L_MR_M)) ){
    df_corr_nopairwise$corr_HvsM[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genename_h[i],gene2=df_corr_nopairwise$genename_m[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_M)$corr
  }else{"do nothing"}
  
  if( any(df_corr_nopairwise$genename_h[i] %in% rownames(L_MR_H)) & any(df_corr_nopairwise$genename_h[i] %in% rownames(L_MR_O)) ){
    df_corr_nopairwise$corr_HvsO[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genename_h[i],gene2=df_corr_nopairwise$genename_h[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_O)$corr
  }else{"do nothing"}
  
  if( any(df_corr_nopairwise$genename_m[i] %in% rownames(L_MR_M)) & any(df_corr_nopairwise$genename_h[i] %in% rownames(L_MR_O)) ){
    df_corr_nopairwise$corr_MvsO[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genename_m[i],gene2=df_corr_nopairwise$genename_h[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M,L2=L_MR_O)$corr
  }else{"do nothing"}

}

saveRDS(df_corr_nopairwise,"humous_v4/out/corrL/df_corr_nopairwise.rds")







# trial in parallel

nonpairw_corr <- function(i,df_corr_nopairwise, L_MR_H, L_MR_M, L_MR_O){
  
  if( any(df_corr_nopairwise$genename_h[i] %in% rownames(L_MR_H)) & any(df_corr_nopairwise$genename_m[i] %in% rownames(L_MR_M)) ){
    df_corr_nopairwise$corr_HvsM[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genename_h[i],gene2=df_corr_nopairwise$genename_m[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_M)$corr
  }else{"do nothing"}
  
  if( any(df_corr_nopairwise$genename_h[i] %in% rownames(L_MR_H)) & any(df_corr_nopairwise$genename_h[i] %in% rownames(L_MR_O)) ){
    df_corr_nopairwise$corr_HvsO[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genename_h[i],gene2=df_corr_nopairwise$genename_h[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_O)$corr
  }else{"do nothing"}
  
  if( any(df_corr_nopairwise$genename_m[i] %in% rownames(L_MR_M)) & any(df_corr_nopairwise$genename_h[i] %in% rownames(L_MR_O)) ){
    df_corr_nopairwise$corr_MvsO[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genename_m[i],gene2=df_corr_nopairwise$genename_h[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M,L2=L_MR_O)$corr
  }else{"do nothing"}

}


cl <- makeCluster(16)
clusterExport(cl,c("df_corr_nopairwise","L_MR_H", "L_MR_M", "L_MR_O"))
setDefaultCluster(cl)

results <- clusterApply(cl, 1:nrow(df_corr_nopairwise), nonpairw_corr)

# Store the results in the dataframe
for (i in 1:nrow(df_corr_nopairwise)) {
  df_corr_nopairwise$corr_HvsM[i] <- results[[i]]$HvsM
  df_corr_nopairwise$corr_HvsO[i] <- results[[i]]$HvsO
  df_corr_nopairwise$corr_MvsO[i] <- results[[i]]$MvsO
}










# load the csv with gene names that is used for the website
# has the mouse gene names as orthologs (upper case) so it does not match with names in L_MR_M

# load list of mouse genenames that dont have human orthologs and remove them from L_MR_M
mousegenes_NoHorth <- read_csv("humous_v3/out/landsM/mousegenes_NoHorth.csv")
L_MR_M_f <- L_MR_M[ ! rownames(L_MR_M) %in% mousegenes_NoHorth$x ,,]

# ORTHOLOG RENAMING of mouse genes with orths
landsnames <- data.frame(M=rownames(L_MR_M_f),Horth=NA)
ortholog <- as.data.frame(read.csv("humous_v3/data/MH_orthologs.csv"))
landsnames$Horth <- ortholog$hsa[match(landsnames$M,ortholog$mmu)]  
landsnames$MHconsensus <- ifelse(is.na(landsnames$Horth),as.character(landsnames$M),as.character(landsnames$Horth))
# rename landscapes in L_MR_M so the ones with Horths are called as the human gene and others keep the mouse name
rownames(L_MR_M_f) <- landsnames$MHconsensus

# load df for landscape indexing used on the website
df_landscape_indexing_web <- read_csv("humous_v3/out/website/df_landscape_indexing_web.csv")

# for each gene in df_landscape_indexing_web, calculate species-to-species correlations (some will be NA)
df_corr_nopairwise <- data.frame(genenames=df_landscape_indexing_web$gene,corr_HvsM=NA,corr_HvsO=NA,corr_MvsO=NA,stringsAsFactors=FALSE)

for (i in 1:nrow(df_corr_nopairwise)){
  
  gene <- df_corr_nopairwise$genenames[i] ; print(gene)
  
  if( df_landscape_indexing_web$human[df_landscape_indexing_web$gene==gene]=="yes" & df_landscape_indexing_web$mouse[df_landscape_indexing_web$gene==gene]=="yes" ){
    df_corr_nopairwise$corr_HvsM[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genenames[i],gene2=df_corr_nopairwise$genenames[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_M_f)$corr
  }else{"do nothing"}
  
  if( df_landscape_indexing_web$human[df_landscape_indexing_web$gene==gene]=="yes" & df_landscape_indexing_web$horg[df_landscape_indexing_web$gene==gene]=="yes" ){
    df_corr_nopairwise$corr_HvsO[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genenames[i],gene2=df_corr_nopairwise$genenames[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_O)$corr
  }else{"do nothing"}
  
  if( df_landscape_indexing_web$mouse[df_landscape_indexing_web$gene==gene]=="yes" & df_landscape_indexing_web$horg[df_landscape_indexing_web$gene==gene]=="yes" ){
    df_corr_nopairwise$corr_MvsO[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genenames[i],gene2=df_corr_nopairwise$genenames[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_O)$corr
  }else{"do nothing"}
  
}

#write.csv(df_corr_nopairwise,"humous_v3/out/corrL/df_corr_nopairwise.csv",row.names=FALSE)
df_corr_nopairwise <- read.csv("humous_v3/out/corrL/df_corr_nopairwise.csv")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
















# for correlations do:
  # one file per gene (corrs on all species combinations including itself)
      # dotty against dotty
      # noisy against noisy
      # patterned of any class (PN, PPN or PPP) all together


# in L_MR_M, change gene names for human orths
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
# load list of mouse genenames that dont have human orthologs and remove them from L_MR_M
mousegenes_NoHorth <- read_csv("humous_v3/out/landsM/mousegenes_NoHorth.csv")
L_MR_M_f <- L_MR_M[ ! rownames(L_MR_M) %in% mousegenes_NoHorth$x ,,]
# ORTHOLOG RENAMING of mouse genes with orths
landsnames <- data.frame(M=rownames(L_MR_M_f),Horth=NA)
ortholog <- as.data.frame(read.csv("humous_v3/data/MH_orthologs.csv"))
landsnames$Horth <- ortholog$hsa[match(landsnames$M,ortholog$mmu)]  
landsnames$MHconsensus <- ifelse(is.na(landsnames$Horth),as.character(landsnames$M),as.character(landsnames$Horth))
# rename landscapes in L_MR_M so the ones with Horths are called as the human gene and others keep the mouse name
rownames(L_MR_M_f) <- landsnames$MHconsensus
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# load df resulting from clustering inception (contains categorization in dotty, noise or subtypes of patterned)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
merged_2 <- read.csv("humous_v3/out/inceptionv3/inception_v3_iterativeclustering/merged_2.csv")
table(merged_2$species,merged_2$L_type)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# EXECUTE ONLY ONCE 
# load df for landscape indexing used on the website (to loop through the genes) and annotate it with inception types
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
df_landscape_indexing_web <- read_csv("humous_v3/out/website/df_landscape_indexing_web.csv")
# annotate df_landscape_indexing_web with inception type
df_landscape_indexing_web$type_human <- merged_2$L_type[match(paste0(df_landscape_indexing_web$gene,"_H"),merged_2$L_name)]
df_landscape_indexing_web$type_horg <- merged_2$L_type[match(paste0(df_landscape_indexing_web$gene,"_O"),merged_2$L_name)]
merged_2$MHconsensus <- landsnames$MHconsensus[match(gsub("_M","",merged_2$L_name),landsnames$M)]
df_landscape_indexing_web$type_mouse <- merged_2$L_type[match(df_landscape_indexing_web$gene,merged_2$MHconsensus)]
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# for each gene, calculate correlations (for mouse, use L_MR_M_f object) - for each gene and species combination, save a csv
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

source("humous_v3/lib/lib_misc.R")

# define function for ifelse switch depending on landscape type inside of for loop
#################
corrl_switch <- function(sourceindexing,targetindexing,Lobj1,Lobj2,colnamesdfd,pathsave){
  # find which type is the gene in source species
  type <- as.character(sourceindexing[df_landscape_indexing_web$gene==gene])
  
  # depending on value of type variable, execute one or another action
  if (type=="D"){ print("its dotty, corr with dotty")
    
    # df <- expand.grid(gene,rownames(Lobj2)[rownames(Lobj2) %in% df_landscape_indexing_web$gene[targetindexing=="D"]]) ; colnames(df) <- colnamesdfd ; df$corr <- NA  # create column to store results
    # df2 <- vector(mode="list",length=nrow(df)) ; df2 <- paste0(df[,1],"_",df[,2])
    # corrs <- simplify2array(mclapply(mc.cores=100,df2,function(x){
    #   L_TH_BoosCorr(gene1=gsub("_.*","",x),gene2=gsub(".*_","",x),threshold=0.3,n_boosts=10,boostsize=2000,L1=Lobj1,L2=Lobj2)$corr
    # }))
    # df$corr <- corrs
    
    # for (j in 1:nrow(df)){ # launch loop
    #   print(paste("doing",i," ",j,"out of",nrow(df)))
    #   df$corr[j] <- L_TH_BoosCorr(gene1=df[j,colnamesdfd[1]],gene2=df[j,colnamesdfd[2]],threshold=0.3,n_boosts=10,boostsize=2000,L1=Lobj1,L2=Lobj2)$corr
    # } 
    # write.csv(df,paste0(pathsave,gene,"_",type,".csv"))
    
  }else if(type=="N"){ print("its noisy, corr with noisy")
    
    # df <- expand.grid(gene,rownames(Lobj2)[rownames(Lobj2) %in% df_landscape_indexing_web$gene[targetindexing=="N"]]) ; colnames(df) <- colnamesdfd ; df$corr <- NA  # create column to store results
    # df2 <- vector(mode="list",length=nrow(df)) ; df2 <- paste0(df[,1],"_",df[,2])
    # corrs <- simplify2array(mclapply(mc.cores=100,df2,function(x){
    #   L_TH_BoosCorr(gene1=gsub("_.*","",x),gene2=gsub(".*_","",x),threshold=0.3,n_boosts=10,boostsize=2000,L1=Lobj1,L2=Lobj2)$corr
    # }))
    # df$corr <- corrs
    # write.csv(df,paste0(pathsave,gene,"_",type,".csv"))
    
  }else if(type %in% c("PN","PPN","PPP")){ print("its patterned, corr with patterned")
    df <- expand.grid(gene,rownames(Lobj2)[rownames(Lobj2) %in% df_landscape_indexing_web$gene[targetindexing %in% c("PN","PPN","PPP")]]) ; colnames(df) <- colnamesdfd ; df$corr <- NA  # create column to store results
    df2 <- vector(mode="list",length=nrow(df)) ; df2 <- paste0(df[,1],"_",df[,2])
    corrs <- simplify2array(mclapply(mc.cores=110,df2,function(x){
      L_TH_BoosCorr(gene1=gsub("_.*","",x),gene2=gsub(".*_","",x),threshold=0.3,n_boosts=10,boostsize=2000,L1=Lobj1,L2=Lobj2)$corr
    }))
    df$corr <- corrs
    write.csv(df,paste0(pathsave,gene,"_",type,".csv"))
    
  }else{"do nothing"}
  
}
#################


# # this is a trial
# df <- expand.grid(gene,rownames(Lobj2)[rownames(Lobj2) %in% df_landscape_indexing_web$gene[targetindexing=="D"]]) ; colnames(df) <- colnamesdfd
# df2 <- vector(mode="list",length=nrow(df)) ; df2 <- paste0(df[,1],"_",df[,2])
# corrs <- simplify2array(mclapply(mc.cores=40,df2,function(x){
#   L_TH_BoosCorr(gene1=gsub("_.*","",x),gene2=gsub(".*_","",x),threshold=0.3,n_boosts=10,boostsize=2000,L1=Lobj1,L2=Lobj2)$corr
# }))


# lAUNCH LOOP
#################

# this was just to be executed the first time!!!
#df_landscape_indexing_web <- read.csv("humous_v3/out/website/df_landscape_indexing_web.csv")
# df_landscape_indexing_web$isdonecorr <- "no" ; then, saved with different name in different folder 

df_landscape_indexing_web <- read.csv("humous_v3/out/corrL/df_landscape_indexing_corr2.csv")
df_landscape_indexing_web$is_patterned_any <- ifelse(grepl("P",paste(df_landscape_indexing_web$type_horg,df_landscape_indexing_web$type_human,df_landscape_indexing_web$type_mouse)),"yes","no")
table(df_landscape_indexing_web$isdonecorr,df_landscape_indexing_web$is_patterned_any) # look for the yes yes to be complete and yes no to be empty

filesHM <- list.files("humous_v3/out/corrL/HM/",full.names = FALSE )
df_landscape_indexing_web$isdonecorr2 <- ifelse(df_landscape_indexing_web$gene %in% mgsub::mgsub(string=filesHM,
                                                                                                 pattern=c("HM_pairwcorr_","_N.csv","_PPP.csv","_D.csv","_PPN.csv","_PN.csv"),
                                                                                                 replacement=c("","","","","","")),"yes","no")
table(df_landscape_indexing_web$isdonecorr2,df_landscape_indexing_web$is_patterned_any)


for (i in levels(as.factor(df_landscape_indexing_web$gene[df_landscape_indexing_web$isdonecorr2=="no" & df_landscape_indexing_web$is_patterned_any=="yes" ]))){
  
  gene <- i ; print(i)
  
  # HUMAN VS MOUSE CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(sourceindexing=df_landscape_indexing_web$type_human,targetindexing=df_landscape_indexing_web$type_mouse,Lobj1=L_MR_H,Lobj2=L_MR_M_f,colnamesdfd=c("human","mouse"),pathsave="humous_v3/out/corrL/HM/HM_pairwcorr_")
    } ,error = function(e) { message("something went wrong") ; message(e) } )

  # HUMAN VS HORG CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_human,targetindexing=df_landscape_indexing_web$type_horg,Lobj1=L_MR_H,Lobj2=L_MR_O,colnamesdfd=c("human","horg"),pathsave="humous_v3/out/corrL/HO/HO_pairwcorr_")
    } ,error = function(e) { message("something went wrong") ; message(e) } )

  # HUMAN VS HUMAN CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_human,targetindexing=df_landscape_indexing_web$type_human,Lobj1=L_MR_H,Lobj2=L_MR_H,colnamesdfd=c("human","human"),pathsave="humous_v3/out/corrL/HH/HH_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # MOUSE VS HUMAN CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_mouse,targetindexing=df_landscape_indexing_web$type_human,Lobj1=L_MR_M_f,Lobj2=L_MR_H,colnamesdfd=c("mouse","human"),pathsave="humous_v3/out/corrL/MH/MH_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
 
  # MOUSE VS HORG CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_mouse,targetindexing=df_landscape_indexing_web$type_horg,Lobj1=L_MR_M_f,Lobj2=L_MR_O,colnamesdfd=c("mouse","horg"),pathsave="humous_v3/out/corrL/MO/MO_pairwcorr_")
    } ,error = function(e) { message("something went wrong") ; message(e) } )

  # MOUSE VS MOUSE CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_mouse,targetindexing=df_landscape_indexing_web$type_mouse,Lobj1=L_MR_M_f,Lobj2=L_MR_M_f,colnamesdfd=c("mouse","mouse"),pathsave="humous_v3/out/corrL/MM/MM_pairwcorr_")
    } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HORG VS HUMAN CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_horg,targetindexing=df_landscape_indexing_web$type_human,Lobj1=L_MR_O,Lobj2=L_MR_H,colnamesdfd=c("horg","human"),pathsave="humous_v3/out/corrL/OH/OH_pairwcorr_") 
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HORG VS MOUSE CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_horg,targetindexing=df_landscape_indexing_web$type_mouse,Lobj1=L_MR_O,Lobj2=L_MR_M_f,colnamesdfd=c("horg","mouse"),pathsave="humous_v3/out/corrL/OM/OM_pairwcorr_") 
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HORG VS HORG CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_horg,targetindexing=df_landscape_indexing_web$type_horg,Lobj1=L_MR_O,Lobj2=L_MR_O,colnamesdfd=c("horg","horg"),pathsave="humous_v3/out/corrL/OO/OO_pairwcorr_")
    } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  df_landscape_indexing_web$isdonecorr[df_landscape_indexing_web$gene==i] <- "yes"
  
  write.csv(df_landscape_indexing_web,"humous_v3/out/corrL/df_landscape_indexing_corr2.csv",row.names = FALSE)
 
} 
#################
  
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 





# AFTER FIRST ROUND OF CORR FINISHED, CHECK WHICH GENES ARE STILL NOT CALCULATED (no file for them)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

# all the ones we need to have
target_HO <- unique(mgsub::mgsub(pattern=c("_H","_M","_O"),replacement=c("","",""),string=merged_2$L_name[ grepl("P",merged_2$L_type) & merged_2$species %in% c("H","O") ])) # 4301
target_M <- unique(mgsub::mgsub(pattern=c("_H","_M","_O"),replacement=c("","",""),string=merged_2$MHconsensus[ grepl("P",merged_2$L_type) & merged_2$species=="M" ])) # 3917
target <- unique(target_HO,target_M)
# all the ones we have
filesall <- c(list.files("humous_v3/out/corrL/HH/"),list.files("humous_v3/out/corrL/HM/"),list.files("humous_v3/out/corrL/HO/"),
              list.files("humous_v3/out/corrL/MH/"),list.files("humous_v3/out/corrL/MM/"),list.files("humous_v3/out/corrL/MO/"),
              list.files("humous_v3/out/corrL/OH/"),list.files("humous_v3/out/corrL/OM/"),list.files("humous_v3/out/corrL/OO/"))
filesP <- filesall[grepl("_P",filesall)]
genenames <- mgsub::mgsub(pattern=c("humous_v3/out/corrL/","HH","HM","HO","MM","MH","MO","OO","OH","OM","_pairwcorr_","_PPP.csv","_PPN.csv","_PN.csv"),
                          replacement=c("","","","","","","","","","","","","",""),string=filesP)
genenames2 <- unique(genenames)
# which ones we miss?
missing <- target[ ! target %in% genenames2] # we miss 944
missing_reporter <- data.frame(gene=missing,isdonecorr="no") ; #write.csv(missing_reporter,"humous_v3/out/corrL/missing_reporter.csv",row.names = FALSE)

missing_reporter <- read_csv("humous_v3/out/corrL/missing_reporter.csv")
table(missing_reporter$isdonecorr)

# get the ones missing
for (i in levels(as.factor(missing_reporter$gene[missing_reporter$isdonecorr=="no"]))){
  
  gene <- i ; print(i)
  
  # HUMAN VS MOUSE CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(sourceindexing=df_landscape_indexing_web$type_human,targetindexing=df_landscape_indexing_web$type_mouse,Lobj1=L_MR_H,Lobj2=L_MR_M_f,colnamesdfd=c("human","mouse"),pathsave="humous_v3/out/corrL/HM/HM_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HUMAN VS HORG CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_human,targetindexing=df_landscape_indexing_web$type_horg,Lobj1=L_MR_H,Lobj2=L_MR_O,colnamesdfd=c("human","horg"),pathsave="humous_v3/out/corrL/HO/HO_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HUMAN VS HUMAN CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_human,targetindexing=df_landscape_indexing_web$type_human,Lobj1=L_MR_H,Lobj2=L_MR_H,colnamesdfd=c("human","human"),pathsave="humous_v3/out/corrL/HH/HH_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # MOUSE VS HUMAN CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_mouse,targetindexing=df_landscape_indexing_web$type_human,Lobj1=L_MR_M_f,Lobj2=L_MR_H,colnamesdfd=c("mouse","human"),pathsave="humous_v3/out/corrL/MH/MH_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # MOUSE VS HORG CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_mouse,targetindexing=df_landscape_indexing_web$type_horg,Lobj1=L_MR_M_f,Lobj2=L_MR_O,colnamesdfd=c("mouse","horg"),pathsave="humous_v3/out/corrL/MO/MO_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # MOUSE VS MOUSE CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_mouse,targetindexing=df_landscape_indexing_web$type_mouse,Lobj1=L_MR_M_f,Lobj2=L_MR_M_f,colnamesdfd=c("mouse","mouse"),pathsave="humous_v3/out/corrL/MM/MM_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HORG VS HUMAN CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_horg,targetindexing=df_landscape_indexing_web$type_human,Lobj1=L_MR_O,Lobj2=L_MR_H,colnamesdfd=c("horg","human"),pathsave="humous_v3/out/corrL/OH/OH_pairwcorr_") 
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HORG VS MOUSE CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_horg,targetindexing=df_landscape_indexing_web$type_mouse,Lobj1=L_MR_O,Lobj2=L_MR_M_f,colnamesdfd=c("horg","mouse"),pathsave="humous_v3/out/corrL/OM/OM_pairwcorr_") 
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HORG VS HORG CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_horg,targetindexing=df_landscape_indexing_web$type_horg,Lobj1=L_MR_O,Lobj2=L_MR_O,colnamesdfd=c("horg","horg"),pathsave="humous_v3/out/corrL/OO/OO_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  missing_reporter$isdonecorr[missing_reporter$gene==i] <- "yes"
  
  write.csv(missing_reporter,"humous_v3/out/corrL/missing_reporter.csv",row.names = FALSE)
  
} 
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



# EXTRA PROBLEM - SOME GENES GOT ALL NA VALUES IN FINAL ASSEMBLY AND SOME _pairwcorr_ csvs for error messages in corr value, FIND OUT WHICH ONES
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

# retrieve listing of all landscapes and their types
# merged_2 <- read.csv("humous_v3/out/inceptionv3/inception_v3_iterativeclustering/merged_2.csv")
# merged_2$genename <- sub("_.*","",merged_2$L_name)
# length(unique(merged_2$genename)) ; length(unique(merged_2$genename[grepl("P",merged_2$L_type)]))  # 25551 in total, 8506 patterned
# 
# 
# # how many genes, and which, I got a pairwcorr table for during calculation?
# filesall <- data.frame(listing=c(list.files("humous_v3/out/corrL/HH/"),list.files("humous_v3/out/corrL/HM/"),list.files("humous_v3/out/corrL/HO/"),
#                                  list.files("humous_v3/out/corrL/MH/"),list.files("humous_v3/out/corrL/MM/"),list.files("humous_v3/out/corrL/MO/"),
#                                  list.files("humous_v3/out/corrL/OH/"),list.files("humous_v3/out/corrL/OM/"),list.files("humous_v3/out/corrL/OO/")))
# filesall$genenames <- mgsub::mgsub(pattern=c("humous_v3/out/corrL/","HH","HM","HO","MM","MH","MO","OO","OH","OM","_pairwcorr_",
#                                              "_PPP.csv","_PPN.csv","_PN.csv","_D.csv","_H.csv","_N.csv"),
#                                    replacement=c("","","","","","","","","","","","","","","","",""),string=filesall$listing)
# length(unique(filesall$genenames)) # 6408
# 
# 
# # how many genes, and which, I generated a compiled csv for website?
# filesweball <- data.frame(listing=c(list.files("humous_v3/out/website/corr_pairw_tables/corr_pairw_H/"),
#                                     list.files("humous_v3/out/website/corr_pairw_tables/corr_pairw_M/"),
#                                     list.files("humous_v3/out/website/corr_pairw_tables/corr_pairw_O/")))
# filesweball$genenames <- sub("_.*","",filesweball$listing)
# filesweball$species <-  gsub(".*_(.).csv", "\\1", filesweball$listing)
# length(unique(filesweball$genenames)) # 5587
# # which of these have problematic tables? NAs?
# library(data.table)
# filesweball$problematic <- NA
# for (i in 1:nrow(filesweball)){
#   filesweball$problematic[i] <- any(is.na(fread(paste0("humous_v3/out/website/corr_pairw_tables/corr_pairw_",
#                                                        filesweball$species[i],"/",filesweball$listing[i]), verbose = FALSE)))
# }
# table(filesweball$problematic) # problematics 2691
# 
# # assemble filesweball columns "genenames" and "problematic", containing 5587 unique patterned with
# # filesall uniques in column "genenames" that are not in filesweball, 938 extra ones
# table(unique(filesall$genenames) %in% filesweball$genenames)
# 
# problematics <- rbind( filesweball[filesweball$problematic==TRUE,c("genenames","problematic")],
#                        data.frame(genenames= unique(filesall$genenames)[ ! unique(filesall$genenames) %in% filesweball$genenames] ,problematic=TRUE ) )
# 
# # for some reason, in problematics there are some gene names that dont exist, some kind of regex problem, remove them cause number is negligible
# problematics_f <- problematics[problematics$genenames %in% merged_2$genename,]
# 
# # RECALCULATE PAIRWISE CORRELATIONS FOR THOSE 2691 PROBLEMATIC ONES
# # example of why it failed, I didn't load the L_TH_BoosCorr function
# a <- read.csv("humous_v3/out/corrL/HH/HH_pairwcorr_PTN_PPP.csv")
# 
# problematics_f$problem_solved <- NA
# #write.csv(problematics_f,"humous_v3/out/corrL/problematics_listing.csv",row.names=FALSE)

source("humous_v3/lib/lib_lands.R") # here is where I load L_TH_BoosCorr

problematics_f <- read.csv("humous_v3/out/corrL/problematics_listing.csv")
# see how many are left
table(problematics_f$problem_solved,useNA="always" )

# load list of problematic genes pointed by umanova and launch calculations just for those
problems <- read.table("humous_v3/out/website/corr_pairw_tables_2/output.txt") 
problems$V1 <-mgsub::mgsub(pattern=c("_M","_H","_O"),replacement=c("","",""),string=problems$V1)

for (i in levels(as.factor(problematics_f$genenames[is.na(problematics_f$problem_solved)]))){
  
  gene <- i ; print(i)
  
  # HUMAN VS MOUSE CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(sourceindexing=df_landscape_indexing_web$type_human,targetindexing=df_landscape_indexing_web$type_mouse,Lobj1=L_MR_H,Lobj2=L_MR_M_f,colnamesdfd=c("human","mouse"),pathsave="humous_v3/out/corrL/HM/HM_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HUMAN VS HORG CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_human,targetindexing=df_landscape_indexing_web$type_horg,Lobj1=L_MR_H,Lobj2=L_MR_O,colnamesdfd=c("human","horg"),pathsave="humous_v3/out/corrL/HO/HO_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HUMAN VS HUMAN CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_human,targetindexing=df_landscape_indexing_web$type_human,Lobj1=L_MR_H,Lobj2=L_MR_H,colnamesdfd=c("human","human"),pathsave="humous_v3/out/corrL/HH/HH_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # MOUSE VS HUMAN CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_mouse,targetindexing=df_landscape_indexing_web$type_human,Lobj1=L_MR_M_f,Lobj2=L_MR_H,colnamesdfd=c("mouse","human"),pathsave="humous_v3/out/corrL/MH/MH_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # MOUSE VS HORG CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_mouse,targetindexing=df_landscape_indexing_web$type_horg,Lobj1=L_MR_M_f,Lobj2=L_MR_O,colnamesdfd=c("mouse","horg"),pathsave="humous_v3/out/corrL/MO/MO_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # MOUSE VS MOUSE CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_mouse,targetindexing=df_landscape_indexing_web$type_mouse,Lobj1=L_MR_M_f,Lobj2=L_MR_M_f,colnamesdfd=c("mouse","mouse"),pathsave="humous_v3/out/corrL/MM/MM_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HORG VS HUMAN CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_horg,targetindexing=df_landscape_indexing_web$type_human,Lobj1=L_MR_O,Lobj2=L_MR_H,colnamesdfd=c("horg","human"),pathsave="humous_v3/out/corrL/OH/OH_pairwcorr_") 
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HORG VS MOUSE CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_horg,targetindexing=df_landscape_indexing_web$type_mouse,Lobj1=L_MR_O,Lobj2=L_MR_M_f,colnamesdfd=c("horg","mouse"),pathsave="humous_v3/out/corrL/OM/OM_pairwcorr_") 
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  # HORG VS HORG CORRELATIONS - ONE FILE PER GENE AND TYPE ANNOTATED TOO
  tryCatch({corrl_switch(df_landscape_indexing_web$type_horg,targetindexing=df_landscape_indexing_web$type_horg,Lobj1=L_MR_O,Lobj2=L_MR_O,colnamesdfd=c("horg","horg"),pathsave="humous_v3/out/corrL/OO/OO_pairwcorr_")
  } ,error = function(e) { message("something went wrong") ; message(e) } )
  
  #problematics_f$problem_solved[problematics_f$genenames==i] <- TRUE
  
  #write.csv(problematics_f,"humous_v3/out/corrL/problematics_listing.csv",row.names=FALSE)
  
} 


# see how many are left
table(problematics_f$problem_solved,useNA="always" )

# check one table
a <- read.csv("humous_v3/out/corrL/MM/MM_pairwcorr_RBFOX3_PPP.csv")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



# check some landscapes to see if corrs make sense
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
# visualize landscapes
  # example of H-M with 0.44 corr value
plot(0:1, 0:1, type="n", xlab="", ylab="", xlim=c(0,1), ylim=c(0,1))
rasterImage(readPNG("humous_v3/out/pngLs/web_pngLs/H/AKIRIN2_H.png"), 0, 0, 1, 1)
plot(0:1, 0:1, type="n", xlab="", ylab="", xlim=c(0,1), ylim=c(0,1))
rasterImage(readPNG("humous_v3/out/pngLs/web_pngLs/M/GADD45A_M.png"), 0, 0, 1, 1)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# SAME GENE ACROSS SPECIES CORRELATIONS (NON-PAIRWISE)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
# load the csv with gene names that is used for the website
# has the mouse gene names as orthologs (upper case) so it does not match with names in L_MR_M

# load list of mouse genenames that dont have human orthologs and remove them from L_MR_M
mousegenes_NoHorth <- read_csv("humous_v3/out/landsM/mousegenes_NoHorth.csv")
L_MR_M_f <- L_MR_M[ ! rownames(L_MR_M) %in% mousegenes_NoHorth$x ,,]

# ORTHOLOG RENAMING of mouse genes with orths
landsnames <- data.frame(M=rownames(L_MR_M_f),Horth=NA)
ortholog <- as.data.frame(read.csv("humous_v3/data/MH_orthologs.csv"))
landsnames$Horth <- ortholog$hsa[match(landsnames$M,ortholog$mmu)]  
landsnames$MHconsensus <- ifelse(is.na(landsnames$Horth),as.character(landsnames$M),as.character(landsnames$Horth))
# rename landscapes in L_MR_M so the ones with Horths are called as the human gene and others keep the mouse name
rownames(L_MR_M_f) <- landsnames$MHconsensus

# load df for landscape indexing used on the website
df_landscape_indexing_web <- read_csv("humous_v3/out/website/df_landscape_indexing_web.csv")

# for each gene in df_landscape_indexing_web, calculate species-to-species correlations (some will be NA)
df_corr_nopairwise <- data.frame(genenames=df_landscape_indexing_web$gene,corr_HvsM=NA,corr_HvsO=NA,corr_MvsO=NA,stringsAsFactors=FALSE)

for (i in 1:nrow(df_corr_nopairwise)){
  
  gene <- df_corr_nopairwise$genenames[i] ; print(gene)
  
  if( df_landscape_indexing_web$human[df_landscape_indexing_web$gene==gene]=="yes" & df_landscape_indexing_web$mouse[df_landscape_indexing_web$gene==gene]=="yes" ){
    df_corr_nopairwise$corr_HvsM[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genenames[i],gene2=df_corr_nopairwise$genenames[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_M_f)$corr
  }else{"do nothing"}
  
  if( df_landscape_indexing_web$human[df_landscape_indexing_web$gene==gene]=="yes" & df_landscape_indexing_web$horg[df_landscape_indexing_web$gene==gene]=="yes" ){
    df_corr_nopairwise$corr_HvsO[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genenames[i],gene2=df_corr_nopairwise$genenames[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_O)$corr
  }else{"do nothing"}
  
  if( df_landscape_indexing_web$mouse[df_landscape_indexing_web$gene==gene]=="yes" & df_landscape_indexing_web$horg[df_landscape_indexing_web$gene==gene]=="yes" ){
    df_corr_nopairwise$corr_MvsO[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genenames[i],gene2=df_corr_nopairwise$genenames[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_O)$corr
  }else{"do nothing"}
  
}

#write.csv(df_corr_nopairwise,"humous_v3/out/corrL/df_corr_nopairwise.csv",row.names=FALSE)
df_corr_nopairwise <- read.csv("humous_v3/out/corrL/df_corr_nopairwise.csv")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# check how the non-pairwise correlations look like
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

ggplot(df_corr_nopairwise) + geom_point(aes(corr_HvsM,corr_HvsO)) + theme_classic() + 
  geom_label(data=df_corr_nopairwise[df_corr_nopairwise$genenames %in% c("SOX2","JUNB","APBB2","EOMES"),],
             mapping=aes(corr_HvsM,corr_HvsO,label=genenames))

plot_ly(df_corr_nopairwise, x = ~corr_MvsO, y = ~corr_HvsM, z = ~corr_HvsO,size=df_corr_nopairwise$corr_HvsM)

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



# ASSEMBLE PAIRWISE CORRELATIONS, JUST PATTERNED GENES, ONE FILE PER GENE & SPECIES (these tables will be for the correlations page of the website)
    # 4 columns on each file (example if the starting gene is human):
          # 1) top corr human vs human ; 2) top corr human vs mouse ; 3) top corr humous vs org ; 4) top ANTIcorr human vs human
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# HUMAN 
#####################

# load the names of all files containing pairwise correlations calculations
foldernames <- c("HH","HM","HO")
files1 <- list.files(paste0("humous_v3/out/corrL/",foldernames[1],"/"),full.names=TRUE)
files2 <- list.files(paste0("humous_v3/out/corrL/",foldernames[2],"/"),full.names=TRUE)
files3 <- list.files(paste0("humous_v3/out/corrL/",foldernames[3],"/"),full.names=TRUE)
files1 <- files1[grepl("_P",files1)] ; files2 <- files2[grepl("_P",files2)] ; files3 <- files3[grepl("_P",files3)] 

genenames <- c(gsub(paste0("humous_v3/out/corrL/",foldernames[1],"/","/",foldernames[1],"_pairwcorr_"),"",files1),
                    gsub(paste0("humous_v3/out/corrL/",foldernames[2],"/","/",foldernames[2],"_pairwcorr_"),"",files2),
               gsub(paste0("humous_v3/out/corrL/",foldernames[3],"/","/",foldernames[3],"_pairwcorr_"),"",files3))
genenames <- unique(mgsub::mgsub(pattern=c("_PPP.csv","_PPN.csv","_PN.csv"),replacement=c("","",""),string=genenames) )

# save a csv per human gene
for (i in levels(as.factor(genenames))){
  print(i)
  # first column of the table - vs human positive correlated
  col1 <- as.data.frame(read.csv(files1[grepl(paste0("_",i,"_"),files1)])) ; col1 <- col1[!grepl("[::alpha::]",col1$corr),] ; col1$corr <- as.numeric(col1$corr) # load and remove rows with errors
  col1 <- col1[col1[,2]==i,]   # in case there was a mistake somewhere, keep just rows in which source gene is i
  col1_f <- col1[order(col1$corr,decreasing=TRUE),] ; col1_f <- col1_f[col1_f$corr<1,] ; col1_f <- col1_f[c(1:30),] # not if corr is ==1 (corr with itself) and take just 30 first (max table size)
  # second column of the table - vs mouse positive correlated
  col2 <- as.data.frame(read.csv(files2[grepl(paste0("_",i,"_"),files2)])) ; col2 <- col2[!grepl("[::alpha::]",col2$corr),] ; col2$corr <- as.numeric(col2$corr)
  col2 <- col2[col2[,2]==i,]   # in case there was a mistake somewhere, keep just rows in which source gene is i
  col2_f <- col2[order(col2$corr,decreasing=TRUE),] ; col2_f <- col2_f[col2_f$corr<1,]; col2_f <- col2_f[c(1:30),] # keep 30 top
  # third column of the table - vs org positive correlated
  col3 <- as.data.frame(read.csv(files3[grepl(paste0("_",i,"_"),files3)])) ; col3 <- col3[!grepl("[::alpha::]",col3$corr),] ; col3$corr <- as.numeric(col3$corr)
  col3 <- col3[col3[,2]==i,]   # in case there was a mistake somewhere, keep just rows in which source gene is i
  col3_f <- col3[order(col3$corr,decreasing=TRUE),] ; col3_f <- col3_f[col3_f$corr<1,]  ; col3_f <- col3_f[c(1:30),] # keep 30 top 
  # fourth column of the table - intra-species negative correlated
  col4 <- as.data.frame(read.csv(files1[grepl(paste0("_",i,"_"),files1)])) ; col4 <- col4[!grepl("[::alpha::]",col4$corr),] ; col4$corr <- as.numeric(col4$corr)
  col4 <- col4[col4[,2]==i,] # in case there was a mistake somewhere, keep just rows in which source gene is i
  col4_f <- col4[col4$corr<0,] # in intraspecies we just want to keep the negatively correlated ones
  col4_f <- col4_f[order(col4_f$corr,decreasing=FALSE),] ; col4_f <- col4_f[c(1:30),] # keep 30 top

  # get gene names from each and populate df with 4 columns - shape needed for the website
  df_f <- data.frame(ref_gene=paste0(i,"_H"),corr_human=col1_f[,3],corr_mouse=col2_f[,3],corr_org=col3_f[,3],anticorr_intra=col4_f[,3])
  # save website table
  write.csv(df_f,paste0("humous_v3/out/website/corr_pairw_tables_2/corr_pairw_H/",i,"_H.csv"),row.names = FALSE)
}

# sanity checks
table(merged_2$L_type,merged_2$species=="H")
filesres <- list.files("humous_v3/out/website/corr_pairw_tables_2/corr_pairw_H/")
a <-  read.csv("humous_v3/out/website/corr_pairw_tables_2/corr_pairw_H/PTN_H.csv")

#####################


# MOUSE
#####################

foldernames <- c("MH","MM","MO")

files1 <- list.files(paste0("humous_v3/out/corrL/",foldernames[1],"/"),full.names=TRUE)
files2 <- list.files(paste0("humous_v3/out/corrL/",foldernames[2],"/"),full.names=TRUE)
files3 <- list.files(paste0("humous_v3/out/corrL/",foldernames[3],"/"),full.names=TRUE)
files1 <- files1[grepl("_P",files1)] ; files2 <- files2[grepl("_P",files2)] ; files3 <- files3[grepl("_P",files3)] 

genenames <- c(gsub(paste0("humous_v3/out/corrL/",foldernames[1],"/","/",foldernames[1],"_pairwcorr_"),"",files1),
               gsub(paste0("humous_v3/out/corrL/",foldernames[2],"/","/",foldernames[2],"_pairwcorr_"),"",files2),
               gsub(paste0("humous_v3/out/corrL/",foldernames[3],"/","/",foldernames[3],"_pairwcorr_"),"",files3))
genenames <- unique(mgsub::mgsub(pattern=c("_PPP.csv","_PPN.csv","_PN.csv"),replacement=c("","",""),string=genenames) )


# save a csv per mouse gene
for (i in levels(as.factor(genenames))){
  print(i)
  # first column of the table - vs human positive correlated
  col1 <- as.data.frame(read.csv(files1[grepl(paste0("_",i,"_"),files1)])) ; col1 <- col1[!grepl("[::alpha::]",col1$corr),] ; col1$corr <- as.numeric(col1$corr) # load and remove rows with errors
  col1 <- col1[col1[,2]==i,]   # in case there was a mistake somewhere, keep just rows in which source gene is i
  col1_f <- col1[order(col1$corr,decreasing=TRUE),] ; col1_f <- col1_f[col1$corr<1,] ; col1_f <- col1_f[c(1:30),] # not if corr is ==1 (corr with itself) and take just 30 first (max table size)
  # second column of the table - vs mouse positive correlated
  col2 <- as.data.frame(read.csv(files2[grepl(paste0("_",i,"_"),files2)])) ; col2 <- col2[!grepl("[::alpha::]",col2$corr),] ; col2$corr <- as.numeric(col2$corr)
  col2 <- col2[col2[,2]==i,]   # in case there was a mistake somewhere, keep just rows in which source gene is i
  col2_f <- col2[order(col2$corr,decreasing=TRUE),] ; col2_f <- col2_f[col2_f$corr<1,]; col2_f <- col2_f[c(1:30),]
  # third column of the table - vs org positive correlated
  col3 <- as.data.frame(read.csv(files3[grepl(paste0("_",i,"_"),files3)])) ; col3 <- col3[!grepl("[::alpha::]",col3$corr),] ; col3$corr <- as.numeric(col3$corr)
  col3 <- col3[col3[,2]==i,]   # in case there was a mistake somewhere, keep just rows in which source gene is i
  col3_f <- col3[order(col3$corr,decreasing=TRUE),] ; col3_f <- col3_f[col3_f$corr<1,]  ; col3_f <- col3_f[c(1:30),]
  # fourth column of the table - intraspecies negative correlated
  col4 <- as.data.frame(read.csv(files2[grepl(paste0("_",i,"_"),files2)])) ; col4 <- col4[!grepl("[::alpha::]",col4$corr),] ; col4$corr <- as.numeric(col4$corr)
  col4 <- col4[col4[,2]==i,] # in case there was a mistake somewhere, keep just rows in which source gene is i
  col4_f <- col4[col4$corr<0,] ;
  col4_f <- col4_f[order(col4_f$corr,decreasing=FALSE),] ; col4_f <- col4_f[c(1:30),]
  
  # get gene names from each and populate df with 4 columns
  df <- data.frame(ref_gene=paste0(i,"_M"),corr_human=col1_f[,3],corr_mouse=col2_f[,3],corr_org=col3_f[,3],anticorr_intra=col4_f[,3])
  
  write.csv(df,paste0("humous_v3/out/website/corr_pairw_tables_2/corr_pairw_M/",i,"_M.csv"),row.names = FALSE)
}
#####################


# ORG
#####################

foldernames <- c("OH","OM","OO")

files1 <- list.files(paste0("humous_v3/out/corrL/",foldernames[1],"/"),full.names=TRUE)
files2 <- list.files(paste0("humous_v3/out/corrL/",foldernames[2],"/"),full.names=TRUE)
files3 <- list.files(paste0("humous_v3/out/corrL/",foldernames[3],"/"),full.names=TRUE)
files1 <- files1[grepl("_P",files1)] ; files2 <- files2[grepl("_P",files2)] ; files3 <- files3[grepl("_P",files3)] 

genenames <- c(gsub(paste0("humous_v3/out/corrL/",foldernames[1],"/","/",foldernames[1],"_pairwcorr_"),"",files1),
               gsub(paste0("humous_v3/out/corrL/",foldernames[2],"/","/",foldernames[2],"_pairwcorr_"),"",files2),
               gsub(paste0("humous_v3/out/corrL/",foldernames[3],"/","/",foldernames[3],"_pairwcorr_"),"",files3))
genenames <- unique(mgsub::mgsub(pattern=c("_PPP.csv","_PPN.csv","_PN.csv"),replacement=c("","",""),string=genenames) )


# save a csv per mouse gene
for (i in levels(as.factor(genenames))){
  print(i)
  # first column of the table - vs human positive correlated
  col1 <- as.data.frame(read.csv(files1[grepl(paste0("_",i,"_"),files1)])) ; col1 <- col1[!grepl("[::alpha::]",col1$corr),] ; col1$corr <- as.numeric(col1$corr) # load and remove rows with errors
  col1 <- col1[col1[,2]==i,]   # in case there was a mistake somewhere, keep just rows in which source gene is i
  col1_f <- col1[order(col1$corr,decreasing=TRUE),] ; col1_f <- col1_f[col1$corr<1,] ; col1_f <- col1_f[c(1:30),] # not if corr is ==1 (corr with itself) and take just 30 first (max table size)
  # second column of the table - vs mouse positive correlated
  col2 <- as.data.frame(read.csv(files2[grepl(paste0("_",i,"_"),files2)])) ; col2 <- col2[!grepl("[::alpha::]",col2$corr),] ; col2$corr <- as.numeric(col2$corr)
  col2 <- col2[col2[,2]==i,]   # in case there was a mistake somewhere, keep just rows in which source gene is i
  col2_f <- col2[order(col2$corr,decreasing=TRUE),] ; col2_f <- col2_f[col2_f$corr<1,]; col2_f <- col2_f[c(1:30),]
  # third column of the table - vs org positive correlated
  col3 <- as.data.frame(read.csv(files3[grepl(paste0("_",i,"_"),files3)])) ; col3 <- col3[!grepl("[::alpha::]",col3$corr),] ; col3$corr <- as.numeric(col3$corr)
  col3 <- col3[col3[,2]==i,]   # in case there was a mistake somewhere, keep just rows in which source gene is i
  col3_f <- col3[order(col3$corr,decreasing=TRUE),] ; col3_f <- col3_f[col3_f$corr<1,]  ; col3_f <- col3_f[c(1:30),]
  # fourth column of the table - intraspecies negative correlated
  col4 <- as.data.frame(read.csv(files3[grepl(paste0("_",i,"_"),files3)])) ; col4 <- col4[!grepl("[::alpha::]",col4$corr),] ; col4$corr <- as.numeric(col4$corr)
  col4 <- col4[col4[,2]==i,] # in case there was a mistake somewhere, keep just rows in which source gene is i
  col4_f <- col4[col4$corr<0,] ;
  col4_f <- col4_f[order(col4_f$corr,decreasing=FALSE),] ; col4_f <- col4_f[c(1:30),]
  
  # get gene names from each and populate df with 4 columns
  df <- data.frame(ref_gene=paste0(i,"_O"),corr_human=col1_f[,3],corr_mouse=col2_f[,3],corr_org=col3_f[,3],anticorr_intra=col4_f[,3])
  
  write.csv(df,paste0("humous_v3/out/website/corr_pairw_tables_2/corr_pairw_O/",i,"_O.csv"),row.names = FALSE)
}
#####################

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 





























  
  type <- df_landscape_indexing_web$type_human[df_landscape_indexing_web$gene==gene]
  
  if (type=="D"){
    HM_df <- expand.grid(gene,rownames(L_MR_M_f)[rownames(L_MR_M_f) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_mouse=="D"]]) ; colnames(HM_df) <- c("human_genes","mouse_genes") 
    HM_df$corr <- NA  # create column to store results
    for (j in 1:nrow(HM_df)){ # launch loop
      HM_df$corr[j] <- L_TH_BoosCorr(gene1=HM_df$human_genes[j],gene2=HM_df$mouse_genes[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_M_f)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/HM/HM_pairwcorr_",gene,".csv"))

  }else if(type=="N"){
    HM_df <- expand.grid(gene,rownames(L_MR_M_f)[rownames(L_MR_M_f) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_mouse=="N"]]) ; colnames(HM_df) <- c("human_genes","mouse_genes") 
    HM_df$corr <- NA  # create column to store results
    for (j in 1:nrow(HM_df)){ # launch loop
      HM_df$corr[j] <- L_TH_BoosCorr(gene1=HM_df$human_genes[j],gene2=HM_df$mouse_genes[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_M_f)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/HM/HM_pairwcorr_",gene,".csv"))
    
  }else if(type %in% c("PN","PPN","PPP")){
    HM_df <- expand.grid(gene,rownames(L_MR_M_f)[rownames(L_MR_M_f) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_mouse %in% c("PN","PPN","PPP")]]) ; colnames(HM_df) <- c("human_genes","mouse_genes") 
    HM_df$corr <- NA  # create column to store results
    for (j in 1:nrow(HM_df)){ # launch loop
      HM_df$corr[j] <- L_TH_BoosCorr(gene1=HM_df$human_genes[j],gene2=HM_df$mouse_genes[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_M_f)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/HM/HM_pairwcorr_",gene,".csv"))
  }else{"do nothing"}

  # HUMAN VS HORG
  # find which type is the gene in human
  type <- df_landscape_indexing_web$type_human[df_landscape_indexing_web$gene==gene]
  
  if (type=="D"){
    HO_df <- expand.grid(gene,rownames(L_MR_O)[rownames(L_MR_O) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg=="D"]]) ; colnames(HO_df) <- c("human_genes","horg_genes") 
    HO_df$corr <- NA  # create column to store results
    for (j in 1:nrow(HO_df)){ # launch loop
      HO_df$corr[j] <- L_TH_BoosCorr(gene1=HO_df$human_genes[j],gene2=HO_df$horg_genes[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_O)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/HO/HO_pairwcorr_",gene,".csv"))
    
  }else if(type=="N"){
    HO_df <- expand.grid(gene,rownames(L_MR_O)[rownames(L_MR_O) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg=="N"]]) ; colnames(HO_df) <- c("human_genes","horg_genes") 
    HO_df$corr <- NA  # create column to store results
    for (j in 1:nrow(HO_df)){ # launch loop
      HO_df$corr[j] <- L_TH_BoosCorr(gene1=HO_df$human_genes[j],gene2=HO_df$horg_genes[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_O)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/HO/HO_pairwcorr_",gene,".csv"))
    
  }else if(type %in% c("PN","PPN","PPP")){
    HO_df <- expand.grid(gene,rownames(L_MR_O)[rownames(L_MR_O) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg %in% c("PN","PPN","PPP")]]) ; colnames(HO_df) <- c("human_genes","horg_genes") 
    HO_df$corr <- NA  # create column to store results
    for (j in 1:nrow(HO_df)){ # launch loop
      HO_df$corr[j] <- L_TH_BoosCorr(gene1=HO_df$human_genes[j],gene2=HO_df$horg_genes[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_O)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/HO/HO_pairwcorr_",gene,".csv"))
  }else{"do nothing"}
  
  
  # MOUSE VS HORG
  # find which type is the gene in mouse
  type <- df_landscape_indexing_web$type_mouse[df_landscape_indexing_web$gene==gene]
  
  if (type=="D"){
    MO_df <- expand.grid(gene,rownames(L_MR_O)[rownames(L_MR_O) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg=="D"]]) ; colnames(MO_df) <- c("mouse_genes","horg_genes") 
    MO_df$corr <- NA  # create column to store results
    for (j in 1:nrow(MO_df)){ # launch loop
      MO_df$corr[j] <- L_TH_BoosCorr(gene1=MO_df$mouse_genes[j],gene2=MO_df$horg_genes[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_O)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/MO/MO_pairwcorr_",gene,".csv"))
    
  }else if(type=="N"){
    MO_df <- expand.grid(gene,rownames(L_MR_O)[rownames(L_MR_O) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg=="N"]]) ; colnames(MO_df) <- c("mouse_genes","horg_genes") 
    MO_df$corr <- NA  # create column to store results
    for (j in 1:nrow(MO_df)){ # launch loop
      MO_df$corr[j] <- L_TH_BoosCorr(gene1=MO_df$mouse_genes[j],gene2=MO_df$horg_genes[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_O)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/MO/MO_pairwcorr_",gene,".csv"))
    
  }else if(type %in% c("PN","PPN","PPP")){
    MO_df <- expand.grid(gene,rownames(L_MR_O)[rownames(L_MR_O) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg %in% c("PN","PPN","PPP")]]) ; colnames(MO_df) <- c("mouse_genes","horg_genes") 
    MO_df$corr <- NA  # create column to store results
    for (j in 1:nrow(MO_df)){ # launch loop
      MO_df$corr[j] <- L_TH_BoosCorr(gene1=MO_df$mouse_genes[j],gene2=MO_df$horg_genes[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_O)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/MO/MO_pairwcorr_",gene,".csv"))
  }else{"do nothing"}
  
  # MOUSE VS MOUSE
  # find which type is the gene in mouse
  type <- df_landscape_indexing_web$type_mouse[df_landscape_indexing_web$gene==gene]
  
  if (type=="D"){
    MM_df <- expand.grid(gene,rownames(L_MR_M_f)[rownames(L_MR_M_f) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg=="D"]]) ; colnames(MM_df) <- c("mouse_genes","mouse_genes2") 
    MM_df$corr <- NA  # create column to store results
    for (j in 1:nrow(MM_df)){ # launch loop
      MM_df$corr[j] <- L_TH_BoosCorr(gene1=MM_df$mouse_genes[j],gene2=MM_df$mouse_genes2[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_M_f)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/MM/MM_pairwcorr_",gene,".csv"))
    
  }else if(type=="N"){
    MM_df <- expand.grid(gene,rownames(L_MR_M_f)[rownames(L_MR_M_f) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg=="N"]]) ; colnames(MM_df) <- c("mouse_genes","mouse_genes2") 
    MM_df$corr <- NA  # create column to store results
    for (j in 1:nrow(MM_df)){ # launch loop
      MM_df$corr[j] <- L_TH_BoosCorr(gene1=MM_df$mouse_genes[j],gene2=MM_df$mouse_genes2[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_M_f)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/MM/MM_pairwcorr_",gene,".csv"))
    
  }else if(type %in% c("PN","PPN","PPP")){
    MM_df <- expand.grid(gene,rownames(L_MR_M_f)[rownames(L_MR_M_f) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg %in% c("PN","PPN","PPP")]]) ; colnames(MM_df) <- c("mouse_genes","mouse_genes2") 
    MM_df$corr <- NA  # create column to store results
    for (j in 1:nrow(MM_df)){ # launch loop
      MM_df$corr[j] <- L_TH_BoosCorr(gene1=MM_df$mouse_genes[j],gene2=MM_df$mouse_genes2[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_M_f)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/MM/MM_pairwcorr_",gene,".csv"))
  }else{"do nothing"}
  
  
  # HUMAN VS HUMAN
  # find which type is the gene in mouse
  type <- df_landscape_indexing_web$type_human[df_landscape_indexing_web$gene==gene]
  
  if (type=="D"){
    HH_df <- expand.grid(gene,rownames(L_MR_M_f)[rownames(L_MR_M_f) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg=="D"]]) ; colnames(HH_df) <- c("mouse_genes","mouse_genes2") 
    HH_df$corr <- NA  # create column to store results
    for (j in 1:nrow(HH_df)){ # launch loop
      HH_df$corr[j] <- L_TH_BoosCorr(gene1=HH_df$mouse_genes[j],gene2=HH_df$mouse_genes2[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_M_f)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/HH/HH_pairwcorr_",gene,".csv"))
    
  }else if(type=="N"){
    HH_df <- expand.grid(gene,rownames(L_MR_M_f)[rownames(L_MR_M_f) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg=="N"]]) ; colnames(HH_df) <- c("mouse_genes","mouse_genes2") 
    HH_df$corr <- NA  # create column to store results
    for (j in 1:nrow(HH_df)){ # launch loop
      HH_df$corr[j] <- L_TH_BoosCorr(gene1=HH_df$mouse_genes[j],gene2=HH_df$mouse_genes2[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_M_f)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/HH/HH_pairwcorr_",gene,".csv"))
    
  }else if(type %in% c("PN","PPN","PPP")){
    HH_df <- expand.grid(gene,rownames(L_MR_M_f)[rownames(L_MR_M_f) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg %in% c("PN","PPN","PPP")]]) ; colnames(HH_df) <- c("mouse_genes","mouse_genes2") 
    HH_df$corr <- NA  # create column to store results
    for (j in 1:nrow(HH_df)){ # launch loop
      HH_df$corr[j] <- L_TH_BoosCorr(gene1=HH_df$mouse_genes[j],gene2=HH_df$mouse_genes2[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_M_f)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/HH/HH_pairwcorr_",gene,".csv"))
  }else{"do nothing"}
  
  
  # HORG VS HORG
  # find which type is the gene in mouse
  type <- df_landscape_indexing_web$type_human[df_landscape_indexing_web$gene==gene]
  
  if (type=="D"){
    OO_df <- expand.grid(gene,rownames(L_MR_M_f)[rownames(L_MR_M_f) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg=="D"]]) ; colnames(OO_df) <- c("org_genes","org_genes2") 
    OO_df$corr <- NA  # create column to store resulHts
    for (j in 1:nrow(OO_df)){ # launch loop
      OO_df$corr[j] <- L_TH_BoosCorr(gene1=OO_df$org_genes[j],gene2=OO_df$org_genes2[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_M_f)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/OO/OO_pairwcorr_",gene,".csv"))
    
  }else if(type=="N"){
    OO_df <- expand.grid(gene,rownames(L_MR_M_f)[rownames(L_MR_M_f) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg=="N"]]) ; colnames(OO_df) <- c("org_genes","org_genes2") 
    OO_df$corr <- NA  # create column to store results
    for (j in 1:nrow(OO_df)){ # launch loop
      OO_df$corr[j] <- L_TH_BoosCorr(gene1=OO_df$org_genes[j],gene2=OO_df$org_genes2[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_M_f)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/OO/OO_pairwcorr_",gene,".csv"))
    
  }else if(type %in% c("PN","PPN","PPP")){
    OO_df <- expand.grid(gene,rownames(L_MR_M_f)[rownames(L_MR_M_f) %in% df_landscape_indexing_web$gene[df_landscape_indexing_web$type_horg %in% c("PN","PPN","PPP")]]) ; colnames(OO_df) <- c("org_genes","org_genes2") 
    OO_df$corr <- NA  # create column to store results
    for (j in 1:nrow(OO_df)){ # launch loop
      OO_df$corr[j] <- L_TH_BoosCorr(gene1=OO_df$org_genes[j],gene2=OO_df$org_genes2[j],threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_M_f)$corr
    } ; write.csv(paste0("humous_v3/out/corrL/OO/OO_pairwcorr_",gene,".csv"))
  }else{"do nothing"}
  

  
}


# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 




















# in L_MR_M, change gene names for human orths
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
# load list of mouse genenames that dont have human orthologs and remove them from L_MR_M
mousegenes_NoHorth <- read_csv("humous_v3/out/landsM/mousegenes_NoHorth.csv")
L_MR_M_f <- L_MR_M[ ! rownames(L_MR_M) %in% mousegenes_NoHorth$x ,,]
# ORTHOLOG RENAMING of mouse genes with orths
landsnames <- data.frame(M=rownames(L_MR_M_f),Horth=NA)
ortholog <- as.data.frame(read.csv("humous_v3/data/MH_orthologs.csv"))
landsnames$Horth <- ortholog$hsa[match(landsnames$M,ortholog$mmu)]  
landsnames$MHconsensus <- ifelse(is.na(landsnames$Horth),as.character(landsnames$M),as.character(landsnames$Horth))
# rename landscapes in L_MR_M so the ones with Horths are called as the human gene and others keep the mouse name
rownames(L_MR_M_f) <- landsnames$MHconsensus
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



# from inception v3 results, load the landscapes for which we want to calculate correlations - H or P (PN, PPN, PPP)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
merged_2 <- read.csv("humous_v3/out/inceptionv3/inception_v3_iterativeclustering/merged_2.csv")
table(merged_2$species,merged_2$L_type)
# remove dotties from merged_2 (the only landscapes for which we dont want to calculate corrs)
merged_2 <- merged_2[ ! merged_2$L_type %in% "D",]
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



# SAME GENE ACROSS SPECIES CORRELATIONS (NON-PAIRWISE)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
# load the csv with gene names that is used for the website
    # has the mouse gene names as orthologs (upper case) so it does not match with names in L_MR_M

# load list of mouse genenames that dont have human orthologs and remove them from L_MR_M
mousegenes_NoHorth <- read_csv("humous_v3/out/landsM/mousegenes_NoHorth.csv")
L_MR_M_f <- L_MR_M[ ! rownames(L_MR_M) %in% mousegenes_NoHorth$x ,,]

# ORTHOLOG RENAMING of mouse genes with orths
landsnames <- data.frame(M=rownames(L_MR_M_f),Horth=NA)
ortholog <- as.data.frame(read.csv("humous_v3/data/MH_orthologs.csv"))
landsnames$Horth <- ortholog$hsa[match(landsnames$M,ortholog$mmu)]  
landsnames$MHconsensus <- ifelse(is.na(landsnames$Horth),as.character(landsnames$M),as.character(landsnames$Horth))
# rename landscapes in L_MR_M so the ones with Horths are called as the human gene and others keep the mouse name
rownames(L_MR_M_f) <- landsnames$MHconsensus

# load df for landscape indexing used on the website
df_landscape_indexing_web <- read_csv("humous_v3/out/website/df_landscape_indexing_web.csv")

# for each gene in df_landscape_indexing_web, calculate species-to-species correlations (some will be NA)
df_corr_nopairwise <- data.frame(genenames=df_landscape_indexing_web$gene,corr_HvsM=NA,corr_HvsO=NA,corr_MvsO=NA,stringsAsFactors=FALSE)

for (i in 1:nrow(df_corr_nopairwise)){
  
  gene <- df_corr_nopairwise$genenames[i] ; print(gene)
  
  if( df_landscape_indexing_web$human[df_landscape_indexing_web$gene==gene]=="yes" & df_landscape_indexing_web$mouse[df_landscape_indexing_web$gene==gene]=="yes" ){
    df_corr_nopairwise$corr_HvsM[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genenames[i],gene2=df_corr_nopairwise$genenames[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_M_f)$corr
  }else{"do nothing"}
  
  if( df_landscape_indexing_web$human[df_landscape_indexing_web$gene==gene]=="yes" & df_landscape_indexing_web$horg[df_landscape_indexing_web$gene==gene]=="yes" ){
    df_corr_nopairwise$corr_HvsO[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genenames[i],gene2=df_corr_nopairwise$genenames[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_O)$corr
  }else{"do nothing"}
  
  if( df_landscape_indexing_web$mouse[df_landscape_indexing_web$gene==gene]=="yes" & df_landscape_indexing_web$horg[df_landscape_indexing_web$gene==gene]=="yes" ){
    df_corr_nopairwise$corr_MvsO[i] <- L_TH_BoosCorr(gene1=df_corr_nopairwise$genenames[i],gene2=df_corr_nopairwise$genenames[i],
                                                     threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_M_f,L2=L_MR_O)$corr
  }else{"do nothing"}

}

#write.csv(df_corr_nopairwise,"humous_v3/out/corrL/df_corr_nopairwise.csv",row.names=FALSE)
df_corr_nopairwise <- read.csv("humous_v3/out/corrL/df_corr_nopairwise.csv")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# check how the correlations look like
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

ggplot(df_corr_nopairwise) + geom_point(aes(corr_HvsM,corr_HvsO)) + theme_classic() + 
  geom_label(data=df_corr_nopairwise[df_corr_nopairwise$genenames %in% c("SOX2","JUNB","APBB2","EOMES"),],
             mapping=aes(corr_HvsM,corr_HvsO,label=genenames))

plot_ly(df_corr_nopairwise, x = ~corr_MvsO, y = ~corr_HvsM, z = ~corr_HvsO,size=df_corr_nopairwise$corr_HvsM)

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
















# subset landscapes objects to keep just the landscapes in merged_2
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
L_MR_H_f <- L_MR_H[gsub("_H","",merged_2$L_name[merged_2$species=="H"]),,] ; dim(L_MR_H_f)
L_MR_M_f <- L_MR_M[gsub("_M","",merged_2$L_name[merged_2$species=="M"]),,] ; dim(L_MR_M_f)
L_MR_O_f <- L_MR_O[gsub("_O","",merged_2$L_name[merged_2$species=="O"]),,] ; dim(L_MR_O_f)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# PAIRWISE CORRELATIONS

# H - M correlations
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

# create long format dataframe (edgelist form) with all the possible combinations of human and mouse genes
HM_df <- expand.grid(rownames(L_MR_H_f),rownames(L_MR_M_f)) ; colnames(HM_df) <- c("human_genes","mouse_genes") ; dim(HM_df)
# create pasted from Human and Mouse gene names to be able to call the L_TH_BoosCorr function
HM_df$pastednames <- paste0(HM_df$human_genes,"_",HM_df$mouse_genes)
# define a NA vector in HM_df to store results from correlation function
HM_df$corrL <- NA

# how many cores do I have available?
parallel::detectCores() # 128
# given that this will take forever, run it in batches to have an idea of the progress
# break down HM_df in a multiple of the number of nrow(HM_df)
divisors <- seq(1:1000)[nrow(HM_df) %% seq(1:1000) == 0] # I choose 903 ; 143082156/903=158495 
# split HM_df into equal size chunks of 130678 rows and store in list
HM_df_list <- split(HM_df,rep(1:903,each=158495,length.out=nrow(HM_df))) # 903 batches - each has 158495 rows

# launch correlation loop with parallelization, save each list separatedly cause it will take very long
for (i in 1:length(HM_df_list)){
  
  print(paste("calculating on split",i))
  
  HMcorr <- simplify2array(mclapply(mc.cores=40, HM_df_list[[i]]$pastednames ,function(x){
    L_TH_BoosCorr(gene1=gsub("_.*","",x),gene2=gsub(".*_","",x),threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H_f,L2=L_MR_M_f)$corr
  }))
  
  HM_df_list[[i]]$corrL <- HMcorr
  saveRDS(HM_df_list[[i]],paste0("humous_v3/out/corrL/HM/HMcorr_splits/HMsplit",i,".rds"))
}

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 




trial <- L_TH_BoosCorr(gene1=gsub("_.*","","ADCY1_0610010F05Rik"),gene2=gsub(".*_","","ADCY1_0610010F05Rik"),threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_M)$corr







rowmultiples <- (seq(1:1000) %% nrow(HM_df)) == 0 ; c(1000000:10000000)[rowmultiples]

coremultiples = (100000:10000000 %% 128) == 0 ; coremultiples <- c(100000:10000000)[coremultiples]
rowmultiples <- (coremultiples %% nrow(HM_df)) == 0 ; tail(coremultiples[rowmultiples])


HM_df_batch1 <- 
  
parallel::detectCores()
HMcorr <- simplify2array(mclapply(mc.cores=16, HM_df$pastednames[1:2] ,function(i){
  L_TH_BoosCorr(gene1=gsub("_.*","",i),gene2=gsub(".*_","",i),threshold=0.3,n_boosts=10,boostsize=2000,L1=L_MR_H,L2=L_MR_M)$corr
}))





# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 








# Human - Mouse Correlations
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# PREPROCESS TO MATCH BY ORTHOLOGS
#######################################
# for this to be easily comparable, I will use just orthologs - subset landscapes to keep just orths and rename mouse genes
ortholog <- readRDS("~/humous/data/ortholog.rds") 
ortholog <- as.data.frame(ortholog[complete.cases(ortholog),]) # 12204 genes

# filter ortholog table to keep just genes present both in human and mouse
ortholog_f <- ortholog[gsub("hsa/","",ortholog$hsa) %in% rownames(L_MR_H),] # 11277 genes
ortholog_f <- ortholog_f[gsub("mmu/","",ortholog_f$mmu) %in% rownames(L_MR_M),] # 10209 genes

# first filtering - filter landscapes objects to just keep genes with orthologs 
L_MR_H_orth <- L_MR_H[gsub("hsa/","",ortholog_f$hsa),,] # filter human landscapes to keep just genes with orthologs
L_MR_M_orth <- L_MR_M[gsub("mmu/","",ortholog_f$mmu),,] # filter mouse landscapes to heep just genes with orthologs

# change mouse gene names in L_MR_M_orth by the corresponding human genes
rownames(L_MR_M_orth) <- gsub("hsa/","",ortholog_f$hsa)[match(rownames(L_MR_M_orth),gsub("mmu/","",ortholog_f$mmu))]

# second filtering - there are still some genes not present in both because they don't have the same name even if they are orths, keep just common
common <- intersect(rownames(L_MR_H_orth),rownames(L_MR_M_orth))
L_MR_H_orth <- L_MR_H_orth[common,,] ; dim(L_MR_H_orth) ; L_MR_M_orth <- L_MR_M_orth[common,,] ; dim(L_MR_M_orth)

# which are the genes with H-M orthologs but not the same name?


# save orth matched landscapes objects
#saveRDS(L_MR_H_orth,"humous_v3/out/landsH/L_MR_H_orth.rds")
#saveRDS(L_MR_M_orth,"humous_v3/out/landsM/L_MR_M_orth.rds")

#######################################


# CALCULATE CORRELATIONS 
#######################################

# trial for one gene
L_TH_BoosCorr_lm(gene="JUNB",threshold=0.3,n_boosts=100,boostsize=2000,L1=L_MR_H_orth,L2=L_MR_M_orth)

# execute it for all genes in parallel
parallel::detectCores()
HMcorr <- simplify2array(mclapply(mc.cores=16, rownames(L_MR_H_orth),function(i){
  L_TH_BoosCorr_lm(gene=i,threshold=0.3,n_boosts=100,boostsize=2000,L1=L_MR_H_orth,L2=L_MR_M_orth)$corr
}))

names(HMcorr) <- rownames(L_MR_H_orth)

# plot correlations
hist(HMcorr)
#######################################




# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 




# Find Human to Human Correlations
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

HvsH_TH_B_corr <- data.frame(gene=c(rownames(L_MR_H)),corr=NA,corrsd=NA,dimTH_L=NA,stringsAsFactors=FALSE)


# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 





# LAUNCH L_TH_BoosCorr_lm FOR HUMAN vs MOUSE (L_TH_BoosCorr_lm function called from library)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

HvsM_TH_B_corr <- data.frame(gene=c(rownames(L_MR_H),rownames(L_MR_M)),corr=NA,corrsd=NA,dimTH_L=NA,stringsAsFactors=FALSE)

for (i in levels(as.factor(HvsM_TH_B_corr$gene))){
  print(i)
  tryCatch({
    HvsM_TH_B_corr$corr[HvsM_TH_B_corr$gene==i] <- L_TH_BoosCorr_lm(gene=i,threshold=0.3,n_boosts=100,boostsize=2000,L1=L_MR_H,L2=L_MR_M)$corr
    HvsM_TH_B_corr$corrsd[HvsM_TH_B_corr$gene==i] <- L_TH_BoosCorr_lm(gene=i,threshold=0.3,n_boosts=100,boostsize=2000,L1=L_MR_H,L2=L_MR_M)$corrsd
    HvsM_TH_B_corr$dimTH_L[HvsM_TH_B_corr$gene==i] <- L_TH_BoosCorr_lm(gene=i,threshold=0.3,n_boosts=100,boostsize=2000,L1=L_MR_H,L2=L_MR_M)$dimTH_L
  },error = function(e) {
    message("gene not expressed in both species")
    message(e)
  })
}
#saveRDS(HvsM_TH_B_corr,"humous_v2/out/TH_B_corr_landscapes/HvsM_TH_B_corr.rds")
HvsM_TH_B_corr <- readRDS("humous_v2/out/TH_B_corr_landscapes/HvsM_TH_B_corr.rds")

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
