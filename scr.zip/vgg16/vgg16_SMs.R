
# VGG16 embeddings of SMs

# setup keras
library(reticulate)
Sys.setenv("RETICULATE_MINICONDA_ENABLED" = TRUE) # make sure that reticulate can use miniconda
reticulate::use_miniconda(condaenv = "minic_py37", required = T) 
reticulate::py_config() # verification
library(keras)
library(tensorflow)
# load vgg16 model
model <- keras::application_vgg16(weights="imagenet",include_top = FALSE)
# load r packages
library(tidyverse) ; library(imager) ; library(magick)  # for preprocessing images
library(raster) ; library(dplyr) ; library(maptools) ; library(png) ; library(rgdal) ; library(microbenchmark)
library(rasterVis) ; library(cowplot) ; library(umap); library(Seurat) ; library(parallel) 


# DEFINE FUNCTION FOR RESHAPING PNGS OF LANDSCAPES TO THE FORMAT NEDDED BY THE vgg16 MODEL 
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
image_prep <- function(filepath, size=224) {
  tryCatch(
    {
      img <- readPNG(filepath)
      x <- image_to_array(img) 
      #x <- array_reshape(x, c(1, dim(x)))
      # resize
      img <- image_read(filepath)
      img_resized <- image_resize(img, paste0(size, "x", size, "!")) # "!" forces exact size
      # Convert back to array (RGB values 0-255)
      img_array <- as.integer(image_data(img_resized)) #  224 224   3
      # Normalize to 0-1 and apply channel corrections expected by vgg16 RGB
      img_array <- img_array / 255
      # add batch dimension
      img_array <- array_reshape(img_array, c(1, dim(img_array)))
      img_preprocessed <- imagenet_preprocess_input(img_array, mode = "caffe")
      return(img_preprocessed)
    },
    error = function(e){
      return(NA)
    }
  )
} 
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #



# Embed HvsO SMs
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
file_list_HvsO <- list.files("humous_v4/out/temporal_shifts/SMs_vgg16/SMs_HvsO/", full.names = TRUE, recursive = FALSE)
vgg16_feature_list_HvsO <- vector(mode="list",length=length(file_list_HvsO))
for (i in 1:length(file_list_HvsO)) {
  print(i)
  vgg16_feature <- predict(model, image_prep(file_list_HvsO[i])) # dim [1,1_7,1:7,1:512]
  flatten <- as.data.frame.table(vgg16_feature, responseName = "value") %>% dplyr::select(value) #  25088     1
  vgg16_feature_list_HvsO[[i]] <-  cbind(i, as.data.frame(t(flatten)))
  if(i %in% c(seq(1000,20000,1000))){gc()}
}
HvsO_vgg16 <- do.call("rbind",vgg16_feature_list_HvsO)
HvsO_vgg16$i <- NULL ; rownames(HvsO_vgg16) <- mgsub::mgsub(file_list_HvsO,pattern=c("humous_v4/out/temporal_shifts/SMs_vgg16/SMs_HvsO//",".png"),replacement=c("",""))
#saveRDS(HvsO_vgg16,"humous_v4/out/temporal_shifts/SMs_vgg16/HvsO_vgg16.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #


# Embed HvsM SMs
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #
file_list_HvsM <- list.files("humous_v4/out/temporal_shifts/SMs_vgg16/SMs_HvsM/", full.names = TRUE, recursive = FALSE)
vgg16_feature_list_HvsM <- vector(mode="list",length=length(file_list_HvsM))
for (i in 1:length(file_list_HvsM)) {
  print(i)
  vgg16_feature <- predict(model, image_prep(file_list_HvsM[i])) # dim [1,1_7,1:7,1:512]
  flatten <- as.data.frame.table(vgg16_feature, responseName = "value") %>% dplyr::select(value) #  25088     1
  vgg16_feature_list_HvsM[[i]] <-  cbind(i, as.data.frame(t(flatten)))
  if(i %in% c(seq(1000,20000,1000))){gc()}
}
HvsM_vgg16 <- do.call("rbind",vgg16_feature_list_HvsM)
HvsM_vgg16$i <- NULL ; rownames(HvsM_vgg16) <- mgsub::mgsub(file_list_HvsM,pattern=c("humous_v4/out/temporal_shifts/SMs_vgg16/SMs_HvsM//",".png"),replacement=c("",""))
#saveRDS(HvsM_vgg16,"humous_v4/out/temporal_shifts/SMs_vgg16/HvsM_vgg16.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #



# Clustering vgg16 Hvs0 SMs
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #

# load matrices with SM vgg16 weights and create seurat object annotated by species comparison type

# SMs_vgg16_S <- local({
#   SMs_vgg16_S_HvsO <- CreateSeuratObject(t(HvsO_vgg16)) ; SMs_vgg16_S_HvsO$comparison <- "HvsO" 
#   SMs_vgg16_S_HvsM <- CreateSeuratObject(t(HvsM_vgg16)) ; SMs_vgg16_S_HvsM$comparison <- "HvsM" 
#   SMs_vgg16_S <- merge(SMs_vgg16_S_HvsO,SMs_vgg16_S_HvsM)
# })
# 
# SMs_vgg16_S <- SMs_vgg16_S %>% NormalizeData() %>% FindVariableFeatures() %>% ScaleData() %>% RunPCA
# SMs_vgg16_S <- RunUMAP(SMs_vgg16_S, dims = 1:15)
#saveRDS(SMs_vgg16_S,"humous_v4/out/temporal_shifts/SMs_vgg16/Seurat_SMs_vgg16.rds")

SMs_vgg16_S <- readRDS("~/humous/humous_v4/out/temporal_shifts/SMs_vgg16/Seurat_SMs_vgg16.rds")

SMs_vgg16_S <- FindVariableFeatures(SMs_vgg16_S)
SMs_vgg16_S <- SMs_vgg16_S %>% NormalizeData() %>% RunPCA() %>% RunUMAP(reduction="pca",dims=1:15)
SMs_vgg16_S <- FindNeighbors(SMs_vgg16_S,reduction = "umap",dims=1:2)
SMs_vgg16_S <- FindClusters(SMs_vgg16_S)

umap <- as.data.frame(SMs_vgg16_S@reductions$umap@cell.embeddings) ; umap$comparison <- SMs_vgg16_S$comparison
umap$clusters <- SMs_vgg16_S$RNA_snn_res.0.8 ; umap$names <- rownames(umap)

ggplot(umap) + geom_point(aes(umap$UMAP_1,umap$UMAP_2,col=umap$clusters)) + theme_classic()


# view one png
img1 <- readPNG("humous_v4/out/temporal_shifts/SMs_vgg16/SMs_HvsM/LIPG_HvsM.png")
grid::grid.raster(img1)
img2 <- readPNG("humous_v4/out/temporal_shifts/SMs_vgg16/SMs_HvsM/NFE2L2_HvsM.png")
grid::grid.raster(img2)

# view the averaged png of all the pngs for each cluster - condition
img_list_HM <- lapply(paste0("humous_v4/out/temporal_shifts/SMs_vgg16/SMs_HvsM/",umap$names[umap$comparison=="HvsM" & umap$clusters=="0"],".png"), readPNG)
img_array_HM <- simplify2array(img_list_HM)
avg_img_HM <- apply(img_array_HM, c(1, 2, 3), mean)
grid::grid.raster(avg_img_HM)

img_list_HO <- lapply(paste0("humous_v4/out/temporal_shifts/SMs_vgg16/SMs_HvsO/",umap$names[umap$comparison=="HvsO" & umap$clusters=="17"],".png"), readPNG)
img_array_HO <- simplify2array(img_list_HO)
avg_img_HO <- apply(img_array_HO, c(1, 2, 3), mean)
grid::grid.raster(avg_img_HO)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- #








