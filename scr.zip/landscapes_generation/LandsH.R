

# LANDSCAPES CALCULATION HUMAN

source("humous_v3/lib/lib_misc.R")
source("humous_v3/lib/lib_lands.R")

library(Seurat) ; library(SeuratObject) ; library(dplyr) ; library(ggplot2) ; library(png)

# Load data (result from integration and ordis) - 
# contains cells for landscapes and ordis normalized
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
IntH_ordi <- readRDS("~/humous/humous_v3/out/ordiH/IntH_ordi_new.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# Preprocess datasets for landscapes
# Using RNA assay, keep genes expressed in all datasets and scale data slot of RNA for nfeatures
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

DefaultAssay(IntH_ordi) <- "RNA" ; IntH_ordi[['integrated']] <- NULL 

# GENE SELECTION
###################

# CHANGE THE FUNCTION SO NO GROUPING IS INCLUDED 
  # (this is the change respect to version 3 - the grouping excluded genes that were present only in certain datasets)

# old criteria - I keep it here for comparison purposes
# genestokeep_h_old <- gene_selector(seuratobj=IntH_ordi,grouping=IntH_ordi$dataset,threshold_grouping=0,threshold_ncells=9)

# subset to keep just genes expressed in more than 1% of the cells across datasets 
num_positive <- apply(IntH_ordi@assays$RNA@counts > 0, 1, sum)
genestokeep_h <- rownames(IntH_ordi)[num_positive > round(1/100 * ncol(IntH_ordi)) ] # 1%
table(grepl("ARHGAP11B",genestokeep_h)) # this is a gene we were loosing before and now we keep

LandsS_H <- subset(IntH_ordi,features = genestokeep_h)
###################


# DATA SCALING AND SAVING
###################
# scale data slot for nfeatures on all genes and correct it so it doesnt have negative values
LandsS_H <- LandsS_H %>% NormalizeData() %>% ScaleData(vars.to.regress="nFeature_RNA",features=rownames(LandsS_H)) # rang_expr <- range(IntH_ordi@assays$RNA@scale.data)
LandsS_H@assays$RNA@scale.data <- LandsS_H@assays$RNA@scale.data + abs(min(LandsS_H@assays$RNA@scale.data))
#saveRDS(LandsS_H,"humous_v4/out/landsH/LandsS_H.rds")
LandsS_H <- readRDS("humous_v4/out/landsH/LandsS_H.rds")
###################


# VISUALIZATION
# check if gene expression makes sense in scale.data scatter
LandsS_H$SOX2 <- LandsS_H@assays$RNA@scale.data["SOX2",] ; LandsS_H$EOMES <- LandsS_H@assays$RNA@scale.data["EOMES",] ; LandsS_H$NEUROD6 <- LandsS_H@assays$RNA@scale.data["NEUROD6",]
LandsS_H$JUNB <- LandsS_H@assays$RNA@scale.data["JUNB",] ; LandsS_H$APBB2 <- LandsS_H@assays$RNA@scale.data["APBB2",] ; LandsS_H$MEF2C <- LandsS_H@assays$RNA@scale.data["MEF2C",]
ggplot(LandsS_H@meta.data) + geom_point(aes(ordi_age_norm,ordi_diff_norm,color=EOMES)) + scale_color_gradient2(low="white",mid="grey",high="red",midpoint = 6)

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# GRIDS generation
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
gridlistH <- list(grid_medR=knn_array_medres(LandsS_H$ordi_age_norm,LandsS_H$ordi_diff_norm,k=100L),
                  grid_lowR=knn_array_lowres(LandsS_H$ordi_age_norm,LandsS_H$ordi_diff_norm,k=100L),
                  grid_highR=knn_array_highres(LandsS_H$ordi_age_norm,LandsS_H$ordi_diff_norm,k=100L))
#saveRDS(gridlistH,"humous_v4/out/landsH/gridlistH.rds")
gridlistH <- readRDS("humous_v4/out/landsH/gridlistH.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# COMPUTE LANDSCAPES
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

# trial for key genes
L_MR_H <- local({
  m <- LandsS_H@assays$RNA@scale.data[c("SOX2","EOMES","NEUROD6","JUNB","APBB2","MEF2C"),]
  landscapes_MR_H <- knn_rowMeans(m,gridlistH$grid_medR) ; rownames(landscapes_MR_H) <- rownames(m) ; landscapes_MR_H
})

gridExtra::grid.arrange(as.array(L_MR_H["SOX2",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster() + ggtitle("SOX2"),
                        as.array(L_MR_H["EOMES",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("EOMES") ,
                        as.array(L_MR_H["NEUROD6",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("NEUROD6"), 
                        as.array(L_MR_H["JUNB",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster() + ggtitle("JUNB"),
                        as.array(L_MR_H["APBB2",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("APBB2") ,
                        as.array(L_MR_H["MEF2C",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("MEF2C"),ncol=3 )


# MEDIUM RESOLUTION, ALL GENES
L_MR_H <- local({
  m <- LandsS_H@assays$RNA@scale.data
  landscapes_MR_H <- knn_rowMeans(m,gridlistH$grid_medR) ; rownames(landscapes_MR_H) <- rownames(m) ; landscapes_MR_H
})
#saveRDS(L_MR_H,"humous_v4/out/landsH/L_MR_H.rds")
L_MR_H <- readRDS("humous_v4/out/landsH/L_MR_H.rds")

# LOW RESOLUTION, ALL GENES
L_LR_H <- local({
  m <- LandsS_H@assays$RNA@scale.data
  landscapes_LR_H <- knn_rowMeans(m,gridlistH$grid_lowR) ; rownames(landscapes_LR_H) <- rownames(m) ; landscapes_LR_H
})
#saveRDS(L_LR_H,"humous_v4/out/landsH/L_LR_H.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



# PNG LANDSCAPES FOR WEBSITE
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

# # FIRST version, with all info in x and y axis labels 
# parallel::detectCores()
# mclapply(mc.cores=16, rownames(L_MR_H),function(i){
#   png(paste0("humous_v4/out/pngLs/web_pngLs/H/",i,"_H.png"),width=500,height=500) 
#   print(as.array(L_MR_H[i,,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% website_ggraster() + ggtitle(paste(i," (Hm)")))
#   dev.off()
# })

# SECOND version, with summarized info and bigger font in x and y axis labels 
parallel::detectCores()
mclapply(mc.cores=64, rownames(L_MR_H),function(i){
  png(paste0("humous_v4/out/pngLs/web_pngLs/H/",i,"_H.png"),width=500,height=500) 
  print(as.array(L_MR_H[i,,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% website_ggraster() + ggtitle(paste(i," (Hm)")) + 
          xlab("Age") + ylab("Differentiation") + theme(axis.title = element_text(size=40)))
  dev.off()
})

# how many were saved?
npngs_H<- list.files("humous_v4/out/pngLs/web_pngLs/H/")
length(npngs_H) ; nrow(L_MR_H) # good, all are there
# see one
plot(0:1, 0:1, type="n", xlab="", ylab="", xlim=c(0,1), ylim=c(0,1))
rasterImage(readPNG(paste0("humous_v4/out/pngLs/web_pngLs/H/",npngs_H[1])), 0, 0, 1, 1)

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



# PNG LANDSCAPES FOR DEEPLEARNING
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

parallel::detectCores()
mclapply(mc.cores=16, rownames(L_MR_H),function(i){
  png(paste0("humous_v4/out/pngLs/ml_pngLs/H/",i,"_H.png"),width=224,height=224) 
  print(as.array(L_MR_H[i,,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% ML_ggraster())
  dev.off()
})

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 










