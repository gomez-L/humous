

# Hv3

# LANDSCAPES CALCULATION HUMAN ORGS

source("humous_v3/lib/lib_misc.R")
source("humous_v3/lib/lib_lands.R")

library(Seurat) ; library(SeuratObject) ; library(dplyr) ; library(ggplot2) ; library(png)

# Load data (result from integration and ordis) - 
# contains cells for landscapes and ordis normalized
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
IntO_ordi <- readRDS("~/humous/humous_v3/out/ordiO/IntO_ordi.rds")

# there is a problem with the expression data of Pt20 and Av19, got corrupted at some stage. 
# it is solvable cause in case of organoids, as integrated with human initially, we need to go back to raw data
# load raw objects from Pt10 and Av19, annotate them and keep the cells that were selected for landscapes, then merge all again
Pt20 <- readRDS("~/humous/data/raw/Pt20/Pt20.rds") 
Pt20 <- subset(Pt20,cells=intersect(colnames(Pt20),colnames(IntO_ordi))) 

Av19 <- readRDS("~/humous/data/raw/Av19/Av19.rds")
Av19 <- subset(Av19,cells=intersect(colnames(Av19),colnames(IntO_ordi))) 

# Preprocess datasets for landscapes
# Using RNA assay, keep genes expressed in all datasets and scale data slot of RNA for nfeatures

DefaultAssay(IntO_ordi) <- "RNA" ; IntO_ordi[['integrated']] <- NULL
IntO_ordi_f <- subset(IntO_ordi,dataset %in% c("Ck19","Kp19"))

# assemble and annotate
IntO_ordi_2 <- merge(IntO_ordi_f,list(Pt20,Av19))

IntO_ordi_2$dataset <- IntO_ordi$dataset[match(colnames(IntO_ordi_2),colnames(IntO_ordi))] 
IntO_ordi_2$dataset_proto <- IntO_ordi$dataset_proto[match(colnames(IntO_ordi_2),colnames(IntO_ordi))] 
IntO_ordi_2$dataset_proto2 <- IntO_ordi$dataset_proto2[match(colnames(IntO_ordi_2),colnames(IntO_ordi))] ; table(IntO_ordi_2$dataset_proto2, useNA="always" )
IntO_ordi_2$ordi_age <- IntO_ordi$ordi_age[match(colnames(IntO_ordi_2),colnames(IntO_ordi))] 
IntO_ordi_2$ordi_age_norm <- IntO_ordi$ordi_age_norm[match(colnames(IntO_ordi_2),colnames(IntO_ordi))] 
IntO_ordi_2$ordi_diff <- IntO_ordi$ordi_diff[match(colnames(IntO_ordi_2),colnames(IntO_ordi))] 
IntO_ordi_2$ordi_diff_norm <- IntO_ordi$ordi_diff_norm[match(colnames(IntO_ordi_2),colnames(IntO_ordi))] 
IntO_ordi_2$diff_ek <- IntO_ordi$diff_ek[match(colnames(IntO_ordi_2),colnames(IntO_ordi))] 
IntO_ordi_2$age_ek <- IntO_ordi$age_ek[match(colnames(IntO_ordi_2),colnames(IntO_ordi))] 
IntO_ordi_2$y_age <- IntO_ordi$y_age[match(colnames(IntO_ordi_2),colnames(IntO_ordi))]  
IntO_ordi_2$y_diff <- IntO_ordi$y_diff[match(colnames(IntO_ordi_2),colnames(IntO_ordi))] 
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# GENE SELECTION
###################
# subset to keep just genes expressed in more than 1% of the cells across datasets 
num_positive <- apply(IntO_ordi_2@assays$RNA@counts > 0, 1, sum)
genestokeep_o <- rownames(IntO_ordi_2)[num_positive > round(1/100 * ncol(IntO_ordi_2)) ] # 1%
LandsS_O <- subset(IntO_ordi_2,features = genestokeep_o)

###################


# DATA SCALING AND SAVING
###################
# scale data slot for nfeatures on all genes and correct it so it doesnt have negative values
LandsS_O <- LandsS_O %>% NormalizeData() %>% ScaleData(vars.to.regress="nFeature_RNA",features=rownames(LandsS_O)) # rang_expr <- range(IntH_ordi@assays$RNA@scale.data)
LandsS_O@assays$RNA@scale.data <- LandsS_O@assays$RNA@scale.data + abs(min(LandsS_O@assays$RNA@scale.data))
#saveRDS(LandsS_O,"humous_v4/out/landsO/LandsS_O.rds")
LandsS_O <- readRDS("~/humous/humous_v4/out/landsO/LandsS_O.rds")
###################


# VISUALIZATION
# check if gene expression makes sense in scale.data scatter
LandsS_O$SOX2 <- LandsS_O@assays$RNA@scale.data["SOX2",] ; LandsS_O$EOMES <- LandsS_O@assays$RNA@scale.data["EOMES",] ; LandsS_O$NEUROD6 <- LandsS_O@assays$RNA@scale.data["NEUROD6",]
LandsS_O$JUNB <- LandsS_O@assays$RNA@scale.data["JUNB",] ; LandsS_O$APBB2 <- LandsS_O@assays$RNA@scale.data["APBB2",] ; LandsS_O$MEF2C <- LandsS_O@assays$RNA@scale.data["MEF2C",]
ggplot(LandsS_O@meta.data) + geom_point(aes(ordi_age_norm,ordi_diff_norm,color=NEUROD6)) + scale_color_gradient2(low="white",mid="grey",high="red",midpoint = 6)

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# GRIDS generation
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
gridlistO <- list(grid_medR=knn_array_medres(LandsS_O$ordi_age_norm,LandsS_O$ordi_diff_norm,k=100L),
                  grid_lowR=knn_array_lowres(LandsS_O$ordi_age_norm,LandsS_O$ordi_diff_norm,k=100L),
                  grid_highR=knn_array_highres(LandsS_O$ordi_age_norm,LandsS_O$ordi_diff_norm,k=100L))
#saveRDS(gridlistO,"humous_v4/out/landsO/gridlistO.rds")
gridlistO <- readRDS("~/humous/humous_v4/out/landsO/gridlistO.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# COMPUTE LANDSCAPES
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

# trial for key genes
L_MR_O <- local({
  m <- LandsS_O@assays$RNA@scale.data[c("SOX2","EOMES","NEUROD6","JUNB","APBB2","MEF2C","NEUROD2","DCX","TUBB3"),]
  landscapes_MR_O <- knn_rowMeans(m,gridlistO$grid_medR) ; rownames(landscapes_MR_O) <- rownames(m) ; landscapes_MR_O
})

gridExtra::grid.arrange(as.array(L_MR_O["SOX2",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster() + ggtitle("SOX2"),
                        as.array(L_MR_O["EOMES",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("EOMES") , 
                        as.array(L_MR_O["NEUROD6",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("NEUROD6") ,
                        as.array(L_MR_O["JUNB",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster() + ggtitle("JUNB"),
                        as.array(L_MR_O["APBB2",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("APBB2") ,
                        as.array(L_MR_O["MEF2C",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("MEF2C"),
                        as.array(L_MR_O["NEUROD2",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster() + ggtitle("NEUROD2"),
                        as.array(L_MR_O["DCX",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster() + ggtitle("DCX"),
                        as.array(L_MR_O["TUBB3",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("TUBB3") ,ncol=3 )


# MEDIUM RESOLUTION, ALL GENES
L_MR_O <- local({
  m <- LandsS_O@assays$RNA@scale.data
  landscapes_MR_O <- knn_rowMeans(m,gridlistO$grid_medR) ; rownames(landscapes_MR_O) <- rownames(m) ; landscapes_MR_O
})
#saveRDS(L_MR_O,"humous_v4/out/landsO/L_MR_O.rds")
L_MR_O <- readRDS("humous_v4/out/landsO/L_MR_O.rds")

# LOW RESOLUTION, ALL GENES
L_LR_O <- local({
  m <- LandsS_O@assays$RNA@scale.data
  landscapes_LR_O <- knn_rowMeans(m,gridlistO$grid_lowR) ; rownames(landscapes_LR_O) <- rownames(m) ; landscapes_LR_O
})
#saveRDS(L_LR_O,"humous_v4/out/landsO/L_LR_O.rds")

# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



# PNG LANDSCAPES FOR WEBSITE
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

# # FIRST version, with all info in x and y axis labels 
# parallel::detectCores()
# mclapply(mc.cores=16, rownames(L_MR_O),function(i){
#   png(paste0("humous_v3/out/pngLs/web_pngLs/O/",i,"_O.png"),width=500,height=500) 
#   print(as.array(L_MR_O[i,,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% website_ggraster() + ggtitle(paste(i," (Org)")))
#   dev.off()
# })


# SECOND version, with summarized info and bigger font in x and y axis labels 
parallel::detectCores()
mclapply(mc.cores=64, rownames(L_MR_O),function(i){
  png(paste0("humous_v4/out/pngLs/web_pngLs/O/",i,"_O.png"),width=500,height=500) 
  print(as.array(L_MR_O[i,,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% website_ggraster() + ggtitle(paste(i," (Org)")) + 
          xlab("Age") + ylab("Differentiation") + theme(axis.title = element_text(size=40)) )
  dev.off()
})

# how many were saved?
npngs_O<- list.files("humous_v4/out/pngLs/web_pngLs/O/")
length(npngs_O) ; nrow(L_MR_O) # good, all are there
# see one
plot(0:1, 0:1, type="n", xlab="", ylab="", xlim=c(0,1), ylim=c(0,1))
rasterImage(readPNG(paste0("humous_v4/out/pngLs/web_pngLs/O/",npngs_O[1])), 0, 0, 1, 1)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



# PNG LANDSCAPES FOR DEEPLEARNING
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

parallel::detectCores()
mclapply(mc.cores=16, rownames(L_MR_O),function(i){
  png(paste0("humous_v4/out/pngLs/ml_pngLs/O/",i,"_O.png"),width=224,height=224) 
  print(as.array(L_MR_O[i,,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% ML_ggraster())
  dev.off()
})

npngs <- list.files("humous_v4/out/pngLs/ml_pngLs/O/")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 









