
# Hv3

# LANDSCAPES CALCULATION MOUSE

source("humous_v3/lib/lib_misc.R")
source("humous_v3/lib/lib_lands.R")

library(Seurat) ; library(SeuratObject) ; library(dplyr) ; library(ggplot2) ; library(stringr) ; library(png)

# Load data (result from integration and ordis) - 
    # contains cells for landscapes and ordis normalized
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
IntM_ordi <- readRDS("~/humous/humous_v3/out/ordiM/IntM_ordi.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# Preprocess dataset for landscapes
    # keep genes expressed in a 1% of cells across all datasets and scale data slot of RNA for nfeatures
    # for mouse, keep all the genes the way they are and we'll deal with orthologs afterwards

DefaultAssay(IntM_ordi) <- "RNA" 
IntM_ordi[['integrated']] <- NULL 

# GENE SELECTION
###################

# subset to keep just genes expressed in more than 1% of the cells across datasets 
num_positive <- apply(IntM_ordi@assays$RNA@counts > 0, 1, sum)
genestokeep_m <- rownames(IntM_ordi)[num_positive > round(1/100 * ncol(IntM_ordi)) ] # 1%
LandsS_M <- subset(IntM_ordi,features = genestokeep_m)

# good, Arhgap11a should exist in mouse but not Arhgap11b
table(grepl("Arhgap11a",genestokeep_m)) ; table(grepl("Arhgap11b",genestokeep_m)) 
table(grepl("Arhgap11a",rownames(LandsS_M))) 

###################


# DATA SCALING AND SAVING
###################
# scale data slot for nfeatures on all genes and correct it so it doesnt have negative values

# MOUSE
LandsS_M <- LandsS_M %>% NormalizeData() %>% ScaleData(vars.to.regress="nFeature_RNA",features=rownames(LandsS_M)) # rang_expr <- range(IntM_ordi@assays$RNA@scale.data)
LandsS_M@assays$RNA@scale.data <- LandsS_M@assays$RNA@scale.data + abs(min(LandsS_M@assays$RNA@scale.data))
#saveRDS(LandsS_M,"humous_v4/out/landsM/LandsS_M.rds")
LandsS_M <- readRDS("humous_v4/out/landsM/LandsS_M.rds")
###################


# VISUALIZATION
# check if gene expression makes sense in scale.data scatter
LandsS_M$Sox2 <- LandsS_M@assays$RNA@scale.data["Sox2",] ; LandsS_M$Eomes <- LandsS_M@assays$RNA@scale.data["Eomes",] ; LandsS_M$Neurod6 <- LandsS_M@assays$RNA@scale.data["Neurod6",]
LandsS_M$Junb <- LandsS_M@assays$RNA@scale.data["Junb",] ; LandsS_M$Apbb2 <- LandsS_M@assays$RNA@scale.data["Apbb2",] ; LandsS_M$Mef2c <- LandsS_M@assays$RNA@scale.data["Mef2c",]
ggplot(LandsS_M@meta.data) + geom_point(aes(ordi_age_norm,ordi_diff_norm,color=Eomes)) + scale_color_gradient2(low="white",mid="grey",high="red",midpoint = 6)


# GRIDS generation
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
gridlistM <- list(grid_medR=knn_array_medres(LandsS_M$ordi_age_norm,LandsS_M$ordi_diff_norm,k=100L),
                 grid_lowR=knn_array_lowres(LandsS_M$ordi_age_norm,LandsS_M$ordi_diff_norm,k=100L),
                 grid_highR=knn_array_highres(LandsS_M$ordi_age_norm,LandsS_M$ordi_diff_norm,k=100L))
#saveRDS(gridlistM,"humous_v4/out/landsM/gridlistM.rds")
gridlistM <- readRDS("~/humous/humous_v4/out/landsM/gridlistM.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 


# COMPUTE LANDSCAPES
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

# do a trial with some genes of interest
L_MR_M <- local({
  m <- LandsS_M@assays$RNA@scale.data[c("Sox2","Eomes","Neurod6","Junb","Apbb2","Mef2c"),]
  landscapes_MR_M <- knn_rowMeans(m,gridlistM$grid_medR) ; rownames(landscapes_MR_M) <- rownames(m) ; landscapes_MR_M
})

gridExtra::grid.arrange(as.array(L_MR_M["Sox2",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster() + ggtitle("Sox2"),
                        as.array(L_MR_M["Eomes",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("Eomes") ,
                        as.array(L_MR_M["Neurod6",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("Neurod6"), 
                        as.array(L_MR_M["Junb",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster() + ggtitle("Junb"),
                        as.array(L_MR_M["Apbb2",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("Apbb2") ,
                        as.array(L_MR_M["Mef2c",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% base_ggraster()+ ggtitle("Mef2c"),ncol=3 )


# MEDIUM RESOLUTION, ALL GENES
L_MR_M <- local({
  m <- LandsS_M@assays$RNA@scale.data
  landscapes_MR_M <- knn_rowMeans(m,gridlistM$grid_medR) ; rownames(landscapes_MR_M) <- rownames(m) ; landscapes_MR_M
})
#saveRDS(L_MR_M,"humous_v4/out/landsM/L_MR_M.rds")
L_MR_M <- readRDS("humous_v4/out/landsM/L_MR_M.rds")
# see one: as.array(L_MR_M["Sox2",,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% website_ggraster() + ggtitle(paste("Sox2"," (Ms)"))


# LOW RESOLUTION, ALL GENES
L_LR_M <- local({
  m <- LandsS_M@assays$RNA@scale.data
  landscapes_LR_M <- knn_rowMeans(m,gridlistM$grid_lowR) ; rownames(landscapes_LR_M) <- rownames(m) ; landscapes_LR_M
})
#saveRDS(L_LR_M,"humous_v4/out/landsM/L_LR_M.rds")
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



# PNG LANDSCAPES FOR WEBSITE
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 
# 
# # ORTHOLOG RENAMING
# # names of genes for the website pngs should be the human ones but in title format for those mouse genes with orthologs and the mouse ones for the rest
# landsnames <- data.frame(M=rownames(L_MR_M),Horth=NA)
# # load orth table and remove rows without value in both columns, remove special patterns
# ortholog <- as.data.frame(read.csv("humous_v3/data/MH_orthologs.csv"))
# landsnames$Horth <- ortholog$hsa[match(landsnames$M,ortholog$mmu)]  # 1150 mouse genes don't have Horth
# onlyM <- landsnames$M[ is.na(landsnames$Horth)] ; #write.csv(onlyM,"humous_v3/out/landsM/mousegenes_NoHorth.csv")
# landsnames$MHconsensus <- ifelse(is.na(landsnames$Horth),as.character(landsnames$M),as.character(landsnames$Horth))
# 
# # rename landscapes in L_MR_M so the ones with Horths are called as the human gene and others keep the mouse name
# rownames(L_MR_M) <- landsnames$MHconsensus


# # FIRST version, with all info in x and y axis labels 
# parallel::detectCores()
# mclapply(mc.cores=16, rownames(L_MR_M),function(i){
#   png(paste0("humous_v3/out/pngLs/web_pngLs/M/",i,"_M.png"),width=500,height=500) 
#   print(as.array(L_MR_M[i,,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% website_ggraster() + ggtitle(paste(i," (Ms)")))
#   dev.off()
# })


# SECOND version, with summarized info and bigger font in x and y axis labels 
parallel::detectCores()
mclapply(mc.cores=64, rownames(L_MR_M),function(i){
  png(paste0("humous_v4/out/pngLs/web_pngLs/M/",i,"_M.png"),width=500,height=500) 
  print(as.array(L_MR_M[i,,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% website_ggraster() + ggtitle(paste(str_to_title(i)," (Ms)")) + 
          xlab("Age") + ylab("Differentiation") + theme(axis.title = element_text(size=40)))
  dev.off()
})

# how many were saved?
npngs_M<- list.files("humous_v4/out/pngLs/web_pngLs/M/")
length(npngs_M) ; nrow(L_MR_M) # good, all are there
# see one
plot(0:1, 0:1, type="n", xlab="", ylab="", xlim=c(0,1), ylim=c(0,1))
rasterImage(readPNG(paste0("humous_v4/out/pngLs/web_pngLs/M/",npngs_M[1])), 0, 0, 1, 1)
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



# PNG LANDSCAPES FOR DEEPLEARNING
# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 

parallel::detectCores()
mclapply(mc.cores=16, rownames(L_MR_M),function(i){
  png(paste0("humous_v4/out/pngLs/ml_pngLs/M/",i,"_M.png"),width=224,height=224) 
  print(as.array(L_MR_M[i,,]) %>% scales::rescale(to=c(0,1)) %>% raster::raster() %>% ML_ggraster())
  dev.off()
})

plot(0:1, 0:1, type="n", xlab="", ylab="", xlim=c(0,1), ylim=c(0,1))
rasterImage(readPNG("humous_v4/out/pngLs/ml_pngLs/M/Gm6654_M.png"), 0, 0, 1, 1)


# --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- # --- 



