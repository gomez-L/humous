

# LANDSCAPES' SD & ENTROPY 


# STANDARD DEVIATION LANDSCAPES
###############################################
# calculate sd of landscapes to know where are the dotties
# sd: measure of the spread of pixel values around the mean value (low sd will be indicative of dottiness)

# human
L_MR_H <- readRDS("~/humous/humous_v4/out/landsH/L_MR_H.rds")
sd_L_H_df <- data.frame(gene=rownames(L_MR_H),sd_L_H=NA)
sd_L_H <- function(gene){sd(as.vector(L_MR_H[gene,,] ) ) }
a <- mapply(sd_L_H,sd_L_H_df$gene)
sd_L_H_df$sd_L_H <- a[match(sd_L_H_df$gene,names(a))]
#saveRDS(sd_L_H_df,"humous_v4/out/landsH/sd_L_H_df.rds")
rm(L_MR_H) ; gc()

# mouse
L_MR_M <- readRDS("~/humous/humous_v4/out/landsM/L_MR_M.rds")
sd_L_M_df <- data.frame(gene=rownames(L_MR_M),sd_L_M=NA)
sd_L_M <- function(gene){sd(as.vector(L_MR_M[gene,,] ) ) }
a <- mapply(sd_L_M,sd_L_M_df$gene)
sd_L_M_df$sd_L_M <- a[match(sd_L_M_df$gene,names(a))]
#saveRDS(sd_L_M_df,"humous_v4/out/landsM/sd_L_M_df.rds")
rm(L_MR_M) ; gc()

# humanorg
L_MR_O <- readRDS("~/humous/humous_v4/out/landsO/L_MR_O.rds")
sd_L_O_df <- data.frame(gene=rownames(L_MR_O),sd_L_O=NA)
sd_L_O <- function(gene){sd(as.vector(L_MR_O[gene,,] ) ) }
a <- mapply(sd_L_O,sd_L_O_df$gene)
sd_L_O_df$sd_L_O <- a[match(sd_L_O_df$gene,names(a))]
#saveRDS(sd_L_O_df,"humous_v4/out/landsO/sd_L_O_df.rds")
rm(L_MR_O) ; gc()
###############################################


# entropy
###############################################

# ENTROPY: measure of the amount of uncertainty or randomness in the pixel values of an image

# HUMAN
pngs_H <- list.files("humous_v4/out/pngLs/ml_pngLs/H/",full.names = TRUE,recursive = TRUE,pattern = ".png")
ent_L_H_df <- data.frame(gene=mgsub::mgsub(pattern=c("humous_v4/out/pngLs/ml_pngLs/H//",".png"),replacement=c("",""),string=pngs_H),entropy=NA)
for (i in levels(as.factor(pngs_H))){
  print(i)
  ent_L_H_df$entropy[ent_L_H_df$gene==mgsub::mgsub(pattern=c("humous_v4/out/pngLs/ml_pngLs/H//",".png"),replacement=c("",""),string=i)] <- entropy::entropy(as.matrix(readPNG(i)),method="CS")
}
#saveRDS(ent_L_H_df,"humous_v4/out/landsH/ent_L_H_df.rds")


# MOUSE
pngs_M <- list.files("humous_v4/out/pngLs/ml_pngLs/M/",full.names = TRUE,recursive = TRUE,pattern = ".png")
ent_L_M_df <- data.frame(gene=mgsub::mgsub(pattern=c("humous_v4/out/pngLs/ml_pngLs/M//",".png"),replacement=c("",""),string=pngs_M),entropy=NA)
for (i in levels(as.factor(pngs_M))){
  ent_L_M_df$entropy[ent_L_M_df$gene==mgsub::mgsub(pattern=c("humous_v4/out/pngLs/ml_pngLs/M//",".png"),replacement=c("",""),string=i)] <- entropy::entropy(as.matrix(readPNG(i)),method="CS")
}
#saveRDS(ent_L_M_df,"humous_v4/out/landsM/ent_L_M_df.rds")


# ORG
pngs_M <- list.files("humous_v4/out/pngLs/ml_pngLs/O/",full.names = TRUE,recursive = TRUE,pattern = ".png")
ent_L_M_df <- data.frame(gene=mgsub::mgsub(pattern=c("humous_v4/out/pngLs/ml_pngLs/M//",".png"),replacement=c("",""),string=pngs_M),entropy=NA)
for (i in levels(as.factor(pngs_M))){
  ent_L_M_df$entropy[ent_L_M_df$gene==mgsub::mgsub(pattern=c("humous_v4/out/pngLs/ml_pngLs/M//",".png"),replacement=c("",""),string=i)] <- entropy::entropy(as.matrix(readPNG(i)),method="CS")
}
#saveRDS(ent_L_M_df,"humous_v4/out/landsM/ent_L_M_df.rds")
###############################################






